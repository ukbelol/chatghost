#!/bin/bash
# ==============================================================================
# CHAT GHOST - SECURE XMPP SERVER & WEB CLIENT INTEGRATED AUTOMATIC INSTALLER
# Target OS: Linux Debian 12 (Bookworm) / Ubuntu 22.04 LTS+
# Domain: chatghost.smartmall577.space
# Admin JID: newest@chatghost.smartmall577.space
# Security Email: rogermei577@gmail.com
# ==============================================================================

# Exit on any error
set -e

# ANSI Color Codes for terminal beauty
GREEN='\033[0;32m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}===================================================================${NC}"
echo -e "${PURPLE}          CHAT GHOST XMPP INTEGRATED SERVICE AUTOMATIC INSTALLER     ${NC}"
echo -e "${BLUE}===================================================================${NC}"
echo -e "Target Domain:  chatghost.smartmall577.space"
echo -e "Security Email: rogermei577@gmail.com"
echo -e "Target OS:      Debian 12 / Ubuntu Linux"
echo -e "${BLUE}===================================================================${NC}"

# 1. Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Error: Este script precisa ser executado como root (sudo su -).${NC}"
  exit 1
fi

# 2. Update System repositories
echo -e "\n${YELLOW}[1/8] Atualizando repositórios e pacotes do sistema...${NC}"
apt-get update && apt-get upgrade -y

# 3. Install Core Dependencies
echo -e "\n${YELLOW}[2/8] Instalando dependências essenciais (Nginx, Certbot, GnuPG, Lua...)${NC}"
apt-get install -y curl gnupg2 lsb-release ca-certificates certbot python3-certbot-nginx ufw git build-essential

# 4. Install Prosody XMPP Server (Latest Release)
echo -e "\n${YELLOW}[3/8] Configurando repositório oficial do Prosody XMPP...${NC}"
mkdir -p /etc/apt/keyrings
curl -fsSL https://prosody.im/files/prosody-debian-packages.key | gpg --dearmor -o /etc/apt/keyrings/prosody.gpg || true

# Add Prosody repo to sources list
echo "deb [signed-by=/etc/apt/keyrings/prosody.gpg] http://packages.prosody.im/debian $(lsb_release -sc) main" > /etc/apt/sources.list.d/prosody.list

apt-get update
echo -e "${YELLOW}Instalando servidor Prosody e módulos Lua necessários...${NC}"
apt-get install -y prosody lua-sec lua-socket lua-expat lua-filesystem lua-dbi-sqlite3

# Install community modules for modern WebRTC, WebSocket and Carbon copies support
echo -e "${YELLOW}Baixando módulos comunitários Prosody (WebSockets, WebRTC, CSI)...${NC}"
mkdir -p /usr/lib/prosody-modules
rm -rf /tmp/prosody-modules || true
git clone https://hg.prosody.im/prosody-modules/ /tmp/prosody-modules
cp -r /tmp/prosody-modules/mod_websocket /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_turn_external /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_csi_simple /usr/lib/prosody-modules/ || true

# 5. Configure Prosody (/etc/prosody/prosody.cfg.lua)
echo -e "\n${YELLOW}[4/8] Gerando arquivo de configuração do Prosody XMPP...${NC}"
cat << 'EOF' > /etc/prosody/prosody.cfg.lua
-- Chat Ghost XMPP Server Configuration
-- Domain: chatghost.smartmall577.space

-- Global Server Options
plugin_paths = { "/usr/lib/prosody-modules" }

modules_enabled = {
    -- Core XMPP features
    "roster";
    "saslauth";
    "tls";
    "dialback";
    "disco";
    "private";
    "vcard4";
    "vcard";

    -- Web Chat & WebSocket Features
    "websocket";
    "bosh";

    -- Advanced features
    "carbons"; -- Synchronize chat history between mobile and web clients
    "pep"; -- Personal Eventing Protocol (avatars, typing, mood)
    "adhoc"; -- Remote command line control
    "admin_adhoc";
    "mam"; -- Message Archive Management (message history)
    "csi_simple"; -- Client State Indication
    "blocklist"; -- Block unwanted users
    "ping"; -- Keep connections alive
}

-- Prevent public registration (admins create accounts)
allow_registration = false;
c2s_require_encryption = true;
s2s_require_encryption = true;

-- Certificate Paths (Let's Encrypt managed)
certificates = "/etc/prosody/certs"

-- Logging configuration
log = {
    info = "/var/log/prosody/prosody.log";
    error = "/var/log/prosody/prosody.err";
}

-- Virtual Host definition
VirtualHost "chatghost.smartmall577.space"
    ssl = {
        key = "/etc/prosody/certs/chatghost.smartmall577.space.key";
        certificate = "/etc/prosody/certs/chatghost.smartmall577.space.crt";
    }

-- Multi-User Chat (Conference)
Component "conference.chatghost.smartmall577.space" "muc"
    restrict_room_creation = "admin"
    modules_enabled = { "muc_mam" }

-- External STUN/TURN configurations for Video and Audio WebRTC
Component "turn.chatghost.smartmall577.space" "turn_external"
    turn_external_host = "chatghost.smartmall577.space"
    turn_external_port = 3478
    turn_external_secret = "chatghost-webrtc-secure-turn-key-577"
EOF

# 6. Set up SSL certificates via Let's Encrypt Certbot
echo -e "\n${YELLOW}[5/8] Solicitando certificado SSL Let's Encrypt para chatghost.smartmall577.space...${NC}"
mkdir -p /etc/prosody/certs
chown -R prosody:prosody /etc/prosody/certs

# Generate Let's Encrypt certificates (Port 80 must be available)
systemctl stop nginx || true
certbot certonly --standalone -d chatghost.smartmall577.space --non-interactive --agree-tos -m rogermei577@gmail.com --preferred-challenges http || {
  echo -e "${RED}Erro ao obter certificado SSL. Certifique-se de que a porta 80 está liberada e o DNS aponta para este IP.${NC}"
  echo -e "${YELLOW}Criando certificado auto-assinado temporário para evitar falha no boot...${NC}"
  openssl req -new -newkey rsa:2048 -days 365 -nodes -x509 \
    -subj "/C=BR/ST=SP/L=SaoPaulo/O=ChatGhost/CN=chatghost.smartmall577.space" \
    -keyout /etc/prosody/certs/chatghost.smartmall577.space.key \
    -out /etc/prosody/certs/chatghost.smartmall577.space.crt
}

if [ -f "/etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem" ]; then
  echo -e "${GREEN}Certificado SSL obtido com sucesso! Importando para o Prosody...${NC}"
  cp /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem /etc/prosody/certs/chatghost.smartmall577.space.key
  cp /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem /etc/prosody/certs/chatghost.smartmall577.space.crt
fi

chown -R prosody:prosody /etc/prosody/certs/
chmod 640 /etc/prosody/certs/*.key || true

# 7. Configure Nginx Reverse Proxy
echo -e "\n${YELLOW}[6/8] Configurando Nginx Web Server & Websocket Reverse Proxy...${NC}"
cat << 'EOF' > /etc/nginx/sites-available/chatghost
server {
    listen 80;
    server_name chatghost.smartmall577.space;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name chatghost.smartmall577.space;

    ssl_certificate /etc/prosody/certs/chatghost.smartmall577.space.crt;
    ssl_certificate_key /etc/prosody/certs/chatghost.smartmall577.space.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    root /var/www/chatghost/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # XMPP Secure WebSocket Proxy
    location /xmpp-websocket {
        proxy_pass http://127.0.0.1:5280/xmpp-websocket;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400;
    }

    # BOSH fallback API
    location /http-bind {
        proxy_pass http://127.0.0.1:5280/http-bind;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

# Activate Nginx site config
ln -sf /etc/nginx/sites-available/chatghost /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default || true

# Ensure directory exists for static files
mkdir -p /var/www/chatghost/dist

# 8. Check if we are running in the Chat Ghost project directory to build and deploy the Web interface
if [ -f "./package.json" ]; then
  echo -e "\n${YELLOW}[7/8] Compilando e Implantando a Interface Web do Chat Ghost...${NC}"
  # Check if Node.js is installed, if not install it
  if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Node.js não encontrado. Instalando Node.js 20 LTS (NodeSource)...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
  fi
  
  echo -e "${YELLOW}Instalando dependências do projeto (npm install)...${NC}"
  npm install
  
  echo -e "${YELLOW}Gerando build de produção (npm run build)...${NC}"
  npm run build
  
  echo -e "${YELLOW}Copiando arquivos estáticos para o diretório do Nginx...${NC}"
  cp -r dist/* /var/www/chatghost/dist/
  chown -R www-data:www-data /var/www/chatghost
  echo -e "${GREEN}Interface Web com build de produção implantada com sucesso!${NC}"
else
  echo -e "\n${YELLOW}[7/8] Nota de Implantação da Interface Web:${NC}"
  echo -e "Nenhum arquivo 'package.json' foi detectado na pasta atual."
  echo -e "Após clonar o repositório do Chat Ghost na VPS, execute:"
  echo -e "  npm install && npm run build"
  echo -e "  cp -r dist/* /var/www/chatghost/dist/"
fi

# 9. Create Superadmin User in Prosody
echo -e "\n${YELLOW}[8/8] Registrando Conta de Super Admin no Servidor XMPP...${NC}"
prosodyctl register newest chatghost.smartmall577.space blackangel@577-NHT || echo -e "${YELLOW}Conta 'newest' já registrada ou erro ao registrar.${NC}"

# 10. Configure Firewall (UFW)
echo -e "\n${YELLOW}Configurando Firewall do Servidor (UFW)...${NC}"
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5222/tcp # Conexão direta de cliente XMPP (ex: Gajim, Conversations)
ufw allow 5269/tcp # Federação Servidor-para-Servidor (s2s)
ufw allow 5280/tcp # Prosody HTTP/WebSocket interno
ufw allow 3478/udp # STUN/TURN WebRTC
ufw allow 5349/tcp # STUN/TURN TLS WebRTC
ufw --force enable || true

# Restart and enable services
echo -e "\n${YELLOW}Reiniciando e ativando serviços do Nginx e Prosody...${NC}"
systemctl daemon-reload || true
systemctl restart prosody
systemctl restart nginx
systemctl enable prosody
systemctl enable nginx

echo -e "\n${GREEN}===================================================================${NC}"
echo -e "${GREEN}          INSTALAÇÃO DO CHAT GHOST CONCLUÍDA COM SUCESSO!            ${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e "URL do Cliente Web:  https://chatghost.smartmall577.space"
echo -e "Servidor XMPP Host:  chatghost.smartmall577.space"
echo -e "URL WebSocket:       wss://chatghost.smartmall577.space/xmpp-websocket"
echo -e "Super Admin JID:     newest@chatghost.smartmall577.space"
echo -e "Senha Admin:         blackangel@577-NHT"
echo -e "E-mail Let's Encrypt: rogermei577@gmail.com"
echo -e "===================================================================${NC}"
echo -e "Você já pode se conectar usando o console Web ou seu cliente XMPP nativo favorito."
