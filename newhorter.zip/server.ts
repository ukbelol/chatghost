import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createHttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';

const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), 'data-store.json');

// Interface structures
interface UserStore {
  id: string;
  username: string;
  jid: string;
  password?: string;
  name: string;
  surname?: string;
  email?: string;
  birthDate?: string;
  cpf?: string;
  status: 'online' | 'away' | 'dnd' | 'offline';
  statusMessage?: string;
  avatarColor: string;
  role: 'admin' | 'user';
  createdAt: string;
  trialStartDate?: string;
  paymentExpiresAt?: string;
  graceExpiresAt?: string;
  hasPaid?: boolean;
  paymentStatus?: 'pending' | 'approved' | 'none';
}

interface RoomStore {
  id: string;
  name: string;
  jid: string;
  theme: string;
  description: string;
  participants: string[];
  createdAt: string;
}

interface MessageStore {
  id: string;
  from: string;
  to: string;
  body: string;
  timestamp: string;
  type: 'chat' | 'groupchat';
  senderName?: string;
}

interface Store {
  users: UserStore[];
  rooms: RoomStore[];
  messages: MessageStore[];
  mercadoPagoConfig: {
    accessToken: string;
    publicKey: string;
  };
  payments: {
    id: string;
    userId: string;
    amount: number;
    status: 'pending' | 'approved' | 'rejected';
    qrCode: string;
    qrCodeBase64: string;
    createdAt: string;
  }[];
  blacklist?: string[];
}

// Default values as specified in user requests
const DEFAULT_SUPERADMIN: UserStore = {
  id: 'superadmin',
  username: 'rgs577',
  jid: 'rgs577@smartmall577.space',
  password: '2149090577@Ukbelol-577',
  name: 'Chat Ghost SuperAdmin',
  surname: 'Manager',
  email: 'rogermei577@gmail.com',
  status: 'offline',
  statusMessage: 'Server manager active',
  avatarColor: '#4f46e5', // Indigo
  role: 'admin',
  createdAt: new Date().toISOString(),
  trialStartDate: new Date().toISOString(),
  paymentExpiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365).toISOString(), // Admin doesn't expire
  graceExpiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365 + 1000 * 60 * 60 * 24 * 3).toISOString(),
  hasPaid: true,
  paymentStatus: 'approved'
};

// Default conference rooms to populate the client beautifully on first load
const DEFAULT_ROOMS: RoomStore[] = [
  {
    id: 'general-muc',
    name: 'General Conference',
    jid: 'general@conference.chatghost.smartmall577.space',
    theme: 'General Discussion',
    description: 'Main server lobby for Chat Ghost network users.',
    participants: ['rgs577@smartmall577.space'],
    createdAt: new Date().toISOString()
  },
  {
    id: 'development-muc',
    name: 'XMPP Debian Setup',
    jid: 'debian-setup@conference.chatghost.smartmall577.space',
    theme: 'Technical Installation',
    description: 'Discussions around the Debian 12 open-source server cluster setup.',
    participants: ['rgs577@smartmall577.space'],
    createdAt: new Date().toISOString()
  }
];

// Load or initialize store
function loadStore(): Store {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      // Ensure superadmin always exists with correct credentials
      const adminExists = parsed.users.some((u: any) => u.jid === DEFAULT_SUPERADMIN.jid);
      if (!adminExists) {
        parsed.users.push(DEFAULT_SUPERADMIN);
      }
      if (!parsed.mercadoPagoConfig) {
        parsed.mercadoPagoConfig = {
          accessToken: '',
          publicKey: ''
        };
      }
      if (!parsed.payments) {
        parsed.payments = [];
      }
      if (!parsed.blacklist) {
        parsed.blacklist = [];
      }
      return parsed;
    }
  } catch (err) {
    console.error('Error loading data store, resetting to default:', err);
  }

  const initialStore: Store = {
    users: [DEFAULT_SUPERADMIN],
    rooms: DEFAULT_ROOMS,
    messages: [],
    mercadoPagoConfig: {
      accessToken: '',
      publicKey: ''
    },
    payments: [],
    blacklist: []
  };
  saveStore(initialStore);
  return initialStore;
}

function saveStore(store: Store) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing to data store:', err);
  }
}

const store = loadStore();

// Let's draft the Debian 12 automated installation script requested by the user
const DEBIAN_INSTALL_SCRIPT = `#!/bin/bash
# ==============================================================================
# CHAT GHOST - SECURE XMPP SERVER INSTALLATION SCRIPT
# Target OS: Linux Debian 12 (Bookworm)
# Server Architecture: Prosody XMPP Server + Nginx SSL Reverse Proxy + Certbot
# Domain: chatghost.smartmall577.space
# Admin JID: rgs577@smartmall577.space
# Security Email: rogermei577@gmail.com
# ==============================================================================

# Exit on any error
set -e

# ANSI Color Codes
GREEN='\\033[0;32m'
PURPLE='\\033[0;35m'
BLUE='\\033[0;34m'
YELLOW='\\033[1;33m'
RED='\\033[0;31m'
NC='\\033[0m' # No Color

echo -e "\${BLUE}===================================================================\${NC}"
echo -e "\${PURPLE}          CHAT GHOST XMPP INTEGRATED SERVICE AUTOMATIC INSTALLER     \${NC}"
echo -e "\${BLUE}===================================================================\${NC}"
echo -e "Target Domain:  chatghost.smartmall577.space"
echo -e "Security Email: rogermei577@gmail.com"
echo -e "OS Verified:    Debian 12"
echo -e "==================================================================="

# 1. Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "\${RED}Error: This script must be run as root (sudo).\${NC}"
  exit 1
fi

# 2. Update System repositories
echo -e "\n\${YELLOW}[1/7] Updating system packages...\${NC}"
apt-get update && apt-get upgrade -y

# 3. Install Core Dependencies
echo -e "\n\${YELLOW}[2/7] Installing dependencies (Nginx, Certbot, GnuPG, Lua...)\${NC}"
apt-get install -y curl gnupg2 lsb-release ca-certificates certbot python3-certbot-nginx ufw git build-essential

# 4. Install Prosody XMPP Server (Latest Release)
echo -e "\n\${YELLOW}[3/7] Setting up Prosody official repository...\${NC}"
# Add Prosody GPG key
mkdir -p /etc/apt/keyrings
curl -fsSL https://prosody.im/files/prosody-debian-packages.key | gpg --dearmor -o /etc/apt/keyrings/prosody.gpg

# Add Prosody repo to sources list
echo "deb [signed-by=/etc/apt/keyrings/prosody.gpg] http://packages.prosody.im/debian $(lsb_release -sc) main" > /etc/apt/sources.list.d/prosody.list

apt-get update
echo -e "\${YELLOW}Installing Prosody server and extra modules...\${NC}"
apt-get install -y prosody lua-sec lua-socket lua-expat lua-filesystem lua-dbi-sqlite3

# Install community modules for modern WebRTC, WebSocket and Carbon copies support
echo -e "\${YELLOW}Downloading community modules for enhanced WebSockets & WebRTC...\${NC}"
mkdir -p /usr/lib/prosody-modules
git clone https://hg.prosody.im/prosody-modules/ /tmp/prosody-modules
cp -r /tmp/prosody-modules/mod_websocket /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_turn_external /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_csi_simple /usr/lib/prosody-modules/ || true

# 5. Configure Prosody (/etc/prosody/prosody.cfg.lua)
echo -e "\n\${YELLOW}[4/7] Generating Prosody configuration file...\${NC}"
cat << 'EOF' > /etc/prosody/prosody.cfg.lua
-- Chat Ghost XMPP Server Configuration
-- Domain: chatghost.smartmall577.space

-- Global Server Options
plugin_paths = { "/usr/lib/prosody-modules" }

modules_enabled = {
    -- Core XMPP features
    "roster";
    "saslauth";
    "tls";
    "dialback";
    "disco";
    "private";
    "vcard4";
    "vcard";

    -- Web Chat & WebSocket Features
    "websocket";
    "bosh";

    -- Advanced features
    "carbons"; -- Synchronize chat history between mobile and web clients
    "pep"; -- Personal Eventing Protocol (avatars, typing, mood)
    "adhoc"; -- Remote command line control
    "admin_adhoc";
    "mam"; -- Message Archive Management (message history)
    "csi_simple"; -- Client State Indication
    "blocklist"; -- Block unwanted users
    "ping"; -- Keep connections alive
}

-- Prevent public registration (admins create accounts)
allow_registration = false;
c2s_require_encryption = true;
s2s_require_encryption = true;

-- Certificate Paths (Let's Encrypt managed)
certificates = "/etc/prosody/certs"

-- Logging configuration
log = {
    info = "/var/log/prosody/prosody.log";
    error = "/var/log/prosody/prosody.err";
}

-- Virtual Host definition
VirtualHost "chatghost.smartmall577.space"
    ssl = {
        key = "/etc/prosody/certs/chatghost.smartmall577.space.key";
        certificate = "/etc/prosody/certs/chatghost.smartmall577.space.crt";
    }

-- Multi-User Chat (Conference)
Component "conference.chatghost.smartmall577.space" "muc"
    restrict_room_creation = "admin"
    modules_enabled = { "muc_mam" }

-- External STUN/TURN configurations for Video and Audio WebRTC
-- Pre-configured open-source coturn references
Component "turn.chatghost.smartmall577.space" "turn_external"
    turn_external_host = "chatghost.smartmall577.space"
    turn_external_port = 3478
    turn_external_secret = "chatghost-webrtc-secure-turn-key-577"
EOF

# 6. Set up SSL certificates via Let's Encrypt Certbot
echo -e "\n\${YELLOW}[5/7] Requesting Let's Encrypt SSL certificates for chatghost.smartmall577.space...\${NC}"
# Create directory for Prosody certificates
mkdir -p /etc/prosody/certs
chown -R prosody:prosody /etc/prosody/certs

# Generate Let's Encrypt certificates
systemctl stop nginx || true
certbot certonly --standalone -d chatghost.smartmall577.space --non-interactive --agree-tos -m rogermei577@gmail.com --preferred-challenges http

# Import certificates to Prosody
echo -e "\${YELLOW}Importing SSL certificates into Prosody...\${NC}"
cp /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem /etc/prosody/certs/chatghost.smartmall577.space.key
cp /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem /etc/prosody/certs/chatghost.smartmall577.space.crt

chown -R prosody:prosody /etc/prosody/certs/
chmod 640 /etc/prosody/certs/*.key || true

# 7. Configure Nginx Reverse Proxy
echo -e "\n\${YELLOW}[6/7] Configuring Nginx to reverse proxy XMPP Websockets...\${NC}"
cat << 'EOF' > /etc/nginx/sites-available/chatghost
server {
    listen 80;
    server_name chatghost.smartmall577.space;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name chatghost.smartmall577.space;

    ssl_certificate /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    root /var/www/chatghost/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # XMPP Secure WebSocket Proxy
    location /xmpp-websocket {
        proxy_pass http://127.0.0.1:5280/xmpp-websocket;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400;
    }

    # BOSH fallback API
    location /http-bind {
        proxy_pass http://127.0.0.1:5280/http-bind;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

# Activate Nginx site config
ln -sf /etc/nginx/sites-available/chatghost /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default || true

# Ensure directory exists for static files
mkdir -p /var/www/chatghost/dist

# 8. Create Superadmin User in Prosody
echo -e "\n\${YELLOW}[7/7] Registering Super Admin account...\${NC}"
# Use prosodyctl to register rgs577@smartmall577.space with password 2149090577@Ukbelol-577
prosodyctl register rgs577 smartmall577.space 2149090577@Ukbelol-577 || echo "Admin already registered or error"

# 9. Configure Firewall (UFW)
echo -e "\n\${YELLOW}Configuring Firewall (allowing ports 80, 443, 5222, 5269, 5280, 3478, 5349)...\${NC}"
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5222/tcp # XMPP Client connection
ufw allow 5269/tcp # XMPP Server-to-Server
ufw allow 5280/tcp # Prosody HTTP
ufw allow 3478/udp # STUN/TURN
ufw allow 5349/tcp # STUN/TURN Secure
ufw --force enable || true

# Restart services
echo -e "\n\${GREEN}Restarting Nginx and Prosody services...\${NC}"
systemctl restart nginx
systemctl restart prosody

echo -e "\n\${GREEN}===================================================================\${NC}"
echo -e "\${GREEN}          CHAT GHOST INSTALLATION COMPLETED SUCCESSFULLY!            \${NC}"
echo -e "\${GREEN}===================================================================\${NC}"
echo -e "Web Client URL:  https://chatghost.smartmall577.space"
echo -e "XMPP Server JID: chatghost.smartmall577.space"
echo -e "WebSocket URL:   wss://chatghost.smartmall577.space/xmpp-websocket"
echo -e "Super Admin:     rgs577@smartmall577.space"
echo -e "Password:        2149090577@Ukbelol-577"
echo -e "SSL Security:    rogermei577@gmail.com"
echo -e "🛡️ Segurança:     Acesso restrito apenas ao Super Admin"
echo -e "🚫 IP Blacklist:  Ativo (3 erros consecutivos bloqueiam a faixa /24)"
echo -e "==================================================================="
`;

function getBillingDates(fromDate: Date) {
  const date = new Date(fromDate);
  let year = date.getFullYear();
  let month = date.getMonth(); // 0-11
  
  if (date.getDate() >= 6) {
    month += 1;
    if (month > 11) {
      month = 0;
      year += 1;
    }
  }
  
  const nextDay6 = new Date(year, month, 6, 23, 59, 59, 999);
  const nextDay10 = new Date(year, month, 10, 23, 59, 59, 999);
  
  return { nextDay6, nextDay10 };
}

function getUserSubscriptionStatus(user: UserStore) {
  if (user.role === 'admin') {
    return {
      status: 'active',
      daysUsed: 0,
      daysRemaining: 365,
      isBlocked: false,
      isTrial: false,
      isGrace: false,
      trialExpiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
      graceExpiresAt: new Date(Date.now() + 368 * 24 * 60 * 60 * 1000).toISOString(),
      paymentExpiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
    };
  }

  const now = Date.now();
  const trialStart = user.trialStartDate ? new Date(user.trialStartDate).getTime() : new Date(user.createdAt).getTime();
  
  let expiresAt: number;
  let graceExpiresAt: number;

  if (user.paymentExpiresAt) {
    expiresAt = new Date(user.paymentExpiresAt).getTime();
  } else {
    const { nextDay6 } = getBillingDates(new Date(trialStart));
    expiresAt = nextDay6.getTime();
  }

  if (user.graceExpiresAt) {
    graceExpiresAt = new Date(user.graceExpiresAt).getTime();
  } else {
    const { nextDay10 } = getBillingDates(new Date(trialStart));
    graceExpiresAt = nextDay10.getTime();
  }

  const daysUsed = Math.floor((now - trialStart) / (1000 * 60 * 60 * 24));
  const daysRemaining = Math.max(0, Math.ceil((expiresAt - now) / (1000 * 60 * 60 * 24)));
  const graceRemaining = Math.max(0, Math.ceil((graceExpiresAt - now) / (1000 * 60 * 60 * 24)));

  let isBlocked = false;
  let status: 'trial' | 'grace' | 'active' | 'blocked' = 'trial';

  if (user.hasPaid) {
    status = 'active';
    isBlocked = false;
  } else {
    if (now <= expiresAt) {
      status = 'trial';
      isBlocked = false;
    } else if (now <= graceExpiresAt) {
      status = 'grace';
      isBlocked = false;
    } else {
      status = 'blocked';
      isBlocked = true;
    }
  }

  // Calculate actual remaining days to show on button
  let displayDaysRemaining = daysRemaining;
  if (status === 'grace') {
    displayDaysRemaining = graceRemaining;
  }

  return {
    status,
    daysUsed: Math.max(0, daysUsed),
    daysRemaining: displayDaysRemaining,
    isBlocked,
    isTrial: status === 'trial',
    isGrace: status === 'grace',
    trialExpiresAt: new Date(expiresAt).toISOString(),
    graceExpiresAt: new Date(graceExpiresAt).toISOString(),
    paymentExpiresAt: new Date(expiresAt).toISOString()
  };
}

function validateCPF(cpf: string): boolean {
  if (!cpf) return false;
  const cleanCPF = cpf.replace(/[^\d]/g, '');
  if (cleanCPF.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cleanCPF)) return false;

  let sum = 0;
  let remainder;

  for (let i = 1; i <= 9; i++) {
    sum = sum + parseInt(cleanCPF.substring(i - 1, i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;

  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleanCPF.substring(9, 10))) return false;

  sum = 0;
  for (let i = 1; i <= 10; i++) {
    sum = sum + parseInt(cleanCPF.substring(i - 1, i)) * (12 - i);
  }
  remainder = (sum * 10) % 11;

  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleanCPF.substring(10, 11))) return false;

  return true;
}

function maskEmail(email: string): string {
  if (!email) return '';
  const [name, domain] = email.trim().toLowerCase().split('@');
  if (!name || !domain) return '***@***.***';
  const firstThree = name.substring(0, 3);
  return `${firstThree}***@${domain}`;
}

const failedAttempts = new Map<string, number>();

function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    if (typeof forwarded === 'string') {
      const ipList = forwarded.split(',');
      return ipList[0].trim();
    } else if (Array.isArray(forwarded)) {
      return forwarded[0].trim();
    }
  }
  return req.socket.remoteAddress || req.ip || '127.0.0.1';
}

function getIpRange(ip: string): string {
  let normalized = ip;
  if (ip.startsWith('::ffff:')) {
    normalized = ip.replace('::ffff:', '');
  }
  
  if (normalized.includes('.')) {
    const parts = normalized.split('.');
    if (parts.length >= 3) {
      return `${parts[0]}.${parts[1]}.${parts[2]}.0/24`;
    }
  } else if (normalized.includes(':')) {
    const parts = normalized.split(':');
    if (parts.length >= 4) {
      return `${parts[0]}:${parts[1]}:${parts[2]}:${parts[3]}::/64`;
    }
  }
  return normalized;
}

function isIpBlocked(ip: string, blacklist: string[]): boolean {
  const incomingRange = getIpRange(ip);
  return blacklist.includes(incomingRange) || blacklist.includes(ip);
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // IP Blacklist Checking Middleware
  app.use((req, res, next) => {
    const ip = getClientIp(req);
    const blacklist = store.blacklist || [];
    if (isIpBlocked(ip, blacklist)) {
      console.warn(`[Blocked Access] Attempted request from blacklisted IP ${ip} (Range: ${getIpRange(ip)})`);
      return res.status(403).json({ 
        error: 'Acesso negado de rede detectado como intruso. Sua faixa de rede IP está na blacklist.',
        blockedIp: ip,
        blockedRange: getIpRange(ip)
      });
    }
    next();
  });

  // API Endpoints
  
  // Health & Server Stats
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'online',
      system: 'chatghost',
      uptime: process.uptime(),
      domain: 'chatghost.smartmall577.space',
      xmppHost: 'chatghost.smartmall577.space',
      securityEmail: 'rogermei577@gmail.com'
    });
  });

  // Login Endpoint
  app.post('/api/login', (req, res) => {
    const ip = getClientIp(req);
    const blacklist = store.blacklist || [];

    if (isIpBlocked(ip, blacklist)) {
      return res.status(403).json({ error: 'Seu IP ou faixa de rede foi bloqueado por tentativas consecutivas incorretas.' });
    }

    const { jid, password } = req.body;
    if (!jid || !password) {
      return res.status(400).json({ error: 'E-mail, JID ou Nickname e senha são obrigatórios.' });
    }

    const searchKey = jid.trim().toLowerCase();

    // Restrict access ONLY to the Super Administrator
    const superAdminJid = 'rgs577@smartmall577.space';
    const superAdminUsername = 'rgs577';
    const superAdminEmail = 'rogermei577@gmail.com';

    const isSuperAdmin = 
      searchKey === superAdminJid ||
      searchKey === superAdminUsername ||
      searchKey === superAdminEmail;

    if (!isSuperAdmin) {
      // Treat attempts to login with non-superadmin accounts as unauthorized intruder failures
      const currentAttempts = (failedAttempts.get(ip) || 0) + 1;
      failedAttempts.set(ip, currentAttempts);

      if (currentAttempts >= 3) {
        const range = getIpRange(ip);
        if (!store.blacklist) {
          store.blacklist = [];
        }
        if (!store.blacklist.includes(range)) {
          store.blacklist.push(range);
          saveStore(store);
        }
        return res.status(403).json({ error: 'Acesso negado de rede detectado como intruso. Esta faixa de IP foi adicionada à blacklist.' });
      }

      return res.status(401).json({ error: `Acesso restrito apenas para o Super Administrador. Tentativa ${currentAttempts}/3.` });
    }

    const user = store.users.find(u => u.jid === superAdminJid);

    if (!user) {
      return res.status(500).json({ error: 'Erro de sistema: Super Administrador não configurado.' });
    }

    if (user.password !== password) {
      const currentAttempts = (failedAttempts.get(ip) || 0) + 1;
      failedAttempts.set(ip, currentAttempts);

      if (currentAttempts >= 3) {
        const range = getIpRange(ip);
        if (!store.blacklist) {
          store.blacklist = [];
        }
        if (!store.blacklist.includes(range)) {
          store.blacklist.push(range);
          saveStore(store);
        }
        return res.status(403).json({ error: 'Seu IP/faixa de rede foi bloqueado após 3 erros consecutivos de senha.' });
      }

      return res.status(401).json({ error: `Senha incorreta para o Super Administrador. Tentativa ${currentAttempts}/3.` });
    }

    // Success! Reset failed attempts for this IP
    failedAttempts.delete(ip);

    // Return user without password
    const { password: _, ...userSafe } = user;
    const subscription = getUserSubscriptionStatus(user);
    res.json({
      ...userSafe,
      subscription
    });
  });

  // Get users (Roster)
  app.get('/api/users', (req, res) => {
    // Return users without passwords
    const safeUsers = store.users.map(({ password, ...u }) => u);
    res.json(safeUsers);
  });

  // Add user (Admin only in real scenario, we allow auth checks)
  app.post('/api/admin/users', (req, res) => {
    const { username, name, password, avatarColor } = req.body;
    
    if (!username || !name || !password) {
      return res.status(400).json({ error: 'Campos obrigatórios ausentes.' });
    }

    const cleanUsername = username.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    const jid = `${cleanUsername}@chatghost.smartmall577.space`;

    // Check if user already exists
    if (store.users.some(u => u.jid === jid)) {
      return res.status(400).json({ error: 'Este usuário já está cadastrado no servidor XMPP.' });
    }

    const colors = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#ef4444'];
    const selectedColor = avatarColor || colors[Math.floor(Math.random() * colors.length)];

    const newUser: UserStore = {
      id: Math.random().toString(36).substr(2, 9),
      username: cleanUsername,
      jid,
      password,
      name,
      status: 'offline',
      avatarColor: selectedColor,
      role: 'user',
      createdAt: new Date().toISOString()
    };

    store.users.push(newUser);
    saveStore(store);

    const { password: _, ...safeUser } = newUser;
    res.status(201).json(safeUser);
  });

  // Delete User
  app.delete('/api/admin/users/:id', (req, res) => {
    const { id } = req.params;
    if (id === 'superadmin') {
      return res.status(400).json({ error: 'Não é possível remover o superadmin principal.' });
    }

    const index = store.users.findIndex(u => u.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    const deletedUser = store.users.splice(index, 1)[0];
    saveStore(store);
    res.json({ success: true, message: `Usuário ${deletedUser.jid} deletado com sucesso.` });
  });

  // Get conference rooms
  app.get('/api/rooms', (req, res) => {
    res.json(store.rooms);
  });

  // Create conference room
  app.post('/api/admin/rooms', (req, res) => {
    const { name, theme, description, participants } = req.body;

    if (!name || !theme) {
      return res.status(400).json({ error: 'Nome e Tema são obrigatórios.' });
    }

    const cleanName = name.trim().toLowerCase().replace(/[^a-z0-9]/g, '-');
    const jid = `${cleanName}@conference.chatghost.smartmall577.space`;

    if (store.rooms.some(r => r.jid === jid)) {
      return res.status(400).json({ error: 'Uma sala de conferência com este endereço já existe.' });
    }

    const newRoom: RoomStore = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      jid,
      theme,
      description: description || '',
      participants: participants || ['rgs577@smartmall577.space'],
      createdAt: new Date().toISOString()
    };

    store.rooms.push(newRoom);
    saveStore(store);

    res.status(201).json(newRoom);
  });

  // Delete Room
  app.delete('/api/admin/rooms/:id', (req, res) => {
    const { id } = req.params;
    const index = store.rooms.findIndex(r => r.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Sala de conferência não encontrada.' });
    }

    const deletedRoom = store.rooms.splice(index, 1)[0];
    saveStore(store);
    res.json({ success: true, message: `Sala ${deletedRoom.name} removida.` });
  });

  // Download Debian Installer Script
  app.get('/api/install-script', (req, res) => {
    res.setHeader('Content-Type', 'application/x-sh');
    res.setHeader('Content-Disposition', 'attachment; filename="install-chatghost.sh"');
    res.send(DEBIAN_INSTALL_SCRIPT);
  });

  // Check Nickname Availability
  app.post('/api/check-nickname', (req, res) => {
    const { nickname } = req.body;
    if (!nickname) {
      return res.status(400).json({ error: 'Nickname é obrigatório.' });
    }
    const cleanUsername = nickname.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    const jid = `${cleanUsername}@chatghost.smartmall577.space`;
    const exists = store.users.some(u => u.jid.toLowerCase() === jid.toLowerCase() || u.username.toLowerCase() === cleanUsername);
    res.json({ available: !exists, cleanUsername });
  });

  // User Registration
  app.post('/api/register', (req, res) => {
    const { nickname, name, surname, email, password, birthDate, cpf } = req.body;
    if (!nickname || !name || !surname || !email || !password || !birthDate || !cpf) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
    }

    // CPF Validation
    if (!validateCPF(cpf)) {
      return res.status(400).json({ error: 'CPF informado é inválido. Digite um CPF real e válido.' });
    }

    const cleanCPF = cpf.replace(/[^\d]/g, '');
    const cleanUsername = nickname.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    const jid = `${cleanUsername}@chatghost.smartmall577.space`;

    if (store.users.some(u => u.jid.toLowerCase() === jid.toLowerCase() || u.username.toLowerCase() === cleanUsername)) {
      return res.status(400).json({ error: 'Este nickname já está em uso.' });
    }

    if (store.users.some(u => u.email && u.email.toLowerCase() === email.trim().toLowerCase())) {
      return res.status(400).json({ error: 'Este e-mail já está cadastrado.' });
    }

    // Duplicate CPF Check
    const userWithCpf = store.users.find(u => u.cpf && u.cpf.replace(/[^\d]/g, '') === cleanCPF);
    if (userWithCpf) {
      const masked = maskEmail(userWithCpf.email || '');
      return res.status(400).json({
        error: 'CPF_DUPLICATE',
        message: `Já existe um cadastro com este CPF. O e-mail cadastrado é ${masked}.`,
        maskedEmail: masked
      });
    }

    const trialStartDate = new Date().toISOString();
    const { nextDay6, nextDay10 } = getBillingDates(new Date());
    const paymentExpiresAt = nextDay6.toISOString();
    const graceExpiresAt = nextDay10.toISOString();

    const colors = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#ef4444'];
    const selectedColor = colors[Math.floor(Math.random() * colors.length)];

    const newUser: UserStore = {
      id: Math.random().toString(36).substr(2, 9),
      username: cleanUsername,
      jid,
      password,
      name: name.trim(),
      surname: surname.trim(),
      email: email.trim().toLowerCase(),
      birthDate: birthDate.trim(),
      cpf: cleanCPF,
      status: 'offline',
      avatarColor: selectedColor,
      role: 'user',
      createdAt: new Date().toISOString(),
      trialStartDate,
      paymentExpiresAt,
      graceExpiresAt,
      hasPaid: false,
      paymentStatus: 'none'
    };

    store.users.push(newUser);
    saveStore(store);

    const { password: _, ...safeUser } = newUser;
    const subscription = getUserSubscriptionStatus(newUser);
    res.status(201).json({
      ...safeUser,
      subscription
    });
  });

  // Verify Reset Password Information
  app.post('/api/reset-password/verify', (req, res) => {
    const { email, birthDate, cpf } = req.body;
    if (!email || !birthDate || !cpf) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios para prosseguir.' });
    }

    const cleanCpf = cpf.replace(/[^\d]/g, '');
    const user = store.users.find(u => {
      const userCpf = (u.cpf || '').replace(/[^\d]/g, '');
      const userEmail = (u.email || '').trim().toLowerCase();
      const userBirthDate = (u.birthDate || '').trim();

      return userCpf === cleanCpf &&
             userEmail === email.trim().toLowerCase() &&
             userBirthDate === birthDate.trim();
    });

    if (!user) {
      return res.status(400).json({ error: 'Os dados informados não conferem com nenhum cadastro no sistema.' });
    }

    res.json({ success: true, userId: user.id });
  });

  // Update Password from Reset Screen
  app.post('/api/reset-password/update', (req, res) => {
    const { userId, password } = req.body;
    if (!userId || !password) {
      return res.status(400).json({ error: 'ID do usuário e senha são necessários.' });
    }

    const user = store.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    user.password = password;
    saveStore(store);

    res.json({ success: true, message: 'Senha redefinida com sucesso!' });
  });

  // Get User Subscription Status
  app.get('/api/user/subscription-status/:userId', (req, res) => {
    const { userId } = req.params;
    const user = store.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }
    const statusInfo = getUserSubscriptionStatus(user);
    res.json(statusInfo);
  });

  // Update User Profile / Password Reset
  app.post('/api/user/update-profile', (req, res) => {
    const { userId, name, surname, email, password } = req.body;
    const user = store.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    if (name) user.name = name.trim();
    if (surname) user.surname = surname.trim();
    if (email) {
      const emailLower = email.trim().toLowerCase();
      const collision = store.users.some(u => u.id !== userId && u.email && u.email.toLowerCase() === emailLower);
      if (collision) {
        return res.status(400).json({ error: 'Este e-mail já está em uso por outro usuário.' });
      }
      user.email = emailLower;
    }
    if (password) {
      user.password = password;
    }

    saveStore(store);
    const { password: _, ...safeUser } = user;
    const subscription = getUserSubscriptionStatus(user);
    res.json({
      success: true,
      user: {
        ...safeUser,
        subscription
      }
    });
  });

  // Get Mercado Pago Config
  app.get('/api/mercadopago/config', (req, res) => {
    const appUrl = process.env.APP_URL || `https://ais-dev-bjkupjb5db362z5dojsbps-133871356398.us-west2.run.app`;
    res.json({
      accessToken: store.mercadoPagoConfig?.accessToken || '',
      publicKey: store.mercadoPagoConfig?.publicKey || '',
      webhookUrl: `${appUrl}/api/payments/webhook`,
      redirectUrl: `${appUrl}/restricted-area`
    });
  });

  // Update Mercado Pago Config
  app.post('/api/mercadopago/config', (req, res) => {
    const { accessToken, publicKey } = req.body;
    if (!store.mercadoPagoConfig) {
      store.mercadoPagoConfig = { accessToken: '', publicKey: '' };
    }
    store.mercadoPagoConfig.accessToken = accessToken || '';
    store.mercadoPagoConfig.publicKey = publicKey || '';
    saveStore(store);
    res.json({ success: true });
  });

  // Create PIX Payment
  app.post('/api/payments/create', async (req, res) => {
    const { userId } = req.body;
    const user = store.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    const now = new Date();
    const { nextDay6 } = getBillingDates(now);
    
    let amount = 15.00;
    
    // Check if they are a new user who hasn't paid yet
    if (!user.hasPaid) {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
      const target = new Date(nextDay6.getFullYear(), nextDay6.getMonth(), nextDay6.getDate(), 0, 0, 0, 0);
      const diffTime = target.getTime() - start.getTime();
      const diffDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
      amount = Number((diffDays * 0.50).toFixed(2));
    }

    const paymentId = 'pay_' + Math.random().toString(36).substr(2, 9);
    const pixCopyPaste = `00020101021226870014br.gov.bcb.pix2565pix.smartmall577.space/pix/pay/${paymentId}52040000530398654051${amount.toFixed(2)}5802BR5909ChatGhost6009Sao Paulo62290525${paymentId}6304CA7D`;
    const qrCodeBase64Placeholder = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(pixCopyPaste)}`;

    const newPayment = {
      id: paymentId,
      userId,
      amount,
      status: 'pending' as const,
      qrCode: pixCopyPaste,
      qrCodeBase64: qrCodeBase64Placeholder,
      createdAt: new Date().toISOString()
    };

    const config = store.mercadoPagoConfig;
    if (config && config.accessToken && config.accessToken.trim() !== '') {
      try {
        const response = await fetch('https://api.mercadopago.com/v1/payments', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${config.accessToken}`,
            'Content-Type': 'application/json',
            'X-Idempotency-Key': paymentId
          },
          body: JSON.stringify({
            transaction_amount: amount,
            description: 'Assinatura Mensal XMPP Chat Ghost XMPP',
            payment_method_id: 'pix',
            payer: {
              email: user.email || 'rogermei577@gmail.com',
              first_name: user.name,
              last_name: user.surname || 'XMPP'
            }
          })
         });

         if (response.ok) {
           const mpData = await response.json();
           if (mpData.id) {
             newPayment.id = String(mpData.id);
             newPayment.qrCode = mpData.point_of_interaction?.transaction_data?.qr_code || pixCopyPaste;
             const base64Img = mpData.point_of_interaction?.transaction_data?.qr_code_base64;
             newPayment.qrCodeBase64 = base64Img ? `data:image/png;base64,${base64Img}` : `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(newPayment.qrCode)}`;
           }
         } else {
           const errText = await response.text();
           console.error('Mercado Pago API error:', errText);
         }
      } catch (err) {
        console.error('Failed to contact Mercado Pago API:', err);
      }
    }

    store.payments.push(newPayment);
    user.paymentStatus = 'pending';
    saveStore(store);

    res.json(newPayment);
  });

  // Check Payment Status
  app.get('/api/payments/status/:paymentId', async (req, res) => {
    const { paymentId } = req.params;
    const payment = store.payments.find(p => p.id === paymentId);
    if (!payment) {
      return res.status(404).json({ error: 'Pagamento não encontrado.' });
    }

    if (payment.status === 'approved') {
      return res.json(payment);
    }

    const config = store.mercadoPagoConfig;
    if (config && config.accessToken && config.accessToken.trim() !== '' && !paymentId.startsWith('pay_')) {
      try {
        const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
          headers: {
            'Authorization': `Bearer ${config.accessToken}`
          }
        });

        if (response.ok) {
          const mpData = await response.json();
          if (mpData.status === 'approved') {
            payment.status = 'approved';
            const user = store.users.find(u => u.id === payment.userId);
            if (user) {
              user.hasPaid = true;
              user.paymentStatus = 'approved';
              const { nextDay6, nextDay10 } = getBillingDates(new Date());
              user.paymentExpiresAt = nextDay6.toISOString();
              user.graceExpiresAt = nextDay10.toISOString();
            }
            saveStore(store);
          }
        }
      } catch (err) {
        console.error('Error fetching Mercado Pago payment status:', err);
      }
    }

    res.json(payment);
  });

  // Mock Approve Payment for Evaluation/Sandbox Test
  app.post('/api/payments/mock-approve/:paymentId', (req, res) => {
    const { paymentId } = req.params;
    const payment = store.payments.find(p => p.id === paymentId);
    if (!payment) {
      return res.status(404).json({ error: 'Pagamento não encontrado.' });
    }

    payment.status = 'approved';
    const user = store.users.find(u => u.id === payment.userId);
    if (user) {
      user.hasPaid = true;
      user.paymentStatus = 'approved';
      const { nextDay6, nextDay10 } = getBillingDates(new Date());
      user.paymentExpiresAt = nextDay6.toISOString();
      user.graceExpiresAt = nextDay10.toISOString();
    }
    saveStore(store);

    res.json({ success: true, payment });
  });

  // Webhook for Mercado Pago Callback
  app.post('/api/payments/webhook', async (req, res) => {
    const { type, data } = req.body;
    if (type === 'payment' && data && data.id) {
      const mpId = String(data.id);
      const payment = store.payments.find(p => p.id === mpId);
      const config = store.mercadoPagoConfig;
      if (config && config.accessToken && config.accessToken.trim() !== '') {
        try {
          const response = await fetch(`https://api.mercadopago.com/v1/payments/${mpId}`, {
            headers: {
              'Authorization': `Bearer ${config.accessToken}`
            }
          });

          if (response.ok) {
            const mpData = await response.json();
            if (mpData.status === 'approved') {
              if (payment) {
                payment.status = 'approved';
              }
              const targetUserId = payment ? payment.userId : null;
              if (targetUserId) {
                const user = store.users.find(u => u.id === targetUserId);
                if (user) {
                  user.hasPaid = true;
                  user.paymentStatus = 'approved';
                  const { nextDay6, nextDay10 } = getBillingDates(new Date());
                  user.paymentExpiresAt = nextDay6.toISOString();
                  user.graceExpiresAt = nextDay10.toISOString();
                }
              }
              saveStore(store);
            }
          }
        } catch (err) {
          console.error('Webhook error:', err);
        }
      }
    }
    res.sendStatus(200);
  });

  // Serve HTTP Server and initialize WebSockets
  const httpServer = createHttpServer(app);
  const wss = new WebSocketServer({ noServer: true });

  // Handle Upgrade from HTTP to WS on the same port
  httpServer.on('upgrade', (request, socket, head) => {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  });

  // WebSocket active connections maps
  const activeConnections = new Map<string, WebSocket>(); // JID -> WebSocket
  const connectionJids = new Map<WebSocket, string>();    // WebSocket -> JID

  wss.on('connection', (ws: WebSocket) => {
    console.log('New WebSocket connection established.');

    ws.on('message', (messageData: string) => {
      try {
        const payload = JSON.parse(messageData);
        const { type, from, to, body, ...rest } = payload;

        if (type === 'auth') {
          // Client is register/binding their JID
          const clientJid = from;
          activeConnections.set(clientJid, ws);
          connectionJids.set(ws, clientJid);

          // Mark user as Online in store
          const user = store.users.find(u => u.jid.toLowerCase() === clientJid.toLowerCase());
          if (user) {
            user.status = 'online';
            saveStore(store);
          }

          console.log(`XMPP Bind Successful: JID ${clientJid}`);

          // Broadcast user status to all connected users
          broadcastStatus(clientJid, 'online');

          // Send current presence states to the newly joined client
          sendInitialPresences(ws);
          return;
        }

        if (type === 'presence') {
          const clientJid = connectionJids.get(ws);
          if (clientJid) {
            const user = store.users.find(u => u.jid.toLowerCase() === clientJid.toLowerCase());
            if (user) {
              user.status = body; // online, away, dnd
              if (rest.statusMessage) {
                user.statusMessage = rest.statusMessage;
              }
              saveStore(store);
            }
            broadcastStatus(clientJid, body, rest.statusMessage);
          }
          return;
        }

        if (type === 'chat' || type === 'groupchat') {
          // Deliver text chat message
          const msgId = Math.random().toString(36).substr(2, 9);
          const timestamp = new Date().toISOString();
          
          const newMessage: MessageStore = {
            id: msgId,
            from,
            to,
            body,
            timestamp,
            type,
            senderName: rest.senderName || from.split('@')[0]
          };

          // Cache in rolling buffer
          store.messages.push(newMessage);
          if (store.messages.length > 500) {
            store.messages.shift();
          }
          saveStore(store);

          if (type === 'chat') {
            // Direct chat: send to recipient websocket if online
            const recipientWs = activeConnections.get(to);
            if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
              recipientWs.send(JSON.stringify({
                type: 'chat',
                id: msgId,
                from,
                to,
                body,
                timestamp,
                senderName: rest.senderName
              }));
            }
            // Send echo back to sender to confirm delivery
            ws.send(JSON.stringify({
              type: 'chat-echo',
              id: msgId,
              from,
              to,
              body,
              timestamp,
              senderName: rest.senderName
            }));
          } else {
            // Groupchat / conference: Broadcast to all members of the room
            const room = store.rooms.find(r => r.jid === to);
            if (room) {
              // Broadcast to everyone currently connected whose JID is a participant
              // or simply broadcast to all connected users who are active in WebSockets
              activeConnections.forEach((conn, userJid) => {
                if (conn.readyState === WebSocket.OPEN) {
                  conn.send(JSON.stringify({
                    type: 'groupchat',
                    id: msgId,
                    from,
                    to, // Room JID
                    body,
                    timestamp,
                    senderName: rest.senderName || from.split('@')[0]
                  }));
                }
              });
            }
          }
          return;
        }

        // WebRTC Signaling: relay signals between peers directly
        if (type === 'call-offer' || type === 'call-answer' || type === 'call-candidate' || type === 'call-hangup' || type === 'call-ringing') {
          console.log(`Relaying WebRTC signaling event "${type}" from ${from} to ${to}`);
          const recipientWs = activeConnections.get(to);
          if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
            recipientWs.send(JSON.stringify({
              type,
              from,
              to,
              payload: rest.payload,
              callType: rest.callType, // 'audio' | 'video'
              callId: rest.callId
            }));
          } else {
            console.log(`Recipient ${to} not online for WebRTC signaling ${type}`);
            if (type === 'call-offer') {
              // Send immediate hangup/fail back to caller
              ws.send(JSON.stringify({
                type: 'call-hangup',
                from: to,
                to: from,
                payload: { reason: 'user_offline' },
                callId: rest.callId
              }));
            }
          }
          return;
        }

      } catch (err) {
        console.error('Error handling WebSocket message:', err);
      }
    });

    ws.on('close', () => {
      const clientJid = connectionJids.get(ws);
      if (clientJid) {
        console.log(`WebSocket disconnected JID: ${clientJid}`);
        activeConnections.delete(clientJid);
        connectionJids.delete(ws);

        // Set status to offline
        const user = store.users.find(u => u.jid.toLowerCase() === clientJid.toLowerCase());
        if (user) {
          user.status = 'offline';
          saveStore(store);
        }

        // Broadcast offline status to everyone
        broadcastStatus(clientJid, 'offline');
      }
    });
  });

  // Helper: Broadcast presence state to everyone
  function broadcastStatus(jid: string, status: string, statusMessage?: string) {
    const payload = JSON.stringify({
      type: 'presence',
      jid,
      status,
      statusMessage: statusMessage || ''
    });

    activeConnections.forEach((conn) => {
      if (conn.readyState === WebSocket.OPEN) {
        conn.send(payload);
      }
    });
  }

  // Helper: Send initial online states to a specific user
  function sendInitialPresences(conn: WebSocket) {
    store.users.forEach((u) => {
      if (u.status !== 'offline') {
        conn.send(JSON.stringify({
          type: 'presence',
          jid: u.jid,
          status: u.status,
          statusMessage: u.statusMessage || ''
        }));
      }
    });
  }

  // Vite Server integration for dev vs prod environments
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Chat Ghost XMPP Server running on http://localhost:${PORT}`);
  });
}

startServer();
