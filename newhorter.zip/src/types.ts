export type XmppStatus = 'online' | 'away' | 'dnd' | 'offline';

export interface User {
  id: string;
  username: string; // e.g. "newest"
  jid: string;      // e.g. "newest@chatghost.smartmall577.space"
  password?: string;
  name: string;     // e.g. "Newest Admin"
  surname?: string;
  email?: string;
  birthDate?: string;
  cpf?: string;
  status: XmppStatus;
  statusMessage?: string;
  avatarColor: string;
  role: 'admin' | 'user';
  createdAt: string;
  trialStartDate?: string;
  paymentExpiresAt?: string;
  graceExpiresAt?: string;
  hasPaid?: boolean;
  paymentStatus?: 'pending' | 'approved' | 'none';
}

export interface MercadoPagoConfig {
  accessToken: string;
  publicKey: string;
}

export interface PaymentInfo {
  id: string;
  userId: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  qrCode: string;
  qrCodeBase64: string;
  createdAt: string;
}

export interface ConferenceRoom {
  id: string;
  name: string;
  jid: string;      // e.g. "room-name@conference.chatghost.smartmall577.space"
  theme: string;
  description: string;
  participants: string[]; // List of user JIDs
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  from: string;     // Sender JID
  to: string;       // Recipient JID or Room JID
  body: string;
  timestamp: string;
  type: 'chat' | 'groupchat';
  senderName?: string; // Cache the sender display name for groupchat
}

export interface CallSession {
  id: string;
  from: string;     // Caller JID
  to: string;       // Callee JID or Room JID
  type: 'audio' | 'video';
  status: 'incoming' | 'outgoing' | 'connected' | 'ended';
  isGroup: boolean;
}
