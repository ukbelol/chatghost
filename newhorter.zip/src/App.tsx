import React, { useState, useEffect } from 'react';
import { User } from './types';
import XmppClient from './components/XmppClient';
import AdminPanel from './components/AdminPanel';
import LandingPage from './components/LandingPage';
import RegisterForm from './components/RegisterForm';
import ResetPasswordForm from './components/ResetPasswordForm';
import UserDashboard from './components/UserDashboard';
import { ShieldAlert, Key, UserCheck, MessageSquare, Terminal, Server, ExternalLink, ArrowLeft } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<'landing' | 'login' | 'register' | 'reset-password' | 'user-dashboard' | 'chat-client' | 'admin' | 'admin-login'>('landing');
  const [prevView, setPrevView] = useState<'landing' | 'login' | 'register' | 'reset-password' | 'user-dashboard' | 'chat-client' | 'admin' | 'admin-login'>('landing');

  // Login Form States
  const [jid, setJid] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Load user session on startup
  useEffect(() => {
    const path = window.location.pathname;
    const saved = localStorage.getItem('newhorter_session');
    
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setCurrentUser(parsed);
        if (parsed.role === 'admin') {
          setView('admin');
        } else {
          setView('user-dashboard');
        }
      } catch (err) {
        localStorage.removeItem('newhorter_session');
        if (path === '/admin-login') {
          setView('admin-login');
        } else {
          setView('landing');
        }
      }
    } else {
      if (path === '/admin-login') {
        setView('admin-login');
      } else {
        setView('landing');
      }
    }
  }, []);

  // Sync JID pre-filling on Admin Login view
  useEffect(() => {
    if (view === 'admin-login') {
      setJid('rgs577@chags.smartmall577.space');
      setError('');
    } else if (view === 'login') {
      setJid('');
      setError('');
    }
  }, [view]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!jid || !password) {
      setError('Por favor, preencha todos os campos.');
      setLoading(false);
      return;
    }

    const inputJid = jid.trim().toLowerCase();
    const isSuperAdminJid = inputJid === 'rgs577@chags.smartmall577.space' ||
                            inputJid === 'rgs577' ||
                            inputJid === 'rogermei577@gmail.com';

    if (isSuperAdminJid && view !== 'admin-login') {
      setError('Acesso de Super Admin detectado. Redirecionando para a página de login exclusiva...');
      setTimeout(() => {
        window.history.pushState(null, '', '/admin-login');
        setView('admin-login');
      }, 1500);
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ jid, password })
      });

      let data;
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        data = await res.json();
      } else {
        const text = await res.text();
        setError(`Erro do servidor (${res.status}): ${text.substring(0, 150)}`);
        setLoading(false);
        return;
      }

      if (!res.ok) {
        setError(data.error || 'Erro de autenticação.');
        setLoading(false);
        return;
      }

      setCurrentUser(data);
      localStorage.setItem('newhorter_session', JSON.stringify(data));
      
      if (data.role === 'admin') {
        window.history.pushState(null, '', '/');
        setView('admin');
      } else {
        setView('user-dashboard');
      }
    } catch (err: any) {
      setError(`Erro na requisição: ${err.message || 'Incapaz de alcançar o servidor. Verifique sua conexão.'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('newhorter_session');
    setJid('');
    setPassword('');
    setView('landing');
  };

  // ROUTER SWITCHBOARD
  if (view === 'landing') {
    return (
      <LandingPage 
        onEnterRestrictedArea={() => setView('login')} 
      />
    );
  }

  if (view === 'register') {
    return (
      <RegisterForm 
        onBack={() => setView('login')} 
        onRegisterSuccess={(user) => {
          setCurrentUser(user);
          localStorage.setItem('newhorter_session', JSON.stringify(user));
          setView(user.role === 'admin' ? 'admin' : 'user-dashboard');
        }}
        onGoToResetPassword={() => setView('reset-password')}
      />
    );
  }

  if (view === 'reset-password') {
    return (
      <ResetPasswordForm 
        onBack={() => setView('login')}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          localStorage.setItem('newhorter_session', JSON.stringify(user));
          setView(user.role === 'admin' ? 'admin' : 'user-dashboard');
        }}
      />
    );
  }

  if (view === 'user-dashboard' && currentUser) {
    return (
      <UserDashboard 
        currentUser={currentUser}
        onLogout={handleLogout}
        onEnterChat={() => setView('chat-client')}
      />
    );
  }

  if (view === 'chat-client' && currentUser) {
    return (
      <XmppClient 
        currentUser={currentUser} 
        onLogout={handleLogout} 
        onGoToAdmin={() => setView('admin')}
        onGoToDashboard={() => setView('user-dashboard')}
      />
    );
  }

  if (view === 'admin' && currentUser && currentUser.role === 'admin') {
    return (
      <AdminPanel 
        currentUser={currentUser} 
        onLogout={handleLogout} 
        onBackToClient={() => setView('chat-client')}
      />
    );
  }

  if (view === 'admin-login') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none" id="admin_login_portal_wrapper">
        <div className="absolute top-[-15%] left-[-10%] w-[60%] h-[60%] rounded-full bg-purple-600/10 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[-15%] right-[-10%] w-[60%] h-[60%] rounded-full bg-indigo-600/10 blur-[120px] pointer-events-none" />

        <button 
          onClick={() => {
            window.history.pushState(null, '', '/');
            setView('landing');
          }}
          className="absolute top-6 left-6 flex items-center gap-2 text-slate-400 hover:text-white text-xs font-semibold font-mono bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 transition cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>Voltar para Home</span>
        </button>

        <div className="w-full max-w-md bg-slate-900 border border-purple-900/30 rounded-3xl p-8 shadow-2xl z-10 space-y-6">
          <div className="text-center">
            <div className="mx-auto w-12 h-12 bg-purple-600/10 border border-purple-500/20 rounded-2xl flex items-center justify-center text-purple-400 mb-4 shadow-xl shadow-purple-950/20">
              <Key size={26} />
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Login do Super Admin</h1>
            <p className="text-slate-400 text-xs mt-1">Canal de acesso exclusivo para gerenciamento de rede</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-xs flex items-center gap-2">
                <ShieldAlert size={14} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 pl-1">
                JID do Administrador
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="rgs577@chags.smartmall577.space"
                  value={jid}
                  onChange={(e) => setJid(e.target.value)}
                  disabled={loading}
                  className="w-full bg-slate-950 border border-purple-950 focus:border-purple-500 focus:outline-none rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder:text-slate-750 transition font-mono"
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-purple-600">
                  <UserCheck size={16} />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 pl-1">
                Chave de Acesso Admin
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  className="w-full bg-slate-950 border border-purple-950 focus:border-purple-500 focus:outline-none rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder:text-slate-750 transition"
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-purple-600">
                  <Key size={16} />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm tracking-wide transition shadow-lg shadow-purple-950/60 disabled:opacity-50 disabled:cursor-not-allowed mt-2 cursor-pointer flex items-center justify-center gap-2 border border-purple-500/20"
            >
              {loading ? (
                <span>Autenticando Super Admin...</span>
              ) : (
                <>
                  <span>Acessar Painel Administrativo</span>
                  <ExternalLink size={14} />
                </>
              )}
            </button>
          </form>

          <div className="text-center pt-2">
            <button
              onClick={() => {
                window.history.pushState(null, '', '/');
                setView('login');
              }}
              className="text-xs text-slate-400 hover:text-slate-300 transition cursor-pointer hover:underline"
            >
              Área Geral do Cliente (Login)
            </button>
          </div>
        </div>

        <div className="mt-6 text-center text-[10px] text-slate-600 font-mono flex items-center gap-2 z-10 select-none">
          <span>CONSOLE: EXCLUSIVE SECURE GATEWAY</span>
        </div>
      </div>
    );
  }

  // Fallback: Login Portal
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none" id="login_portal_wrapper">
      
      {/* Visual background details */}
      <div className="absolute top-[-15%] left-[-10%] w-[60%] h-[60%] rounded-full bg-emerald-600/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-15%] right-[-10%] w-[60%] h-[60%] rounded-full bg-indigo-600/5 blur-[120px] pointer-events-none" />

      {/* Back to Home Button */}
      <button 
        onClick={() => setView('landing')}
        className="absolute top-6 left-6 flex items-center gap-2 text-slate-400 hover:text-white text-xs font-semibold font-mono bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 transition cursor-pointer"
      >
        <ArrowLeft size={14} />
        <span>Ir para Home</span>
      </button>

      {/* Main Container Card */}
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl z-10 space-y-6">
        
        {/* Branding Logo Header */}
        <div className="text-center">
          <div className="mx-auto w-12 h-12 bg-emerald-600/10 border border-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400 mb-4 shadow-xl shadow-emerald-950/20">
            <Server size={26} />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Área Restrita</h1>
          <p className="text-slate-400 text-xs mt-1">Insira seu e-mail ou nickname XMPP para conectar</p>
        </div>

        {/* Authentication Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          
          {error && (
            <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-xs flex items-center gap-2">
              <ShieldAlert size={14} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 pl-1">
              E-mail ou Nickname / JID
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Ex: roger577 ou roger@chags.smartmall577.space"
                value={jid}
                onChange={(e) => setJid(e.target.value)}
                disabled={loading}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-500 focus:outline-none rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder:text-slate-650 transition"
                required
              />
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-600">
                <UserCheck size={16} />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 pl-1">
              Senha de Segurança
            </label>
            <div className="relative">
              <input
                type="password"
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder:text-slate-650 transition"
                required
              />
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-600">
                <Key size={16} />
              </div>
            </div>
          </div>

          <button
            type="submit"
            id="btn_submit_login"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm tracking-wide transition shadow-lg shadow-emerald-950/60 disabled:opacity-50 disabled:cursor-not-allowed mt-2 cursor-pointer flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>Autenticando...</span>
            ) : (
              <>
                <span>Acessar Painel de Controle</span>
                <ExternalLink size={14} />
              </>
            )}
          </button>
        </form>

        {/* Create account trigger */}
        <div className="text-center pt-2 space-y-3">
          <button
            onClick={() => setView('register')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold transition hover:underline cursor-pointer block w-full text-center"
          >
            Não tem uma conta? Crie sua conta grátis (14 dias de teste)
          </button>
          <button
            onClick={() => setView('reset-password')}
            className="text-xs text-slate-400 hover:text-slate-300 font-semibold transition hover:underline cursor-pointer block w-full text-center pt-0.5"
          >
            Esqueceu sua senha? Redefinir aqui
          </button>
          <button
            onClick={() => {
              window.history.pushState(null, '', '/admin-login');
              setView('admin-login');
            }}
            className="text-xs text-purple-400 hover:text-purple-300 font-semibold transition hover:underline cursor-pointer block w-full text-center pt-1"
          >
            Acesso do Super Administrador (Painel)
          </button>
        </div>

      </div>

      {/* Mini technical footer */}
      <div className="mt-6 text-center text-[10px] text-slate-600 font-mono flex items-center gap-2 z-10 select-none">
        <span>SSL: SECURE TLS 1.3</span>
        <span>•</span>
        <span>MUC: ACTIVE</span>
        <span>•</span>
        <span>WebRTC: FULL-DUPLEX</span>
      </div>
    </div>
  );
}
