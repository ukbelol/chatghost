import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { 
  User as UserIcon, Shield, Key, Copy, Check, LogOut, 
  MessageSquare, Smartphone, Download, AlertTriangle, 
  CheckCircle, RefreshCw, XCircle, QrCode, CreditCard, ShieldAlert, Ghost
} from 'lucide-react';

interface UserDashboardProps {
  currentUser: User;
  onLogout: () => void;
  onEnterChat: () => void;
}

interface SubscriptionInfo {
  status: 'trial' | 'grace' | 'active' | 'blocked';
  daysUsed: number;
  daysRemaining: number;
  isBlocked: boolean;
  isTrial: boolean;
  isGrace: boolean;
  trialExpiresAt: string;
  graceExpiresAt: string;
  paymentExpiresAt: string;
}

interface ActivePayment {
  id: string;
  qrCode: string;
  qrCodeBase64: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
}

export default function UserDashboard({ currentUser, onLogout, onEnterChat }: UserDashboardProps) {
  // Profile edit states
  const [name, setName] = useState(currentUser.name || '');
  const [surname, setSurname] = useState(currentUser.surname || '');
  const [email, setEmail] = useState(currentUser.email || '');
  const [password, setPassword] = useState('');
  const [editLoading, setEditLoading] = useState(false);
  const [editSuccess, setEditSuccess] = useState(false);
  const [editError, setEditError] = useState('');

  // Subscription info state
  const [sub, setSub] = useState<SubscriptionInfo | null>(null);
  const [subLoading, setSubLoading] = useState(true);

  // Payment states
  const [activePayment, setActivePayment] = useState<ActivePayment | null>(null);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentCheckStatus, setPaymentCheckStatus] = useState<string>('');

  // General state
  const [copiedText, setCopiedText] = useState<{ [key: string]: boolean }>({});
  const [showPassword, setShowPassword] = useState(false);

  // Fetch subscription status
  const fetchSubscription = async () => {
    try {
      const res = await fetch(`/api/user/subscription-status/${currentUser.id}`);
      if (res.ok) {
        const data = await res.json();
        setSub(data);
      }
    } catch (err) {
      console.error('Error fetching subscription status:', err);
    } finally {
      setSubLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscription();
    // Refresh subscription status every 30 seconds
    const interval = setInterval(fetchSubscription, 30000);
    return () => clearInterval(interval);
  }, [currentUser.id]);

  // Check payment status periodically when pending
  useEffect(() => {
    if (!activePayment || activePayment.status === 'approved') return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/payments/status/${activePayment.id}`);
        if (res.ok) {
          const data = await res.json();
          if (data.status === 'approved') {
            setActivePayment(prev => prev ? { ...prev, status: 'approved' } : null);
            setPaymentCheckStatus('approved');
            fetchSubscription(); // Refresh user subscription immediately
            clearInterval(interval);
          }
        }
      } catch (err) {
        console.error('Error polling payment status:', err);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [activePayment?.id, activePayment?.status]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setEditLoading(true);
    setEditError('');
    setEditSuccess(false);

    try {
      const res = await fetch('/api/user/update-profile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: currentUser.id,
          name,
          surname,
          email,
          password: password || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao atualizar dados.');
      }

      setEditSuccess(true);
      // Update session storage details
      const session = localStorage.getItem('newhorter_session');
      if (session) {
        const parsed = JSON.parse(session);
        const updated = { ...parsed, name, surname, email };
        if (password) updated.password = password;
        localStorage.setItem('newhorter_session', JSON.stringify(updated));
      }
      
      // Let dashboard know
      currentUser.name = name;
      currentUser.surname = surname;
      currentUser.email = email;
      if (password) {
        currentUser.password = password;
        setPassword('');
      }

      setTimeout(() => setEditSuccess(false), 3000);
    } catch (err: any) {
      setEditError(err.message || 'Houve um erro.');
    } finally {
      setEditLoading(false);
    }
  };

  const handleCreatePayment = async () => {
    setPaymentLoading(true);
    setPaymentCheckStatus('pending');
    try {
      const res = await fetch('/api/payments/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId: currentUser.id })
      });

      if (res.ok) {
        const data = await res.json();
        setActivePayment(data);
      } else {
        setPaymentCheckStatus('error');
      }
    } catch (err) {
      setPaymentCheckStatus('error');
    } finally {
      setPaymentLoading(false);
    }
  };

  const handleMockApprove = async () => {
    if (!activePayment) return;
    try {
      const res = await fetch(`/api/payments/mock-approve/${activePayment.id}`, {
        method: 'POST'
      });
      if (res.ok) {
        setActivePayment(prev => prev ? { ...prev, status: 'approved' } : null);
        setPaymentCheckStatus('approved');
        fetchSubscription(); // update UI
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(prev => ({ ...prev, [key]: true }));
    setTimeout(() => {
      setCopiedText(prev => ({ ...prev, [key]: false }));
    }, 2000);
  };

  const formatDate = (isoStr: string) => {
    try {
      return new Date(isoStr).toLocaleDateString('pt-BR');
    } catch (e) {
      return isoStr;
    }
  };

  if (subLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white font-sans">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
        <span className="text-sm font-mono text-slate-400 mt-4">Verificando situação da assinatura...</span>
      </div>
    );
  }

  const isBlocked = sub ? sub.isBlocked : false;

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans p-4 md:p-6 select-none relative overflow-x-hidden" id="dashboard_root">
      {/* Background glow details */}
      <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto space-y-6 z-10 relative">
        
        {/* Header Bar */}
        <div className="bg-slate-900 border border-slate-800/80 rounded-3xl p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-indigo-600 flex items-center justify-center text-white font-bold text-xl shadow-xl shadow-emerald-950/20">
              {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-bold tracking-tight">Painel do Usuário</h1>
              <p className="text-slate-400 text-xs">Olá, {currentUser.name} {currentUser.surname || ''} — Nickname: <strong className="text-emerald-400">{currentUser.username}</strong></p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onLogout}
              className="px-4 py-2 bg-slate-950 hover:bg-red-950/40 border border-slate-800 hover:border-red-900/40 text-red-400 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer ml-auto sm:ml-0"
            >
              <LogOut size={13} />
              <span>Sair</span>
            </button>
          </div>
        </div>

        {/* Subscription / Status Alert Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Status Alert/Subscription Details */}
          <div className="bg-slate-900 border border-slate-800/80 rounded-3xl p-6 space-y-6 lg:col-span-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-200 flex items-center gap-2">
                <CreditCard size={18} className="text-emerald-400" />
                <span>Situação da Assinatura</span>
              </h2>
              
              {/* STATUS INDICATOR BUTTON WITH DAYS COUNTER */}
              {sub && (
                <div className="px-3.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl font-mono text-[10px] text-slate-400 flex items-center gap-2 shadow-inner">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Em uso: <strong>{sub.daysUsed} dias</strong></span>
                  <span className="text-slate-700">|</span>
                  <span>Faltam: <strong className="text-emerald-400">{sub.daysRemaining} dias</strong> para fatura</span>
                </div>
              )}
            </div>

            {sub && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-7 space-y-3">
                  
                  {/* Visual Status Badges */}
                  {sub.status === 'trial' && (
                    <div className="p-4 bg-emerald-950/30 border border-emerald-900/30 rounded-2xl flex gap-3.5">
                      <CheckCircle className="text-emerald-400 shrink-0 mt-0.5" size={20} />
                      <div>
                        <h3 className="text-sm font-bold text-emerald-400">Modo Teste Gratuito de 14 Dias</h3>
                        <p className="text-xs text-slate-400 leading-relaxed mt-1">
                          Sua conta está operando no período de testes grátis. Você pode usar todos os recursos sem restrições até <strong>{formatDate(sub.trialExpiresAt)}</strong>.
                        </p>
                      </div>
                    </div>
                  )}

                  {sub.status === 'active' && (
                    <div className="p-4 bg-indigo-950/30 border border-indigo-900/30 rounded-2xl flex gap-3.5">
                      <CheckCircle className="text-indigo-400 shrink-0 mt-0.5" size={20} />
                      <div>
                        <h3 className="text-sm font-bold text-indigo-400">Assinatura Ativa & Quitada</h3>
                        <p className="text-xs text-slate-400 leading-relaxed mt-1">
                          Sua manutenção mensal de R$ 15,00 está em dia! Acesso completo liberado para chats e conferências XMPP até <strong>{formatDate(sub.paymentExpiresAt)}</strong>.
                        </p>
                      </div>
                    </div>
                  )}

                  {sub.status === 'grace' && (
                    <div className="p-4 bg-amber-950/30 border border-amber-900/30 rounded-2xl flex gap-3.5">
                      <AlertTriangle className="text-amber-400 shrink-0 mt-0.5" size={20} />
                      <div>
                        <h3 className="text-sm font-bold text-amber-400">Prazo de Renovação (Prazo de 3 dias)</h3>
                        <p className="text-xs text-slate-400 leading-relaxed mt-1">
                          A data de renovação de sua assinatura chegou. Você tem um <strong>prazo de tolerância de 3 dias</strong> até <strong>{formatDate(sub.graceExpiresAt)}</strong> para quitar a mensalidade de R$15. Após esse prazo, seu acesso será bloqueado.
                        </p>
                      </div>
                    </div>
                  )}

                  {sub.status === 'blocked' && (
                    <div className="p-4 bg-red-950/30 border border-red-900/30 rounded-2xl flex gap-3.5">
                      <XCircle className="text-red-400 shrink-0 mt-0.5" size={20} />
                      <div>
                        <h3 className="text-sm font-bold text-red-400">Acesso Temporariamente Bloqueado</h3>
                        <p className="text-xs text-slate-400 leading-relaxed mt-1">
                          A tolerância de 3 dias de renovação expirou sem quitação. Seu login de chat está bloqueado. Efetue o pagamento da taxa de R$ 15,00 via PIX para desbloquear imediatamente.
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="pt-2">
                    <button
                      onClick={onEnterChat}
                      disabled={isBlocked}
                      className={`w-full py-3.5 rounded-xl font-bold text-sm tracking-wide transition flex items-center justify-center gap-2 ${
                        isBlocked 
                          ? 'bg-slate-950 border border-slate-800 text-slate-600 cursor-not-allowed' 
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/40 cursor-pointer'
                      }`}
                    >
                      <MessageSquare size={16} />
                      <span>{isBlocked ? 'Área de Chat Bloqueada (Pague para usar)' : 'Acessar Área de Chat (XmppClient)'}</span>
                    </button>
                    {isBlocked && (
                      <p className="text-[10px] text-red-400/80 mt-1.5 pl-1 italic text-center">
                        * O acesso será desbloqueado de forma instantânea assim que o pagamento do PIX for processado.
                      </p>
                    )}
                  </div>
                </div>

                {/* Right Column: Checkout or Payment Details */}
                <div className="md:col-span-5 bg-slate-950 border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-center items-center text-center space-y-4 min-h-[220px]">
                  
                  {!activePayment ? (
                    <div className="space-y-3 w-full">
                      <QrCode className="mx-auto text-slate-600" size={32} />
                      <div>
                        <span className="text-[11px] uppercase tracking-widest text-slate-500 font-mono font-bold block">Mensalidade</span>
                        <span className="text-2xl font-black text-white font-mono block mt-0.5">R$ 15,00</span>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-relaxed max-w-[180px] mx-auto">
                        Pague usando PIX (QR Code ou copia/cola) processado via Mercado Pago.
                      </p>
                      <button
                        onClick={handleCreatePayment}
                        disabled={paymentLoading}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                      >
                        {paymentLoading ? 'Gerando PIX...' : 'Pagar Manutenção R$15'}
                      </button>
                    </div>
                  ) : activePayment.status === 'approved' ? (
                    <div className="space-y-3 py-6">
                      <CheckCircle className="mx-auto text-emerald-400 animate-bounce" size={42} />
                      <div>
                        <h4 className="text-sm font-bold text-white">Pagamento Aprovado!</h4>
                        <p className="text-xs text-slate-400 mt-1">Sua assinatura foi renovada por mais 30 dias com sucesso.</p>
                      </div>
                      <button
                        onClick={() => {
                          setActivePayment(null);
                          setPaymentCheckStatus('');
                        }}
                        className="px-4 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg text-xs font-mono"
                      >
                        Fazer Nova Recarga
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4 w-full">
                      <div className="flex items-center justify-between w-full border-b border-slate-900 pb-2">
                        <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider">PIX Pendente</span>
                        <span className="text-[10px] text-slate-500 font-mono">ID: {activePayment.id.slice(0, 10)}...</span>
                      </div>

                      {/* Display QR Code */}
                      <div className="bg-white p-2.5 rounded-xl inline-block shadow-lg">
                        <img 
                          src={activePayment.qrCodeBase64} 
                          alt="PIX QR Code" 
                          className="w-32 h-32"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="space-y-2">
                        <button
                          onClick={() => handleCopy(activePayment.qrCode, 'pix')}
                          className="w-full py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                        >
                          {copiedText['pix'] ? (
                            <>
                              <Check size={12} className="text-emerald-400" />
                              <span>Copiado com Sucesso!</span>
                            </>
                          ) : (
                            <>
                              <Copy size={12} />
                              <span>Copiar PIX Copia e Cola</span>
                            </>
                          )}
                        </button>

                        {/* MOCK APPROVAL BUTTON FOR EVALUATION COMFORT */}
                        <button
                          onClick={handleMockApprove}
                          className="w-full py-2 bg-emerald-950/30 border border-emerald-900/40 hover:bg-emerald-950/50 text-emerald-400 font-bold text-[11px] rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <RefreshCw size={11} className="animate-spin" />
                          <span>Simular Aprovação (Sandbox)</span>
                        </button>
                      </div>

                      <div className="text-[9px] text-slate-500 font-mono flex items-center justify-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                        <span>Aguardando pagamento do PIX...</span>
                      </div>
                    </div>
                  )}

                </div>
              </div>
            )}
          </div>

          {/* Connection configuration steps */}
          <div className="bg-slate-900 border border-slate-800/80 rounded-3xl p-6 space-y-4">
            <h2 className="text-lg font-bold text-slate-200 flex items-center gap-2">
              <Smartphone size={18} className="text-indigo-400" />
              <span>Usar no Celular ou PC</span>
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              O seu login XMPP é aberto e funciona em qualquer app de conversas federado! Siga os passos:
            </p>

            <div className="space-y-3 pt-1">
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-xs text-slate-400 shrink-0 font-mono font-bold mt-0.5">
                  1
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-semibold text-white">Baixe o App XMPP</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    <strong>Conversations</strong> (Android), <strong>Dino</strong> (Linux), <strong>Gajim</strong> (Windows) ou <strong>ChatSecure</strong> (iOS).
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-xs text-slate-400 shrink-0 font-mono font-bold mt-0.5">
                  2
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-semibold text-white">Adicione sua Conta Existente</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Escolha a opção "Já possuo um login" e informe as credenciais abaixo:
                  </p>
                </div>
              </div>
            </div>

            {/* Connection coordinates box */}
            <div className="bg-slate-950 border border-slate-800/60 rounded-2xl p-3.5 space-y-2 font-mono text-[11px] shadow-inner">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Nickname / JID:</span>
                <span className="text-emerald-400 font-bold select-all">{currentUser.jid}</span>
              </div>
              <div className="flex items-center justify-between relative">
                <span className="text-slate-500">Senha:</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-300 font-bold select-all">
                    {showPassword ? currentUser.password : '••••••••••••'}
                  </span>
                  <button 
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[9px] text-slate-500 hover:text-white underline cursor-pointer"
                  >
                    {showPassword ? 'Ocultar' : 'Revelar'}
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Servidor (Host):</span>
                <span className="text-white select-all">chatghost.smartmall577.space</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Porta XMPP:</span>
                <span className="text-indigo-400 font-bold">5222</span>
              </div>
            </div>
          </div>

        </div>

        {/* Profile Settings Box */}
        <div className="bg-slate-900 border border-slate-800/80 rounded-3xl p-6 max-w-3xl">
          <h2 className="text-lg font-bold text-slate-200 flex items-center gap-2 mb-4">
            <UserIcon size={18} className="text-indigo-400" />
            <span>Editar Meus Dados de Cadastro</span>
          </h2>

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            {editError && (
              <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-xs flex items-center gap-2">
                <ShieldAlert size={14} className="shrink-0" />
                <span>{editError}</span>
              </div>
            )}

            {editSuccess && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle size={14} className="shrink-0" />
                <span>Cadastro atualizado com sucesso no servidor!</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider pl-1">Nome</label>
                <input
                  type="text"
                  placeholder="Seu nome"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider pl-1">Sobrenome</label>
                <input
                  type="text"
                  placeholder="Seu sobrenome"
                  value={surname}
                  onChange={(e) => setSurname(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider pl-1">E-mail de Login</label>
              <input
                type="email"
                placeholder="seuemail@exemplo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider pl-1">Nova Senha (deixe em branco se não desejar resetar)</label>
              <input
                type="password"
                placeholder="Resetar senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white"
              />
            </div>

            <button
              type="submit"
              disabled={editLoading}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition shadow-lg shadow-indigo-950/35 cursor-pointer disabled:opacity-50"
            >
              {editLoading ? 'Salvando...' : 'Atualizar Meus Dados'}
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
