import React, { useState } from 'react';
import { Check, X, ChevronRight, UserPlus, ArrowLeft, Mail, Lock, Shield, Sparkles, Calendar, FileText, KeyRound } from 'lucide-react';
import { User } from '../types';

interface RegisterFormProps {
  onBack: () => void;
  onRegisterSuccess: (user: User) => void;
  onGoToResetPassword?: () => void;
}

export default function RegisterForm({ onBack, onRegisterSuccess, onGoToResetPassword }: RegisterFormProps) {
  // Step 1: Nickname
  const [nickname, setNickname] = useState('');
  const [checkingNickname, setCheckingNickname] = useState(false);
  const [nicknameChecked, setNicknameChecked] = useState(false);
  const [nicknameAvailable, setNicknameAvailable] = useState<boolean | null>(null);
  const [nicknameError, setNicknameError] = useState('');

  // Step 2: Remaining fields (locked until nickname is verified)
  const [name, setName] = useState('');
  const [surname, setSurname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [cpf, setCpf] = useState('');

  // Global submit
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [duplicateCpfEmail, setDuplicateCpfEmail] = useState('');

  const validateCPF = (val: string) => {
    const clean = val.replace(/[^\d]/g, '');
    if (clean.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(clean)) return false;
    let sum = 0;
    let rem;
    for (let i = 1; i <= 9; i++) sum += parseInt(clean.substring(i - 1, i)) * (11 - i);
    rem = (sum * 10) % 11;
    if (rem === 10 || rem === 11) rem = 0;
    if (rem !== parseInt(clean.substring(9, 10))) return false;
    sum = 0;
    for (let i = 1; i <= 10; i++) sum += parseInt(clean.substring(i - 1, i)) * (12 - i);
    rem = (sum * 10) % 11;
    if (rem === 10 || rem === 11) rem = 0;
    if (rem !== parseInt(clean.substring(10, 11))) return false;
    return true;
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const clean = rawVal.replace(/[^\d]/g, '');
    let formatted = clean;
    if (clean.length > 3) {
      formatted = `${clean.slice(0, 3)}.${clean.slice(3)}`;
    }
    if (clean.length > 6) {
      formatted = `${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6)}`;
    }
    if (clean.length > 9) {
      formatted = `${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6, 9)}-${clean.slice(9, 11)}`;
    }
    setCpf(formatted.slice(0, 14));
  };

  const checkNicknameAvailability = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname) return;

    setCheckingNickname(true);
    setNicknameError('');
    setNicknameAvailable(null);
    setNicknameChecked(false);

    try {
      const res = await fetch('/api/check-nickname', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nickname })
      });

      if (!res.ok) {
        throw new Error('Falha ao verificar nickname.');
      }

      const data = await res.json();
      if (data.available) {
        setNicknameAvailable(true);
      } else {
        setNicknameAvailable(false);
        setNicknameError('Este nickname já está em uso, por favor informe outro diferente.');
      }
      setNicknameChecked(true);
    } catch (err: any) {
      setNicknameError('Erro na conexão com o servidor.');
    } finally {
      setCheckingNickname(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nicknameAvailable) return;

    setSubmitError('');
    setDuplicateCpfEmail('');

    // CPF Client-side Validation
    if (!validateCPF(cpf)) {
      setSubmitError('CPF inválido. Por favor, verifique os dígitos informados.');
      return;
    }

    if (!birthDate) {
      setSubmitError('Por favor, informe sua data de nascimento.');
      return;
    }

    setSubmitting(true);

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          nickname,
          name,
          surname,
          email,
          password,
          birthDate,
          cpf
        })
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.error === 'CPF_DUPLICATE') {
          setDuplicateCpfEmail(data.maskedEmail);
          throw new Error(data.message || 'Já existe um cadastro com este CPF.');
        }
        throw new Error(data.error || 'Erro ao efetuar cadastro.');
      }

      // Automatically log in using automatic route using email/password as requested:
      // "ao finalizar o cadastro crie uma rota com redirecionamento para login automatico usando e-mail e senha"
      const loginRes = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          jid: email, // Can login using email
          password: password
        })
      });

      if (!loginRes.ok) {
        // Fallback: use register return data if automatic login fails for some reason
        onRegisterSuccess(data);
        return;
      }

      const loginData = await loginRes.json();
      onRegisterSuccess(loginData);

    } catch (err: any) {
      setSubmitError(err.message || 'Houve um erro no processamento do cadastro.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none" id="register_portal_wrapper">
      
      {/* Background ambient details */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-emerald-600/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-600/5 blur-[120px] pointer-events-none" />

      {/* Back button */}
      <button 
        onClick={onBack}
        className="absolute top-6 left-6 flex items-center gap-2 text-slate-400 hover:text-white text-xs font-semibold font-mono bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 transition cursor-pointer"
      >
        <ArrowLeft size={14} />
        <span>Voltar ao Login</span>
      </button>

      {/* Register Card */}
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl z-10 space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <div className="mx-auto w-10 h-10 bg-indigo-600/10 border border-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400 mb-3 shadow-xl">
            <UserPlus size={20} />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">Criar Conta XMPP</h1>
          <p className="text-slate-400 text-xs mt-1">Siga as etapas para registrar seu login seguro</p>
        </div>

        {/* Step 1: Nickname verification */}
        <div className="space-y-4">
          <form onSubmit={checkNicknameAvailability} className="space-y-1.5">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">
              Etapa 1: Defina seu Nickname único (ID de Usuário)
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Ex: roger577"
                  value={nickname}
                  onChange={(e) => {
                    setNickname(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, ''));
                    setNicknameChecked(false);
                    setNicknameAvailable(null);
                  }}
                  disabled={nicknameAvailable === true}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl pl-4 pr-3 py-3 text-sm text-white font-mono placeholder:text-slate-700 transition"
                  required
                />
                {nicknameAvailable === true && (
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-emerald-400">
                    <Check size={16} />
                  </div>
                )}
              </div>
              
              {nicknameAvailable !== true && (
                <button
                  type="submit"
                  disabled={checkingNickname || !nickname}
                  className="px-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {checkingNickname ? 'Verificando...' : 'Verificar'}
                  <ChevronRight size={14} />
                </button>
              )}
            </div>
            
            {/* Nickname Verification Messages */}
            {nicknameError && (
              <p className="text-xs text-red-400 font-medium pl-1">{nicknameError}</p>
            )}

            {nicknameAvailable === true && (
              <div className="p-2.5 bg-emerald-950/20 border border-emerald-900/30 rounded-xl text-[11px] text-emerald-400 flex items-center gap-2">
                <Sparkles size={12} />
                <span>Nickname <strong>{nickname}</strong> está disponível! Endereço: <strong>{nickname}@chags.smartmall577.space</strong></span>
              </div>
            )}
          </form>
        </div>

        {/* Step 2: Full details form (Unlocked only when nickname is available) */}
        <div className={`transition-all duration-300 ${nicknameAvailable === true ? 'opacity-100' : 'opacity-30 pointer-events-none'}`}>
          <form onSubmit={handleRegister} className="space-y-4">
            
            {submitError && (
              <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-xs space-y-2">
                <div className="flex items-center gap-2">
                  <Shield size={14} className="shrink-0" />
                  <span className="font-medium">{submitError}</span>
                </div>
                {duplicateCpfEmail && onGoToResetPassword && (
                  <div className="pt-2 border-t border-red-900/20">
                    <button
                      type="button"
                      onClick={onGoToResetPassword}
                      className="w-full py-2 bg-indigo-900 hover:bg-indigo-800 border border-indigo-700 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <KeyRound size={12} />
                      <span>Recuperar Acesso / Redefinir Senha</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Nome</label>
                <input
                  type="text"
                  placeholder="Nome"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-xs text-white"
                  required={nicknameAvailable === true}
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Sobrenome</label>
                <input
                  type="text"
                  placeholder="Sobrenome"
                  value={surname}
                  onChange={(e) => setSurname(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-xs text-white"
                  required={nicknameAvailable === true}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Nascimento</label>
                <div className="relative">
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2 text-xs text-white"
                    required={nicknameAvailable === true}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">CPF</label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="000.000.000-00"
                    value={cpf}
                    onChange={handleCpfChange}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-xs text-white font-mono"
                    required={nicknameAvailable === true}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">E-mail de Login</label>
              <div className="relative">
                <input
                  type="email"
                  placeholder="exemplo@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl pl-4 pr-10 py-2.5 text-xs text-white"
                  required={nicknameAvailable === true}
                />
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-600">
                  <Mail size={14} />
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Senha Segura</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl pl-4 pr-10 py-2.5 text-xs text-white"
                  required={nicknameAvailable === true}
                />
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-600">
                  <Lock size={14} />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting || nicknameAvailable !== true}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-bold text-xs tracking-wide rounded-xl transition shadow-lg shadow-indigo-950/50 disabled:opacity-50 disabled:cursor-not-allowed mt-2 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>{submitting ? 'Efetuando Registro...' : 'Concluir Cadastro & Acessar Painel'}</span>
            </button>
          </form>
        </div>

        {onGoToResetPassword && (
          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={onGoToResetPassword}
              className="text-[11px] text-slate-400 hover:text-white font-medium hover:underline transition cursor-pointer"
            >
              Esqueceu sua senha? Recupere aqui
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
