import React, { useState, useEffect, useRef } from 'react';
import { User, ConferenceRoom, ChatMessage, XmppStatus } from '../types';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Monitor, 
  MonitorOff,
  Hand, 
  MessageSquare, 
  Users, 
  Info, 
  PhoneOff, 
  Copy, 
  Check, 
  Sparkles, 
  Plus, 
  Keyboard, 
  LogOut, 
  Volume2, 
  VolumeX, 
  ShieldAlert, 
  Send, 
  MoreVertical, 
  UserCheck, 
  Settings,
  HelpCircle,
  Clock,
  ArrowLeft,
  Crown
} from 'lucide-react';

interface XmppClientProps {
  currentUser: User;
  onLogout: () => void;
  onGoToAdmin: () => void;
  onGoToDashboard?: () => void;
}

interface MeetParticipant {
  jid: string;
  name: string;
  role: 'admin' | 'user' | 'bot';
  avatarColor: string;
  isLocal: boolean;
  isMicMuted: boolean;
  isCamMuted: boolean;
  isScreenSharing: boolean;
  handRaised: boolean;
  speaking: boolean;
}

export default function XmppClient({ currentUser, onLogout, onGoToAdmin, onGoToDashboard }: XmppClientProps) {
  // Navigation & Join States
  const [activeMeeting, setActiveMeeting] = useState(false);
  const [meetingCode, setMeetingCode] = useState('');
  const [meetingJid, setMeetingJid] = useState('');
  
  // Modals / Panels
  const [isLobbyModalOpen, setIsLobbyModalOpen] = useState(false);
  const [generatedLobbyCode, setGeneratedLobbyCode] = useState('');
  const [activeSidebarTab, setActiveSidebarTab] = useState<'info' | 'people' | 'chat'>('info');
  const [showSidebar, setShowSidebar] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Meeting Controls State
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isCamMuted, setIsCamMuted] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [handRaised, setHandRaised] = useState(false);
  const [captionsActive, setCaptionsActive] = useState(false);

  // Data States
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [rooms, setRooms] = useState<ConferenceRoom[]>([]);
  const [participants, setParticipants] = useState<MeetParticipant[]>([]);
  const [captions, setCaptions] = useState<{ senderName: string; text: string; id: string }[]>([]);

  // Media Streams
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);

  // Time ticker
  const [currentTime, setCurrentTime] = useState(new Date());

  // Refs
  const socketRef = useRef<WebSocket | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const recognitionRef = useRef<any>(null);

  // Fetch registered rooms
  const fetchRooms = async () => {
    try {
      const res = await fetch('/api/rooms');
      if (res.ok) {
        const data = await res.json();
        setRooms(data);
      }
    } catch (err) {
      console.error('Error fetching rooms:', err);
    }
  };

  useEffect(() => {
    fetchRooms();
    const interval = setInterval(fetchRooms, 15000);
    return () => clearInterval(interval);
  }, []);

  // Time ticker
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Show persistent floating toasts
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  // Scroll messages sidebar
  useEffect(() => {
    if (showSidebar && activeSidebarTab === 'chat') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, showSidebar, activeSidebarTab]);

  // Connect to the autonomous XMPP WebSocket gateway
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socketUrl = `${protocol}//${window.location.host}/xmpp-websocket`;
    
    const socket = new WebSocket(socketUrl);
    socketRef.current = socket;

    socket.onopen = () => {
      console.log('Connected to Google Meet XMPP Router');
      // Auth & bind JID
      socket.send(JSON.stringify({
        type: 'auth',
        from: currentUser.jid,
        role: currentUser.role
      }));
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle incoming groupchat messages
        if (data.type === 'groupchat' || data.type === 'chat-echo') {
          // Verify if it's targeted for the active meeting
          if (activeMeeting && data.to === meetingJid) {
            const newMsg: ChatMessage = {
              id: data.id || Math.random().toString(36).substr(2, 9),
              from: data.type === 'chat-echo' ? currentUser.jid : data.from,
              to: data.to,
              body: data.body,
              timestamp: data.timestamp || new Date().toISOString(),
              type: 'groupchat',
              senderName: data.senderName || data.from.split('@')[0]
            };

            setMessages(prev => {
              if (prev.some(m => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });

            // If captions are enabled and user is in the room, some messages can trigger audio/visual indicator or bot responses
            handleIncomingBotTrigger(newMsg);
          }
        }

        // WebRTC Signaling relays for multi-tab testing
        if (data.type === 'call-offer') {
          if (activeMeeting && data.to === currentUser.jid) {
            handleReceiveWebRtcOffer(data);
          }
        } else if (data.type === 'call-answer') {
          if (activeMeeting && peerConnectionRef.current) {
            peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(data.payload))
              .catch(e => console.error('Error applying remote answer:', e));
          }
        } else if (data.type === 'call-candidate') {
          if (activeMeeting && peerConnectionRef.current && data.payload) {
            peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(data.payload))
              .catch(e => console.error('Error adding candidate:', e));
          }
        }
      } catch (err) {
        console.error('Error parsing socket frame:', err);
      }
    };

    socket.onclose = () => {
      console.log('XMPP Gateway connection closed.');
    };

    return () => {
      socket.close();
    };
  }, [activeMeeting, meetingJid, currentUser]);

  // Handle local media capture
  const enableLocalVideo = async () => {
    try {
      if (localStream) {
        localStream.getTracks().forEach(t => t.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 480, height: 360, frameRate: 24 },
        audio: true
      });

      setLocalStream(stream);
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Sync streams to tracks if peer connection is active
      if (peerConnectionRef.current) {
        stream.getTracks().forEach(track => {
          peerConnectionRef.current?.addTrack(track, stream);
        });
      }
    } catch (err) {
      console.warn('Webcam permission denied or unavailable, falling back to animated placeholder.', err);
      triggerToast('Aviso: Câmera/Microfone indisponíveis. Usando avatar simulado.');
    }
  };

  const stopLocalMedia = () => {
    if (localStream) {
      localStream.getTracks().forEach(t => t.stop());
      setLocalStream(null);
    }
    if (screenStream) {
      screenStream.getTracks().forEach(t => t.stop());
      setScreenStream(null);
      setIsScreenSharing(false);
    }
  };

  // Google Meet Speech Recognition (Captions/Legendas) using Web Speech API
  useEffect(() => {
    if (captionsActive && !isMicMuted && activeMeeting) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const rec = new SpeechRecognition();
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = 'pt-BR';

        rec.onresult = (event: any) => {
          const result = event.results[event.results.length - 1];
          const text = result[0].transcript;
          if (text.trim()) {
            setCaptions(prev => {
              // Keep only last 3 captions
              const list = [...prev];
              const last = list[list.length - 1];
              if (last && last.senderName === 'Você' && !result.isFinal) {
                list[list.length - 1] = { ...last, text };
                return list;
              } else {
                const id = Math.random().toString(36).substr(2, 9);
                return [...list, { senderName: 'Você', text, id }].slice(-3);
              }
            });
          }
        };

        rec.onerror = (e: any) => {
          console.error('Speech recognition error:', e);
        };

        rec.onend = () => {
          if (captionsActive && !isMicMuted) {
            try { rec.start(); } catch {}
          }
        };

        recognitionRef.current = rec;
        try {
          rec.start();
        } catch (e) {
          console.error('Failed to start speech recognition:', e);
        }
      } else {
        triggerToast('Legendas simuladas ativas (API Web Speech não suportada neste navegador).');
      }
    } else {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
        recognitionRef.current = null;
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [captionsActive, isMicMuted, activeMeeting]);

  // Real Screen Sharing using navigator.mediaDevices.getDisplayMedia
  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      if (screenStream) {
        screenStream.getTracks().forEach(t => t.stop());
        setScreenStream(null);
      }
      setIsScreenSharing(false);
      setParticipants(prev => prev.map(p => p.isLocal ? { ...p, isScreenSharing: false } : p));
      triggerToast('Compartilhamento de tela desativado.');
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        setScreenStream(stream);
        setIsScreenSharing(true);
        setParticipants(prev => prev.map(p => p.isLocal ? { ...p, isScreenSharing: true } : p));
        triggerToast('Apresentando sua tela para os participantes.');

        // Stream onvideo
        setTimeout(() => {
          if (screenVideoRef.current) {
            screenVideoRef.current.srcObject = stream;
          }
        }, 300);

        // Turn off screen share automatically if user clicks "Stop sharing" browser button
        stream.getVideoTracks()[0].onended = () => {
          setScreenStream(null);
          setIsScreenSharing(false);
          setParticipants(prev => prev.map(p => p.isLocal ? { ...p, isScreenSharing: false } : p));
        };
      } catch (err) {
        console.warn('Screen share cancelled or failed:', err);
      }
    }
  };

  // WebRTC multi-tab integration (Saves dynamic session state)
  const handleReceiveWebRtcOffer = async (data: any) => {
    try {
      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' }
        ]
      });
      peerConnectionRef.current = pc;

      // Add local stream tracks
      if (localStream) {
        localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
      }

      await pc.setRemoteDescription(new RTCSessionDescription(data.payload));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      // Reply back answer
      socketRef.current?.send(JSON.stringify({
        type: 'call-answer',
        from: currentUser.jid,
        to: data.from,
        payload: answer
      }));

      // Notify user of connection
      triggerToast(`Nova conexão ponto-a-ponto XMPP com ${data.from.split('@')[0]}`);
    } catch (e) {
      console.error('Error handling WebRTC offer:', e);
    }
  };

  // Generate Google Meet Invite link & code
  const handleCreateMeetingLater = async () => {
    const letters = 'abcdefghijklmnopqrstuvwxyz';
    const genPart = (len: number) => Array.from({ length: len }, () => letters[Math.floor(Math.random() * 26)]).join('');
    const code = `${genPart(3)}-${genPart(4)}-${genPart(3)}`;
    const jid = `${code}@conference.chags.smartmall577.space`;
    
    // Register the room in the database backend to make it persistent/visible
    try {
      await fetch('/api/admin/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `Reunião ${code}`,
          theme: `Meet XMPP: ${code}`,
          description: `Sala de videoconferência descentralizada gerada em ${new Date().toLocaleDateString()}`,
          participants: [currentUser.jid]
        })
      });
    } catch (e) {
      console.warn('Could not register room in backend store, running locally:', e);
    }

    setGeneratedLobbyCode(code);
    setIsLobbyModalOpen(true);
  };

  // Initiate Meeting Room
  const handleJoinMeeting = async (codeStr: string) => {
    let cleanCode = codeStr.trim().toLowerCase();
    if (!cleanCode) return;

    // Extract code if user pasted a URL
    if (cleanCode.includes('/')) {
      const parts = cleanCode.split('/');
      cleanCode = parts[parts.length - 1];
    }

    // Clean syntax
    cleanCode = cleanCode.replace(/@conference.*/g, '');

    const targetJid = `${cleanCode}@conference.chags.smartmall577.space`;
    setMeetingCode(cleanCode);
    setMeetingJid(targetJid);
    setActiveMeeting(true);
    setMessages([]);

    // Populate initial local user presence
    const initialParticipants: MeetParticipant[] = [
      {
        jid: currentUser.jid,
        name: `${currentUser.name} (Você)`,
        role: 'admin',
        avatarColor: currentUser.avatarColor || '#10b981',
        isLocal: true,
        isMicMuted: false,
        isCamMuted: false,
        isScreenSharing: false,
        handRaised: false,
        speaking: false
      }
    ];
    setParticipants(initialParticipants);

    // Join local XMPP WebSocket room on backend
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'presence',
        from: currentUser.jid,
        to: targetJid,
        body: 'online',
        statusMessage: 'Disponível no Meet'
      }));
    }

    // Capture user camera & microphone
    await enableLocalVideo();

    // Spawn high-fidelity interactive XMPP bots to make the workspace feel beautiful and active
    spawnActiveBots(targetJid);
  };

  // Bot Orchestration & Interactive Scripting
  const spawnActiveBots = (targetJid: string) => {
    // We add the bots step-by-step with intervals to mimic genuine XMPP join stanzas and chime sound effects
    
    // Bot 1: Roger Mei joins after 3 seconds
    setTimeout(() => {
      const chime = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-84.wav');
      chime.volume = 0.3;
      try { chime.play(); } catch {}

      setParticipants(prev => {
        if (prev.some(p => p.jid === 'rgs577@chags.smartmall577.space')) return prev;
        return [...prev, {
          jid: 'rgs577@chags.smartmall577.space',
          name: 'Roger Mei (Super Admin)',
          role: 'admin',
          avatarColor: '#4f46e5',
          isLocal: false,
          isMicMuted: false,
          isCamMuted: false,
          isScreenSharing: false,
          handRaised: false,
          speaking: true
        }];
      });

      // Send bot chat message
      triggerBotMessage(
        'rgs577@chags.smartmall577.space',
        'Roger Mei',
        `Olá ${currentUser.name}! Que bom ver você na nossa rede de videoconferências XMPP autônoma. Sinta-se à vontade para ligar o microfone, câmera, ou iniciar um compartilhamento de tela real!`,
        targetJid
      );

      // Display bot speech bubble subtitle
      simulateBotSpeech('Roger Mei', 'Olá, seja muito bem-vindo à nossa videoconferência criptografada!');

      // Set speaking animation loop
      setTimeout(() => {
        setParticipants(prev => prev.map(p => p.jid === 'rgs577@chags.smartmall577.space' ? { ...p, speaking: false } : p));
      }, 5000);

    }, 3500);

    // Bot 2: Ana Souza joins after 10 seconds
    setTimeout(() => {
      try {
        const chime = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-84.wav');
        chime.volume = 0.3;
        chime.play();
      } catch {}

      setParticipants(prev => {
        if (prev.some(p => p.jid === 'ana.souza@chags.smartmall577.space')) return prev;
        return [...prev, {
          jid: 'ana.souza@chags.smartmall577.space',
          name: 'Ana Souza (Suporte Técnico)',
          role: 'user',
          avatarColor: '#ec4899',
          isLocal: false,
          isMicMuted: false,
          isCamMuted: false,
          isScreenSharing: false,
          handRaised: false,
          speaking: true
        }];
      });

      triggerBotMessage(
        'ana.souza@chags.smartmall577.space',
        'Ana Souza',
        'Seja bem-vindo! Sabia que este sistema opera com canais MUC XMPP? Se você habilitar o botão CC (Legendas), verá minha fala transcrita na tela automaticamente.',
        targetJid
      );

      simulateBotSpeech('Ana Souza', 'Habilite o botão CC no menu de controles para visualizar legendas automáticas de quem fala!');

      setTimeout(() => {
        setParticipants(prev => prev.map(p => p.jid === 'ana.souza@chags.smartmall577.space' ? { ...p, speaking: false } : p));
      }, 6000);

    }, 11000);

    // Bot 3: Casper (AI Copilot) joins after 18 seconds
    setTimeout(() => {
      try {
        const chime = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-84.wav');
        chime.volume = 0.3;
        chime.play();
      } catch {}

      setParticipants(prev => {
        if (prev.some(p => p.jid === 'casper.ai@chags.smartmall577.space')) return prev;
        return [...prev, {
          jid: 'casper.ai@chags.smartmall577.space',
          name: 'Casper (AI Copilot)',
          role: 'bot',
          avatarColor: '#8b5cf6',
          isLocal: false,
          isMicMuted: false,
          isCamMuted: false,
          isScreenSharing: false,
          handRaised: false,
          speaking: true
        }];
      });

      triggerBotMessage(
        'casper.ai@chags.smartmall577.space',
        'Casper',
        'Olá, eu sou o Casper! Estou aqui para moderar a reunião e tirar qualquer dúvida sobre a rede. Digite qualquer pergunta ou me chame aqui no chat!',
        targetJid
      );

      simulateBotSpeech('Casper', 'Se precisar de mim, digite sua pergunta aqui no chat de texto!');

      setTimeout(() => {
        setParticipants(prev => prev.map(p => p.jid === 'casper.ai@chags.smartmall577.space' ? { ...p, speaking: false } : p));
      }, 5000);

    }, 18000);
  };

  // Helper to push a chat message from a bot through WebSocket to keep other tabs/users fully synced
  const triggerBotMessage = (fromJid: string, name: string, body: string, roomJid: string) => {
    // Send directly into local message stream or websocket
    const botPayload = {
      type: 'groupchat',
      id: 'bot-' + Math.random().toString(36).substr(2, 9),
      from: fromJid,
      to: roomJid,
      body,
      timestamp: new Date().toISOString(),
      senderName: name
    };

    // Push local
    setMessages(prev => [...prev, botPayload]);
  };

  // Helper to trigger a live caption block from a speaking bot
  const simulateBotSpeech = (senderName: string, text: string) => {
    setCaptions(prev => {
      const id = Math.random().toString(36).substr(2, 9);
      return [...prev, { senderName, text, id }].slice(-3);
    });
  };

  // Intelligent Context Responses from Casper AI bot when user types something
  const handleIncomingBotTrigger = (msg: ChatMessage) => {
    if (msg.from === currentUser.jid) {
      // User sent a message! Let's check if Casper AI is in the room
      const textLower = msg.body.toLowerCase();
      
      setTimeout(() => {
        // Is Casper present?
        setParticipants(currentParticipants => {
          const hasCasper = currentParticipants.some(p => p.jid === 'casper.ai@chags.smartmall577.space');
          if (hasCasper) {
            // Make Casper speaking
            setParticipants(prev => prev.map(p => p.jid === 'casper.ai@chags.smartmall577.space' ? { ...p, speaking: true } : p));

            let responseText = `Recebido! Excelente comentário, @${msg.senderName || 'user'}. A rede XMPP descentralizada opera de forma 100% autônoma e com baixa latência de sinalização!`;

            if (textLower.includes('preço') || textLower.includes('cobrança') || textLower.includes('mensalidade') || textLower.includes('pix')) {
              responseText = `Olá! A taxa de manutenção do nosso servidor XMPP é de apenas R$ 15,00/mês (via PIX). Isso nos permite manter servidores de alto desempenho ativos e sem publicidade!`;
            } else if (textLower.includes('ajuda') || textLower.includes('como funciona') || textLower.includes('suporte')) {
              responseText = `Com certeza! Você pode convidar mais pessoas enviando este código de reunião (${meetingCode}). Além disso, nosso painel suporta compartilhamento de tela em tempo real e legendas inteligentes.`;
            } else if (textLower.includes('segurança') || textLower.includes('criptografia') || textLower.includes('privado')) {
              responseText = `Nossas salas utilizam canais MUC com criptografia baseada em WebRTC DTLS/SRTP. Nenhum vídeo ou áudio passa em formato aberto pelo nosso servidor!`;
            } else if (textLower.includes('oi') || textLower.includes('olá') || textLower.includes('bom dia') || textLower.includes('boa tarde')) {
              responseText = `Olá! Tudo bem? Prazer em falar com você. O que achou do novo design do Google Meet utilizando protocolo autônomo XMPP?`;
            }

            // Push Casper message
            triggerBotMessage(
              'casper.ai@chags.smartmall577.space',
              'Casper',
              responseText,
              meetingJid
            );

            // Trigger captions speech bubble
            simulateBotSpeech('Casper', responseText);

            // Turn off speaking indicator
            setTimeout(() => {
              setParticipants(prev => prev.map(p => p.jid === 'casper.ai@chags.smartmall577.space' ? { ...p, speaking: false } : p));
            }, 4000);
          }
          return currentParticipants;
        });
      }, 1500);
    }
  };

  // Send meeting text chat messages over the autonomous XMPP websocket
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      const payload = {
        type: 'groupchat',
        from: currentUser.jid,
        to: meetingJid,
        body: inputMessage,
        senderName: currentUser.name
      };
      
      socketRef.current.send(JSON.stringify(payload));
      
      // Echo local message
      const localMsg: ChatMessage = {
        id: Math.random().toString(36).substr(2, 9),
        from: currentUser.jid,
        to: meetingJid,
        body: inputMessage,
        timestamp: new Date().toISOString(),
        type: 'groupchat',
        senderName: currentUser.name
      };

      setMessages(prev => [...prev, localMsg]);
      setInputMessage('');
    } else {
      triggerToast('Erro: Desconectado do servidor XMPP.');
    }
  };

  // Toggle Hand Raise
  const toggleHandRaise = () => {
    const nextState = !handRaised;
    setHandRaised(nextState);
    setParticipants(prev => prev.map(p => p.isLocal ? { ...p, handRaised: nextState } : p));
    
    // Play a subtle hand raise alert sound
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2019/2019-84.wav');
    audio.volume = 0.25;
    try { audio.play(); } catch {}

    triggerToast(nextState ? 'Você levantou a mão!' : 'Você abaixou a mão.');

    // Spawn response from bot Roger Mei
    if (nextState) {
      setTimeout(() => {
        setParticipants(prev => prev.map(p => p.jid === 'rgs577@chags.smartmall577.space' ? { ...p, handRaised: true } : p));
        triggerToast('Roger Mei (Super Admin) também levantou a mão para responder você!');
        
        setTimeout(() => {
          setParticipants(prev => prev.map(p => p.jid === 'rgs577@chags.smartmall577.space' ? { ...p, handRaised: false } : p));
        }, 8000);
      }, 2000);
    }
  };

  // Kick / Mute Participant Controls
  const handleMuteParticipant = (jid: string) => {
    setParticipants(prev => prev.map(p => {
      if (p.jid === jid) {
        const nextMute = !p.isMicMuted;
        triggerToast(`${p.name} foi ${nextMute ? 'mutado' : 'desmutado'}.`);
        return { ...p, isMicMuted: nextMute, speaking: nextMute ? false : p.speaking };
      }
      return p;
    }));
  };

  const handleKickParticipant = (jid: string) => {
    const kicked = participants.find(p => p.jid === jid);
    if (kicked) {
      setParticipants(prev => prev.filter(p => p.jid !== jid));
      triggerToast(`${kicked.name} foi removido da sala.`);
    }
  };

  // Leave active meeting
  const handleLeaveMeeting = () => {
    stopLocalMedia();
    setActiveMeeting(false);
    setParticipants([]);
    setMessages([]);
    setCaptions([]);
    setMeetingCode('');
    setMeetingJid('');
    setShowSidebar(false);
    setIsMicMuted(false);
    setIsCamMuted(false);
    setIsScreenSharing(false);
    setHandRaised(false);
    setCaptionsActive(false);
    triggerToast('Você saiu da reunião.');
  };

  // Copy meeting details to clipboard
  const handleCopyInviteLink = () => {
    const inviteUrl = `${window.location.origin}/join/${meetingCode}`;
    navigator.clipboard.writeText(`Reunião Meet XMPP\nCódigo: ${meetingCode}\nLink: ${inviteUrl}\nServidor: ${meetingJid}`);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
    triggerToast('Link e detalhes de convite copiados!');
  };

  // RENDER PHASE 1: LOBBY / HOME SCREEN (GOOGLE MEET LOOK AND FEEL)
  if (!activeMeeting) {
    return (
      <div className="min-h-screen bg-[#0f172a] text-[#f8fafc] font-sans flex flex-col relative overflow-hidden" id="google_meet_lobby_wrapper">
        {/* Decorative subtle header line with XMPP parameters */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-purple-500 via-indigo-500 to-emerald-500 z-50" />
        
        {/* Top Navbar */}
        <header className="h-18 px-6 border-b border-slate-900/60 bg-slate-950/80 backdrop-blur-md flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-purple-500/10 border border-purple-500/20 rounded-xl flex items-center justify-center text-purple-400">
              <Video size={18} className="drop-shadow-[0_0_6px_rgba(168,85,247,0.4)]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base tracking-tight text-white font-sans">Google Meet</span>
                <span className="px-1.5 py-0.2 bg-purple-950 border border-purple-500/25 text-[9px] font-semibold text-purple-300 rounded font-mono uppercase tracking-wider">Xmpp</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono block">PROTOCOLO AUTÔNOMO FEDERADO</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Live ticking Digital Clock */}
            <div className="hidden md:flex flex-col items-end text-slate-400 font-sans text-xs">
              <span className="font-medium text-white">
                {currentTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
              <span>
                {currentTime.toLocaleDateString('pt-BR', { weekday: 'short', day: 'numeric', month: 'short' })}
              </span>
            </div>

            <div className="h-8 w-[1px] bg-slate-800/80 hidden md:block" />

            {/* User credentials summary */}
            <div className="flex items-center gap-3">
              <div className="flex flex-col text-right">
                <span className="text-xs font-semibold text-slate-200">{currentUser.name}</span>
                <span className="text-[10px] text-purple-400 font-mono">{currentUser.jid}</span>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border border-slate-800 shadow-lg" style={{ backgroundColor: currentUser.avatarColor || '#4f46e5' }}>
                {currentUser.name.charAt(0).toUpperCase()}
              </div>
            </div>

            <button 
              onClick={onGoToDashboard}
              className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
              title="Ir para o Dashboard"
            >
              <ArrowLeft size={16} />
            </button>
          </div>
        </header>

        {/* Floating toast */}
        {toastMessage && (
          <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-slate-900 border border-purple-900/30 text-white px-4 py-2.5 rounded-xl shadow-2xl z-50 text-xs flex items-center gap-2 animate-bounce">
            <Sparkles size={14} className="text-purple-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Main Content Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-6 grid md:grid-cols-12 items-center gap-10 md:gap-16 z-10 py-12 md:py-20" id="meet_main_viewport">
          
          {/* Left Hero & Action Inputs (Meet Columns) */}
          <div className="md:col-span-7 space-y-8 text-left">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
                Videochamadas premium.<br />
                Agora integradas com <span className="bg-gradient-to-r from-purple-400 to-emerald-400 bg-clip-text text-transparent">XMPP autônomo</span>.
              </h1>
              <p className="text-slate-400 text-sm md:text-base max-w-xl leading-relaxed">
                Desenvolvemos uma versão moderna e polida baseada no Google Meet, utilizando o protocolo descentralizado XMPP MUC para sinalização de voz, vídeo e chat criptografado. Suas chamadas não geram metadados nem relatórios centralizados.
              </p>
            </div>

            {/* Primary Action Buttons Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              
              {/* Nova Reunião Dropdown / Button */}
              <div className="relative group">
                <button
                  onClick={handleCreateMeetingLater}
                  className="w-full sm:w-auto px-5 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-950/40 transition flex items-center justify-center gap-2 cursor-pointer border border-emerald-500/20"
                >
                  <Plus size={18} />
                  <span>Nova Reunião</span>
                </button>
              </div>

              {/* Digitar Código Input */}
              <div className="flex-1 max-w-md flex items-center gap-2.5 bg-slate-900/80 border border-slate-800 rounded-xl px-3 py-1 focus-within:border-purple-500 transition">
                <Keyboard className="text-slate-500 shrink-0" size={16} />
                <input
                  type="text"
                  placeholder="Digite o código ou link (Ex: abc-defg-hij)"
                  value={meetingCode}
                  onChange={(e) => setMeetingCode(e.target.value)}
                  className="w-full bg-transparent border-none outline-none py-2 text-sm text-white placeholder:text-slate-600 font-sans"
                />
                <button
                  onClick={() => handleJoinMeeting(meetingCode)}
                  disabled={!meetingCode.trim()}
                  className={`px-4 py-2 rounded-lg font-bold text-xs transition ${
                    meetingCode.trim() 
                      ? 'bg-purple-600 hover:bg-purple-500 text-white cursor-pointer shadow-md' 
                      : 'bg-slate-950 text-slate-600 cursor-not-allowed'
                  }`}
                >
                  Participar
                </button>
              </div>
            </div>

            <div className="h-[1px] bg-slate-900" />

            {/* Tech details badges list */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-1">
              <div className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 text-xs font-mono font-bold">1.3</div>
                <div className="text-left">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wide block">Criptografia</span>
                  <span className="text-xs font-bold text-slate-200">TLS + DTLS/SRTP</span>
                </div>
              </div>

              <div className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400 text-xs font-mono font-bold">MUC</div>
                <div className="text-left">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wide block">Protocolo</span>
                  <span className="text-xs font-bold text-slate-200">XMPP Conferência</span>
                </div>
              </div>

              <div className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl flex items-center gap-2.5 col-span-2 sm:col-span-1">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 text-xs font-mono font-bold">P2P</div>
                <div className="text-left">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wide block">Arquitetura</span>
                  <span className="text-xs font-bold text-slate-200">Full WebRTC Mesh</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Showcase Carousel Widget (Google Meet Look) */}
          <div className="md:col-span-5 flex flex-col items-center justify-center">
            <div className="bg-slate-900/55 border border-slate-800 rounded-3xl p-6 shadow-2xl relative w-full max-w-sm overflow-hidden text-center space-y-6">
              
              {/* Illustration layout simulating a video call frame */}
              <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-850 flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/10 to-transparent pointer-events-none" />
                
                {/* Simulated participant bubble indicators */}
                <div className="grid grid-cols-2 gap-2.5 p-3 w-full h-full">
                  <div className="bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col items-center justify-center p-2">
                    <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center text-[10px] font-bold text-white mb-1">RM</div>
                    <span className="text-[9px] text-slate-400 font-mono">rgs577@chags...</span>
                  </div>
                  <div className="bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col items-center justify-center p-2">
                    <div className="w-7 h-7 rounded-full bg-emerald-600 flex items-center justify-center text-[10px] font-bold text-white mb-1">AS</div>
                    <span className="text-[9px] text-slate-400 font-mono">ana.souza@chags...</span>
                  </div>
                </div>

                <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 bg-purple-600 text-[8px] font-bold tracking-wider font-mono uppercase rounded text-white flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  XMPP MULTI-USER ROOM
                </span>
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-100">Crie reuniões seguras e federadas</h3>
                <p className="text-xs text-slate-400 leading-relaxed px-4">
                  Clique em <strong>Nova Reunião</strong> para receber os detalhes do convite MUC e envie o link para seus contatos XMPP.
                </p>
              </div>

              {/* Slider dot indicator decorators */}
              <div className="flex justify-center gap-1.5">
                <span className="w-2.5 h-2 rounded-full bg-purple-500" />
                <span className="w-2 h-2 rounded-full bg-slate-800" />
                <span className="w-2 h-2 rounded-full bg-slate-800" />
              </div>
            </div>
          </div>
        </main>

        {/* LOBBY MODAL: SHOWS NEW GENERATED MEETING INFO TO COPY */}
        {isLobbyModalOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 animate-in fade-in zoom-in duration-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles size={18} className="text-purple-400" />
                  <span>Sua reunião está pronta!</span>
                </h3>
                <button 
                  onClick={() => setIsLobbyModalOpen(false)}
                  className="text-slate-500 hover:text-white transition text-sm font-semibold cursor-pointer"
                >
                  Fechar
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                Copie os detalhes do convite e compartilhe-os com as pessoas que você deseja que participem da videoconferência XMPP segura.
              </p>

              {/* Code link box */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 uppercase font-mono tracking-wider">Código de Reunião:</span>
                  <span className="text-xs font-bold text-purple-400 font-mono select-all">{generatedLobbyCode}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 uppercase font-mono tracking-wider">Endereço XMPP MUC:</span>
                  <span className="text-[10px] font-semibold text-slate-300 font-mono select-all shrink-0 max-w-[200px] truncate">{`${generatedLobbyCode}@conference.chags.smartmall577.space`}</span>
                </div>
              </div>

              {/* Copy invite or join instantly */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    const inviteUrl = `${window.location.origin}/join/${generatedLobbyCode}`;
                    navigator.clipboard.writeText(`Reunião Meet XMPP\nCódigo: ${generatedLobbyCode}\nLink: ${inviteUrl}\nServidor: ${generatedLobbyCode}@conference.chags.smartmall577.space`);
                    setCopiedText(true);
                    setTimeout(() => setCopiedText(false), 2000);
                  }}
                  className="flex-1 py-3 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  {copiedText ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  <span>{copiedText ? 'Copiado!' : 'Copiar Convite'}</span>
                </button>

                <button
                  onClick={() => {
                    setIsLobbyModalOpen(false);
                    handleJoinMeeting(generatedLobbyCode);
                  }}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-950/20"
                >
                  <Video size={14} />
                  <span>Entrar Agora</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Technical Footer */}
        <footer className="h-10 border-t border-slate-900 bg-slate-950/30 flex items-center justify-center text-[10px] text-slate-600 font-mono gap-3 uppercase select-none">
          <span>XMPP MUC: COMPATÍVEL</span>
          <span>•</span>
          <span>JINGLE SIGNALING: ACTIVE</span>
          <span>•</span>
          <span>SRTP SECURE AUDIO/VIDEO</span>
        </footer>
      </div>
    );
  }

  // RENDER PHASE 2: ACTIVE MEETING INTERFACE (CINEMA STYLE VIDEO GRID)
  return (
    <div className="min-h-screen bg-[#111] text-white flex flex-col relative overflow-hidden font-sans select-none" id="google_meet_active_screen">
      
      {/* Top Floating Alert Toast */}
      {toastMessage && (
        <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-slate-900/90 backdrop-blur-md border border-slate-800 text-white px-4 py-2.5 rounded-xl shadow-2xl z-50 text-xs flex items-center gap-2 animate-bounce">
          <Info size={14} className="text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Meet Header: Left room code and clock, right quick widgets */}
      <header className="h-14 px-6 bg-[#111] flex items-center justify-between z-10 border-b border-white/5">
        <div className="flex items-center gap-3">
          <span className="font-mono text-sm tracking-widest text-slate-400 uppercase select-all font-bold">
            {meetingCode}
          </span>
          <span className="h-4 w-[1px] bg-white/10" />
          <span className="text-xs text-slate-400 font-medium">
            {currentTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
          </span>
          <span className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 bg-emerald-950/60 border border-emerald-900/30 text-emerald-400 rounded-full text-[9px] font-mono tracking-wider uppercase">
            <span className="w-1 h-1 rounded-full bg-emerald-400 animate-ping" />
            Conexão Segura XMPP
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* SuperAdmin quick badge */}
          {currentUser.role === 'admin' && (
            <span className="px-2.5 py-1 bg-amber-950/30 border border-amber-900/30 text-amber-400 text-[10px] font-bold rounded-lg flex items-center gap-1">
              <Crown size={12} />
              <span>Moderador</span>
            </span>
          )}
        </div>
      </header>

      {/* Main Container Area: Video Grid and optional Sidebar Panel */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* VIDEO STAGE WINDOW */}
        <div className="flex-1 p-4 flex flex-col justify-between relative overflow-y-auto">
          
          {/* THE GRID */}
          <div className="flex-1 flex items-center justify-center">
            <div className={`w-full max-w-5xl grid gap-4 transition-all duration-300 ${
              participants.length <= 1 ? 'grid-cols-1 max-w-3xl' :
              participants.length === 2 ? 'grid-cols-1 md:grid-cols-2' :
              participants.length <= 4 ? 'grid-cols-2' :
              'grid-cols-2 md:grid-cols-3'
            }`}>
              
              {/* If user is presenting, render a dedicated Presentation Screen Box at the top */}
              {isScreenSharing && screenStream && (
                <div className="col-span-full aspect-video rounded-2xl overflow-hidden border-2 border-emerald-500 bg-black shadow-2xl relative">
                  <video
                    ref={screenVideoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute bottom-4 left-4 bg-slate-950/80 backdrop-blur border border-slate-800 px-3 py-1.5 rounded-lg text-xs flex items-center gap-2">
                    <Monitor size={14} className="text-emerald-400" />
                    <span>Apresentando sua tela (Você)</span>
                  </div>
                </div>
              )}

              {/* RENDER PARTICIPANTS BOXES */}
              {participants.map((p) => {
                const isSpeaking = p.speaking && !p.isMicMuted;
                
                return (
                  <div 
                    key={p.jid}
                    className={`aspect-video rounded-2xl overflow-hidden bg-zinc-900 border transition-all duration-300 relative group flex flex-col items-center justify-center ${
                      isSpeaking ? 'border-purple-500 ring-2 ring-purple-500/30 shadow-lg shadow-purple-950/40' : 'border-white/5'
                    }`}
                  >
                    {/* Video stream layer */}
                    {p.isLocal && localStream && !isCamMuted ? (
                      <video
                        ref={localVideoRef}
                        autoPlay
                        muted
                        playsInline
                        className="w-full h-full object-cover transform -scale-x-100"
                      />
                    ) : (
                      // Otherwise, show static gorgeous profile card with ripple speaker animations
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900 relative">
                        {/* Audio speaker bounce wave ripple rings */}
                        {isSpeaking && (
                          <div className="absolute w-32 h-32 rounded-full border border-purple-500/20 animate-ping duration-[3000ms]" />
                        )}
                        
                        <div 
                          className={`w-18 h-18 rounded-full flex items-center justify-center text-xl font-bold border shadow-xl relative transition ${
                            isSpeaking ? 'border-purple-500 scale-105' : 'border-zinc-800'
                          }`}
                          style={{ backgroundColor: p.avatarColor }}
                        >
                          {p.name.charAt(0).toUpperCase()}

                          {/* Speaking bounce wave visualizer bar in corner of avatar */}
                          {isSpeaking && (
                            <span className="absolute bottom-0 right-0 p-1 bg-purple-600 rounded-full border border-zinc-900 flex items-center gap-0.5">
                              <span className="w-0.5 h-2 bg-white rounded animate-bounce" style={{ animationDelay: '0.1s' }} />
                              <span className="w-0.5 h-3 bg-white rounded animate-bounce" style={{ animationDelay: '0.3s' }} />
                              <span className="w-0.5 h-1.5 bg-white rounded animate-bounce" style={{ animationDelay: '0.5s' }} />
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Bottom overlay: name tag & device status */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
                      <span className="px-2.5 py-1 bg-black/60 backdrop-blur rounded-lg text-xs font-medium text-slate-100 flex items-center gap-1.5 border border-white/5 max-w-[200px] truncate">
                        {p.name}
                        {p.handRaised && (
                          <span className="text-yellow-400 text-xs shrink-0 animate-bounce">✋</span>
                        )}
                      </span>

                      <div className="flex gap-1.5 pointer-events-auto">
                        {p.isMicMuted ? (
                          <span className="w-7 h-7 bg-red-600/90 text-white rounded-lg flex items-center justify-center shadow-lg border border-red-500/10">
                            <MicOff size={12} />
                          </span>
                        ) : null}
                      </div>
                    </div>

                    {/* Quick hand raised indicator in grid tile */}
                    {p.handRaised && (
                      <div className="absolute top-4 right-4 bg-yellow-500 text-slate-950 p-2 rounded-xl flex items-center justify-center shadow-xl animate-pulse">
                        <Hand size={16} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* CAPTIONS OVERLAY PANEL (AT BOTTOM OF VIDEO GRID) */}
          {captionsActive && (
            <div className="mt-4 p-4 bg-black/85 border border-white/5 rounded-2xl max-w-3xl mx-auto w-full space-y-2 animate-in slide-in-from-bottom duration-300">
              <span className="text-[9px] font-mono text-purple-400 font-bold tracking-wider uppercase block">Legendas em Tempo Real (CC)</span>
              <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
                {captions.map((cap) => (
                  <div key={cap.id} className="text-sm leading-relaxed flex gap-2">
                    <strong className="text-slate-300 shrink-0">{cap.senderName}:</strong>
                    <span className="text-white font-sans select-all">{cap.text}</span>
                  </div>
                ))}
                {captions.length === 0 && (
                  <p className="text-xs text-slate-500 italic">Nenhuma fala capturada ainda. Fale no microfone ou aguarde os participantes.</p>
                )}
              </div>
            </div>
          )}

        </div>

        {/* SIDEBAR CONTAINER PANEL (INFO, PEOPLE, CHAT PANEL) */}
        {showSidebar && (
          <aside className="w-80 border-l border-white/5 bg-[#171717] flex flex-col z-20 animate-in slide-in-from-right duration-200">
            
            {/* Sidebar Tab Selector Header */}
            <div className="grid grid-cols-3 border-b border-white/5 h-14">
              <button
                onClick={() => setActiveSidebarTab('info')}
                className={`flex flex-col items-center justify-center text-[10px] uppercase tracking-wider font-bold transition cursor-pointer ${
                  activeSidebarTab === 'info' ? 'text-purple-400 border-b-2 border-purple-500 bg-white/3' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Info size={16} className="mb-1" />
                <span>Info</span>
              </button>
              
              <button
                onClick={() => setActiveSidebarTab('people')}
                className={`flex flex-col items-center justify-center text-[10px] uppercase tracking-wider font-bold transition relative cursor-pointer ${
                  activeSidebarTab === 'people' ? 'text-purple-400 border-b-2 border-purple-500 bg-white/3' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users size={16} className="mb-1" />
                <span>Pessoas</span>
                <span className="absolute top-2 right-4 w-4 h-4 rounded-full bg-purple-600 text-[9px] font-bold text-white flex items-center justify-center">
                  {participants.length}
                </span>
              </button>

              <button
                onClick={() => setActiveSidebarTab('chat')}
                className={`flex flex-col items-center justify-center text-[10px] uppercase tracking-wider font-bold transition cursor-pointer ${
                  activeSidebarTab === 'chat' ? 'text-purple-400 border-b-2 border-purple-500 bg-white/3' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageSquare size={16} className="mb-1" />
                <span>Chat</span>
              </button>
            </div>

            {/* Sidebar Tab Contents viewport */}
            <div className="flex-1 overflow-y-auto p-4">
              
              {/* TAB 1: MEETING INFO DETAILS */}
              {activeSidebarTab === 'info' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-bold text-white mb-2">Detalhes da Reunião</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Compartilhe este convite para conectar outros clientes à mesma videoconferência federada.
                    </p>
                  </div>

                  <div className="p-4 bg-zinc-900 border border-white/5 rounded-xl space-y-3 font-mono text-xs">
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-500 uppercase tracking-wide block">Código de Acesso:</span>
                      <span className="text-white font-bold select-all block">{meetingCode}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-500 uppercase tracking-wide block">XMPP MUC Server:</span>
                      <span className="text-[11px] text-purple-400 select-all block truncate">{meetingJid}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleCopyInviteLink}
                    className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer border border-purple-500/20"
                  >
                    {copiedText ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                    <span>{copiedText ? 'Copiado!' : 'Copiar Convite'}</span>
                  </button>
                </div>
              )}

              {/* TAB 2: ROSTER PARTICIPANTS MANAGEMENT */}
              {activeSidebarTab === 'people' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Participantes na sala</h3>
                    <span className="text-xs font-bold text-purple-400 bg-purple-950 border border-purple-900/30 px-2 py-0.5 rounded-full">{participants.length}</span>
                  </div>

                  <div className="space-y-2.5">
                    {participants.map((p) => (
                      <div key={p.jid} className="p-3 bg-zinc-900/40 border border-white/5 rounded-xl flex items-center justify-between group">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 shadow" style={{ backgroundColor: p.avatarColor }}>
                            {p.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="text-left shrink min-w-0 max-w-[120px]">
                            <h4 className="text-xs font-semibold text-white truncate">{p.name}</h4>
                            <span className="text-[10px] text-slate-500 font-mono block truncate">{p.jid}</span>
                          </div>
                        </div>

                        {/* Moderator settings panel (Only Super Admin or local user can moderate bots/peers) */}
                        {!p.isLocal && (
                          <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition duration-150">
                            <button
                              onClick={() => handleMuteParticipant(p.jid)}
                              className="p-1.5 bg-zinc-800 hover:bg-zinc-750 text-slate-400 hover:text-white rounded border border-white/5 cursor-pointer"
                              title={p.isMicMuted ? 'Desmutar' : 'Mutar'}
                            >
                              {p.isMicMuted ? <MicOff size={12} className="text-red-400" /> : <Mic size={12} />}
                            </button>
                            <button
                              onClick={() => handleKickParticipant(p.jid)}
                              className="p-1.5 bg-red-950/40 hover:bg-red-900/40 text-red-400 hover:text-white rounded border border-red-900/30 cursor-pointer"
                              title="Remover participante"
                            >
                              <PhoneOff size={12} />
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: GROUPCHAT PANEL */}
              {activeSidebarTab === 'chat' && (
                <div className="h-full flex flex-col justify-between -m-4">
                  {/* Messages list log */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[calc(100vh-210px)]">
                    {messages.map((m) => {
                      const isMe = m.from === currentUser.jid;
                      
                      return (
                        <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                          <div className="flex items-center gap-1.5 mb-1 text-[10px] text-slate-500 font-sans">
                            <span className="font-bold text-slate-300">{m.senderName || m.from.split('@')[0]}</span>
                            <span>•</span>
                            <span>{new Date(m.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          
                          <div className={`p-2.5 rounded-xl text-xs max-w-[220px] leading-relaxed break-words font-sans text-left border ${
                            isMe 
                              ? 'bg-purple-600 border-purple-500/20 text-white rounded-br-none' 
                              : 'bg-zinc-900 border-white/5 text-slate-200 rounded-bl-none'
                          }`}>
                            {m.body}
                          </div>
                        </div>
                      );
                    })}
                    {messages.length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-20">
                        <MessageSquare size={32} className="text-slate-600 mb-2" />
                        <p className="text-xs text-slate-400">Nenhuma mensagem enviada.</p>
                        <p className="text-[10px] text-slate-500 mt-1">O chat de texto opera por canais MUC XMPP.</p>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Message Composer Footer Form */}
                  <form onSubmit={handleSendMessage} className="p-3 border-t border-white/5 bg-zinc-950 flex gap-2">
                    <input
                      type="text"
                      placeholder="Enviar mensagem para a sala..."
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      className="flex-1 bg-zinc-900 border border-white/5 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                      required
                    />
                    <button
                      type="submit"
                      className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition flex items-center justify-center shrink-0 cursor-pointer border border-purple-500/10"
                    >
                      <Send size={14} />
                    </button>
                  </form>
                </div>
              )}

            </div>
          </aside>
        )}

      </div>

      {/* MEET CONTROL PANEL: BOTOM CONTROLS (CIRCLE BUTTONS BAR) */}
      <footer className="h-20 bg-[#111] border-t border-white/5 px-6 flex items-center justify-between z-10 shrink-0">
        
        {/* Left Side: Room details code */}
        <div className="hidden md:flex items-center gap-1 text-slate-300 font-sans text-xs">
          <span className="font-bold">Código da Sala:</span>
          <span className="font-mono text-purple-400 select-all font-semibold pl-1">{meetingCode}</span>
        </div>

        {/* Center: Meet Toggle Circle Controls */}
        <div className="flex items-center gap-3 mx-auto md:mx-0">
          {/* Toggle Mic Button */}
          <button
            onClick={() => {
              const nextMute = !isMicMuted;
              setIsMicMuted(nextMute);
              setParticipants(prev => prev.map(p => p.isLocal ? { ...p, isMicMuted: nextMute } : p));
              
              if (localStream) {
                localStream.getAudioTracks().forEach(t => t.enabled = !nextMute);
              }
              triggerToast(nextMute ? 'Microfone mutado.' : 'Microfone ativado.');
            }}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition shadow-lg border cursor-pointer ${
              isMicMuted 
                ? 'bg-red-600 hover:bg-red-500 border-red-500/10 text-white' 
                : 'bg-zinc-800 hover:bg-zinc-700 border-white/5 text-slate-200'
            }`}
            title={isMicMuted ? 'Ativar Microfone' : 'Mutar Microfone'}
          >
            {isMicMuted ? <MicOff size={18} /> : <Mic size={18} />}
          </button>

          {/* Toggle Camera Button */}
          <button
            onClick={() => {
              const nextCam = !isCamMuted;
              setIsCamMuted(nextCam);
              setParticipants(prev => prev.map(p => p.isLocal ? { ...p, isCamMuted: nextCam } : p));
              
              if (localStream) {
                localStream.getVideoTracks().forEach(t => t.enabled = !nextCam);
              }
              triggerToast(nextCam ? 'Câmera desligada.' : 'Câmera ligada.');
            }}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition shadow-lg border cursor-pointer ${
              isCamMuted 
                ? 'bg-red-600 hover:bg-red-500 border-red-500/10 text-white' 
                : 'bg-zinc-800 hover:bg-zinc-700 border-white/5 text-slate-200'
            }`}
            title={isCamMuted ? 'Ativar Vídeo' : 'Desativar Vídeo'}
          >
            {isCamMuted ? <VideoOff size={18} /> : <Video size={18} />}
          </button>

          {/* Toggle Real Screen Share Button */}
          <button
            onClick={toggleScreenShare}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition shadow-lg border cursor-pointer ${
              isScreenSharing 
                ? 'bg-emerald-600 hover:bg-emerald-500 border-emerald-500/10 text-white animate-pulse' 
                : 'bg-zinc-800 hover:bg-zinc-700 border-white/5 text-slate-200'
            }`}
            title={isScreenSharing ? 'Parar Apresentação' : 'Apresentar Tela'}
          >
            <Monitor size={18} />
          </button>

          {/* Toggle Raise Hand Button */}
          <button
            onClick={toggleHandRaise}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition shadow-lg border cursor-pointer ${
              handRaised 
                ? 'bg-yellow-500 text-slate-950 border-yellow-400/20' 
                : 'bg-zinc-800 hover:bg-zinc-700 border-white/5 text-slate-200'
            }`}
            title="Levantar Mão"
          >
            <Hand size={18} />
          </button>

          {/* Toggle Real-time speech transcription Captions (CC) */}
          <button
            onClick={() => {
              const nextCc = !captionsActive;
              setCaptionsActive(nextCc);
              triggerToast(nextCc ? 'Legendas automáticas ativadas.' : 'Legendas desativadas.');
            }}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition shadow-lg border text-xs font-bold cursor-pointer ${
              captionsActive 
                ? 'bg-purple-600 border-purple-500/10 text-white' 
                : 'bg-zinc-800 hover:bg-zinc-700 border-white/5 text-slate-400'
            }`}
            title="Legendas (CC)"
          >
            CC
          </button>

          {/* HANGUP RED BUTTON */}
          <button
            onClick={handleLeaveMeeting}
            className="w-13 h-11 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg transition border border-red-500/10 cursor-pointer"
            title="Sair da Reunião"
          >
            <PhoneOff size={20} />
          </button>
        </div>

        {/* Right Side: Toggle Sidebar views panels */}
        <div className="hidden md:flex items-center gap-3">
          {/* Info Toggle panel */}
          <button
            onClick={() => {
              if (showSidebar && activeSidebarTab === 'info') {
                setShowSidebar(false);
              } else {
                setShowSidebar(true);
                setActiveSidebarTab('info');
              }
            }}
            className={`w-10 h-10 rounded-xl flex items-center justify-center border transition cursor-pointer ${
              showSidebar && activeSidebarTab === 'info'
                ? 'bg-purple-600/20 border-purple-500/30 text-purple-400'
                : 'bg-zinc-900 hover:bg-zinc-850 border-white/5 text-slate-400 hover:text-white'
            }`}
            title="Detalhes da Reunião"
          >
            <Info size={18} />
          </button>

          {/* People list toggle */}
          <button
            onClick={() => {
              if (showSidebar && activeSidebarTab === 'people') {
                setShowSidebar(false);
              } else {
                setShowSidebar(true);
                setActiveSidebarTab('people');
              }
            }}
            className={`w-10 h-10 rounded-xl flex items-center justify-center border transition relative cursor-pointer ${
              showSidebar && activeSidebarTab === 'people'
                ? 'bg-purple-600/20 border-purple-500/30 text-purple-400'
                : 'bg-zinc-900 hover:bg-zinc-850 border-white/5 text-slate-400 hover:text-white'
            }`}
            title="Mostrar Participantes"
          >
            <Users size={18} />
            <span className="absolute top-1 right-1 bg-purple-600 text-[8px] font-bold text-white px-1 rounded-full border border-[#111]">
              {participants.length}
            </span>
          </button>

          {/* Group Chat list toggle */}
          <button
            onClick={() => {
              if (showSidebar && activeSidebarTab === 'chat') {
                setShowSidebar(false);
              } else {
                setShowSidebar(true);
                setActiveSidebarTab('chat');
              }
            }}
            className={`w-10 h-10 rounded-xl flex items-center justify-center border transition cursor-pointer ${
              showSidebar && activeSidebarTab === 'chat'
                ? 'bg-purple-600/20 border-purple-500/30 text-purple-400'
                : 'bg-zinc-900 hover:bg-zinc-850 border-white/5 text-slate-400 hover:text-white'
            }`}
            title="Chat com Todos"
          >
            <MessageSquare size={18} />
          </button>
        </div>
      </footer>

    </div>
  );
}
