import React, { useState, useEffect, useRef } from 'react';
import { User, ConferenceRoom, ChatMessage, XmppStatus } from '../types';
import { 
  Users, 
  MessageSquare, 
  Video, 
  Phone, 
  PhoneOff, 
  Mic, 
  MicOff, 
  VideoOff, 
  Send, 
  LogOut, 
  Settings, 
  UserCheck, 
  ChevronDown, 
  Circle,
  Clock,
  ShieldAlert,
  Volume2,
  VolumeX,
  Play,
  Maximize2
} from 'lucide-react';

interface XmppClientProps {
  currentUser: User;
  onLogout: () => void;
  onGoToAdmin: () => void;
  onGoToDashboard?: () => void;
}

export default function XmppClient({ currentUser, onLogout, onGoToAdmin, onGoToDashboard }: XmppClientProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [rooms, setRooms] = useState<ConferenceRoom[]>([]);
  const [activeChat, setActiveChat] = useState<{ type: 'user' | 'room'; id: string } | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [status, setStatus] = useState<XmppStatus>('online');
  const [statusMessage, setStatusMessage] = useState('Chat Ghost XMPP conectado');
  const [showStatusMenu, setShowStatusMenu] = useState(false);

  // WebRTC Call States
  const [callActive, setCallActive] = useState(false);
  const [callType, setCallType] = useState<'audio' | 'video'>('video');
  const [callStatus, setCallStatus] = useState<'incoming' | 'outgoing' | 'connected' | 'idle'>('idle');
  const [callPartner, setCallPartner] = useState<User | null>(null);
  const [callId, setCallId] = useState<string | null>(null);
  const [audioMuted, setAudioMuted] = useState(false);
  const [videoMuted, setVideoMuted] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  
  // Simulated Loopback for testing calls when alone
  const [isLoopback, setIsLoopback] = useState(false);

  const socketRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);

  // Fetch initial rosters and rooms
  const fetchData = async () => {
    try {
      const usersRes = await fetch('/api/users');
      const roomsRes = await fetch('/api/rooms');
      if (usersRes.ok) {
        const usersData = await usersRes.json();
        // Remove self from standard roster list to show others nicely
        setUsers(usersData.filter((u: User) => u.jid.toLowerCase() !== currentUser.jid.toLowerCase()));
      }
      if (roomsRes.ok) {
        const roomsData = await roomsRes.json();
        setRooms(roomsData);
      }
    } catch (err) {
      console.error('Error fetching roster:', err);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 6000);
    return () => clearInterval(interval);
  }, [currentUser]);

  // Handle WebSocket Connection
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socketUrl = `${protocol}//${window.location.host}/xmpp-websocket`;
    
    const socket = new WebSocket(socketUrl);
    socketRef.current = socket;

    socket.onopen = () => {
      console.log('Connected to Chat Ghost XMPP Router');
      // Auth / bind JID to WebSocket session
      socket.send(JSON.stringify({
        type: 'auth',
        from: currentUser.jid,
        role: currentUser.role
      }));
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'presence') {
          // Update status of roster users dynamically
          setUsers(prev => prev.map(u => {
            if (u.jid.toLowerCase() === data.jid.toLowerCase()) {
              return { ...u, status: data.status as XmppStatus, statusMessage: data.statusMessage };
            }
            return u;
          }));
        }

        if (data.type === 'chat' || data.type === 'groupchat' || data.type === 'chat-echo') {
          const fromJid = data.type === 'chat-echo' ? currentUser.jid : data.from;
          const toJid = data.to;
          
          const newMsg: ChatMessage = {
            id: data.id,
            from: fromJid,
            to: toJid,
            body: data.body,
            timestamp: data.timestamp,
            type: data.type === 'groupchat' ? 'groupchat' : 'chat',
            senderName: data.senderName
          };

          setMessages(prev => {
            // Guard against duplicates
            if (prev.some(m => m.id === newMsg.id)) return prev;
            return [...prev, newMsg];
          });
        }

        // WebRTC Signaling
        if (data.type === 'call-offer') {
          const caller = users.find(u => u.jid.toLowerCase() === data.from.toLowerCase());
          if (caller) {
            setCallPartner(caller);
            setCallStatus('incoming');
            setCallType(data.callType);
            setCallId(data.callId);
            setCallActive(true);
            setIsLoopback(false);
          }
          // Hold the signaling payload for answering later
          (window as any).incomingSessionOffer = data.payload;
        }

        if (data.type === 'call-answer') {
          if (peerConnectionRef.current && data.payload) {
            peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(data.payload));
            setCallStatus('connected');
          }
        }

        if (data.type === 'call-candidate') {
          if (peerConnectionRef.current && data.payload) {
            peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(data.payload))
              .catch(e => console.error('Error adding ICE candidate:', e));
          }
        }

        if (data.type === 'call-hangup') {
          handleEndCall(false);
        }

      } catch (err) {
        console.error('Error processing socket frame:', err);
      }
    };

    socket.onclose = () => {
      console.log('Chat Ghost XMPP disconnected');
    };

    return () => {
      socket.close();
    };
  }, [currentUser, users]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeChat]);

  // Handle Presence Status Change
  const handleStatusChange = (newStatus: XmppStatus) => {
    setStatus(newStatus);
    setShowStatusMenu(false);
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'presence',
        from: currentUser.jid,
        body: newStatus,
        statusMessage: statusMessage
      }));
    }
  };

  // Handle Send Text Message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || !activeChat) return;

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      const payload = {
        type: activeChat.type === 'user' ? 'chat' : 'groupchat',
        from: currentUser.jid,
        to: activeChat.id,
        body: inputMessage,
        senderName: currentUser.name
      };
      socketRef.current.send(JSON.stringify(payload));
      setInputMessage('');
    }
  };

  // Get active chat display details
  const activeChatDetails = () => {
    if (!activeChat) return null;
    if (activeChat.type === 'user') {
      const u = users.find(u => u.jid === activeChat.id);
      return u ? { name: u.name, subtitle: u.jid, avatarColor: u.avatarColor, status: u.status } : { name: activeChat.id, subtitle: 'Usuário XMPP', avatarColor: '#6b7280', status: 'offline' };
    } else {
      const r = rooms.find(r => r.jid === activeChat.id);
      return r ? { name: r.name, subtitle: `MUC: ${r.theme}`, avatarColor: '#10b981', status: 'room' } : { name: activeChat.id, subtitle: 'Conferência MUC', avatarColor: '#10b981', status: 'room' };
    }
  };

  const currentChatMsgs = messages.filter(m => {
    if (!activeChat) return false;
    if (activeChat.type === 'user') {
      // Direct message: from me to activeChat OR from activeChat to me
      return (m.type === 'chat' && (
        (m.from === currentUser.jid && m.to === activeChat.id) ||
        (m.from === activeChat.id && m.to === currentUser.jid)
      ));
    } else {
      // Room message: targeted to the room JID
      return m.type === 'groupchat' && m.to === activeChat.id;
    }
  });

  // ==========================================================================
  // WebRTC Video/Audio calling logic
  // ==========================================================================

  const startLocalMedia = async (type: 'audio' | 'video') => {
    try {
      const constraints = {
        audio: true,
        video: type === 'video' ? { width: 640, height: 480 } : false
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setLocalStream(stream);
      if (localVideoRef.current && type === 'video') {
        localVideoRef.current.srcObject = stream;
      }
      return stream;
    } catch (err) {
      console.error('Error accessing camera or microphone:', err);
      alert('Não foi possível acessar a câmera ou microfone. Verifique as permissões do navegador.');
      return null;
    }
  };

  // 1. Initiate Call
  const handleStartCall = async (type: 'audio' | 'video') => {
    if (activeChat?.type !== 'user') return;
    const partner = users.find(u => u.jid === activeChat.id);
    if (!partner) return;

    setCallPartner(partner);
    setCallStatus('outgoing');
    setCallType(type);
    setCallActive(true);
    
    // Check if the recipient is online. If offline, support loopback preview
    if (partner.status === 'offline') {
      setIsLoopback(true);
      const stream = await startLocalMedia(type);
      if (stream) {
        setCallStatus('connected');
        // Loop back local video to remote screen as simulated partner
        setTimeout(() => {
          if (remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = stream;
          }
        }, 1000);
      }
      return;
    }

    // Direct Real WebRTC Signaling
    const cId = Math.random().toString(36).substr(2, 9);
    setCallId(cId);

    const stream = await startLocalMedia(type);
    if (!stream) {
      handleEndCall(true);
      return;
    }

    // Initialize RTCPeerConnection
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    });

    peerConnectionRef.current = pc;

    // Add local tracks to WebRTC
    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    // Handle incoming remote tracks
    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        setRemoteStream(event.streams[0]);
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = event.streams[0];
        }
      }
    };

    // Handle ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate && socketRef.current) {
        socketRef.current.send(JSON.stringify({
          type: 'call-candidate',
          from: currentUser.jid,
          to: partner.jid,
          payload: event.candidate,
          callId: cId
        }));
      }
    };

    // Create Call Offer
    try {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      if (socketRef.current) {
        socketRef.current.send(JSON.stringify({
          type: 'call-offer',
          from: currentUser.jid,
          to: partner.jid,
          payload: offer,
          callType: type,
          callId: cId
        }));
      }
    } catch (e) {
      console.error('Error creating SDP WebRTC offer:', e);
    }
  };

  // 2. Accept Call
  const handleAcceptCall = async () => {
    if (!callPartner || !socketRef.current) return;

    setCallStatus('connected');
    const stream = await startLocalMedia(callType);
    if (!stream) {
      handleEndCall(true);
      return;
    }

    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    });
    peerConnectionRef.current = pc;

    // Add local tracks
    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    // Handle remote tracks
    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        setRemoteStream(event.streams[0]);
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = event.streams[0];
        }
      }
    };

    // ICE Candidates
    pc.onicecandidate = (event) => {
      if (event.candidate && socketRef.current) {
        socketRef.current.send(JSON.stringify({
          type: 'call-candidate',
          from: currentUser.jid,
          to: callPartner.jid,
          payload: event.candidate,
          callId: callId
        }));
      }
    };

    // Handle incoming offer from window cache
    const incomingOffer = (window as any).incomingSessionOffer;
    if (incomingOffer) {
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(incomingOffer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        socketRef.current.send(JSON.stringify({
          type: 'call-answer',
          from: currentUser.jid,
          to: callPartner.jid,
          payload: answer,
          callId: callId
        }));
      } catch (err) {
        console.error('Error setting remote description/answer:', err);
      }
    }
  };

  // 3. Reject / Hangup Call
  const handleEndCall = (shouldNotify = true) => {
    // Stop camera and microphone tracks
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    setLocalStream(null);
    setRemoteStream(null);

    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    if (shouldNotify && callPartner && socketRef.current) {
      socketRef.current.send(JSON.stringify({
        type: 'call-hangup',
        from: currentUser.jid,
        to: callPartner.jid,
        callId: callId
      }));
    }

    setCallActive(false);
    setCallStatus('idle');
    setCallPartner(null);
    setCallId(null);
    setIsLoopback(false);
  };

  // Toggle audio / video tracks
  const toggleAudio = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setAudioMuted(!audioTrack.enabled);
      }
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setVideoMuted(!videoTrack.enabled);
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-screen overflow-hidden bg-slate-950 text-slate-100" id="xmpp_client_workspace">
      
      {/* Sidebar Panel */}
      <aside className="w-full md:w-80 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
        
        {/* User Identity and Status Bar */}
        <div className="p-4 border-b border-slate-800 bg-slate-900 flex justify-between items-center relative">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white text-base shadow-lg relative border border-slate-800"
              style={{ backgroundColor: currentUser.avatarColor }}
            >
              {currentUser.name.charAt(0).toUpperCase()}
              {/* Presence badge */}
              <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-slate-900 flex items-center justify-center ${
                status === 'online' ? 'bg-emerald-500' :
                status === 'away' ? 'bg-amber-500' :
                status === 'dnd' ? 'bg-red-500' :
                'bg-slate-500'
              }`} />
            </div>

            <div>
              <h2 className="font-bold text-sm text-white tracking-tight">{currentUser.name}</h2>
              <button 
                onClick={() => setShowStatusMenu(!showStatusMenu)}
                className="text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1 transition font-medium mt-0.5"
              >
                <span className="capitalize">{status}</span>
                <ChevronDown size={12} />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {onGoToDashboard && (
              <button
                onClick={onGoToDashboard}
                className="p-2 text-slate-400 hover:text-indigo-400 hover:bg-slate-850 rounded-lg transition border border-transparent hover:border-slate-800 cursor-pointer"
                title="Voltar ao Painel de Usuário"
              >
                <UserCheck size={18} />
              </button>
            )}
            {currentUser.role === 'admin' && (
              <button
                onClick={onGoToAdmin}
                id="btn_client_to_admin"
                className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-850 rounded-lg transition border border-transparent hover:border-slate-800 cursor-pointer"
                title="Painel de Administração"
              >
                <Settings size={18} />
              </button>
            )}
            <button
              onClick={onLogout}
              id="btn_client_logout"
              className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-850 rounded-lg transition border border-transparent hover:border-slate-800 cursor-pointer"
              title="Sair da Conta"
            >
              <LogOut size={18} />
            </button>
          </div>

          {/* Status Select Popover Menu */}
          {showStatusMenu && (
            <div className="absolute top-16 left-4 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl p-2 z-50 w-52">
              <p className="text-[10px] font-bold text-slate-500 px-2.5 py-1 uppercase tracking-wider">Definir Presença XMPP</p>
              <div className="space-y-1 mt-1">
                <button
                  onClick={() => handleStatusChange('online')}
                  className="w-full flex items-center gap-2 px-2.5 py-2 hover:bg-slate-900 rounded-lg text-sm transition cursor-pointer text-left"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-slate-200 font-medium">Disponível</span>
                </button>
                <button
                  onClick={() => handleStatusChange('away')}
                  className="w-full flex items-center gap-2 px-2.5 py-2 hover:bg-slate-900 rounded-lg text-sm transition cursor-pointer text-left"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="text-slate-200 font-medium">Ausente</span>
                </button>
                <button
                  onClick={() => handleStatusChange('dnd')}
                  className="w-full flex items-center gap-2 px-2.5 py-2 hover:bg-slate-900 rounded-lg text-sm transition cursor-pointer text-left"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                  <span className="text-slate-200 font-medium">Não Perturbe</span>
                </button>
                <button
                  onClick={() => handleStatusChange('offline')}
                  className="w-full flex items-center gap-2 px-2.5 py-2 hover:bg-slate-900 rounded-lg text-sm transition cursor-pointer text-left"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
                  <span className="text-slate-200 font-medium">Invisível</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Contacts & Rooms Scroll Area */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          
          {/* Conference Rooms list */}
          <div>
            <span className="text-[10px] font-bold text-slate-500 px-2 uppercase tracking-wider flex items-center gap-1">
              <MessageSquare size={10} />
              Salas de Conferência (MUC)
            </span>
            <div className="space-y-1 mt-2">
              {rooms.map((r) => {
                const isActive = activeChat?.type === 'room' && activeChat.id === r.jid;
                return (
                  <button
                    key={r.id}
                    onClick={() => setActiveChat({ type: 'room', id: r.jid })}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl transition cursor-pointer text-left border ${
                      isActive 
                        ? 'bg-emerald-950/20 border-emerald-900/40 text-white' 
                        : 'bg-transparent border-transparent text-slate-300 hover:bg-slate-850/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <div className="w-8 h-8 rounded-lg bg-emerald-600/10 border border-emerald-500/20 flex items-center justify-center font-bold text-emerald-400">
                        #
                      </div>
                      <div className="truncate">
                        <p className="font-semibold text-sm leading-tight">{r.name}</p>
                        <p className="text-slate-500 text-xs truncate mt-0.5">{r.theme}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
              {rooms.length === 0 && (
                <p className="text-slate-500 text-xs px-2 italic">Nenhuma sala ativa criada ainda.</p>
              )}
            </div>
          </div>

          {/* Roster list */}
          <div>
            <span className="text-[10px] font-bold text-slate-500 px-2 uppercase tracking-wider flex items-center gap-1">
              <Users size={10} />
              Roster de Usuários XMPP
            </span>
            <div className="space-y-1 mt-2">
              {users.map((u) => {
                const isActive = activeChat?.type === 'user' && activeChat.id === u.jid;
                return (
                  <button
                    key={u.id}
                    onClick={() => setActiveChat({ type: 'user', id: u.jid })}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl transition cursor-pointer text-left border ${
                      isActive 
                        ? 'bg-indigo-950/20 border-indigo-900/40 text-white' 
                        : 'bg-transparent border-transparent text-slate-300 hover:bg-slate-850/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <div 
                        className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white text-xs shrink-0 shadow-inner"
                        style={{ backgroundColor: u.avatarColor }}
                      >
                        {u.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="truncate">
                        <p className="font-semibold text-sm leading-tight">{u.name}</p>
                        <p className="text-slate-500 text-xs truncate mt-0.5">{u.jid}</p>
                      </div>
                    </div>

                    {/* Status Dot */}
                    <span className={`w-2 h-2 rounded-full shrink-0 ${
                      u.status === 'online' ? 'bg-emerald-500' :
                      u.status === 'away' ? 'bg-amber-500' :
                      u.status === 'dnd' ? 'bg-red-500' :
                      'bg-slate-600'
                    }`} />
                  </button>
                );
              })}
              {users.length === 0 && (
                <p className="text-slate-500 text-xs px-2 italic">Carregando usuários...</p>
              )}
            </div>
          </div>

        </div>

        {/* Brand footer */}
        <div className="p-3 border-t border-slate-800 text-center bg-slate-950">
          <p className="text-[10px] text-slate-600 uppercase tracking-widest font-mono">newhorter xmpp server</p>
        </div>
      </aside>

      {/* Main Chat & Calling Arena */}
      <section className="flex-1 flex flex-col bg-slate-950 relative h-full">
        
        {activeChat ? (
          <>
            {/* Top Workspace Header */}
            <div className="p-4 border-b border-slate-800 bg-slate-900/80 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div 
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white text-sm"
                  style={{ backgroundColor: activeChatDetails()?.avatarColor }}
                >
                  {activeChatDetails()?.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h2 className="font-bold text-white text-sm leading-tight">{activeChatDetails()?.name}</h2>
                  <p className="text-slate-400 text-xs truncate mt-0.5">{activeChatDetails()?.subtitle}</p>
                </div>
              </div>

              {/* Call Control Tools (Only for direct user chats) */}
              {activeChat.type === 'user' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleStartCall('audio')}
                    id="btn_start_audio_call"
                    className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-750 transition cursor-pointer border border-slate-750"
                    title="Iniciar chamada de voz XMPP"
                  >
                    <Phone size={16} />
                  </button>
                  <button
                    onClick={() => handleStartCall('video')}
                    id="btn_start_video_call"
                    className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-750 transition cursor-pointer border border-slate-750"
                    title="Iniciar chamada de vídeo XMPP"
                  >
                    <Video size={16} />
                  </button>
                </div>
              )}
            </div>

            {/* Message log display */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/40">
              {currentChatMsgs.map((m) => {
                const isMe = m.from.toLowerCase() === currentUser.jid.toLowerCase();
                return (
                  <div 
                    key={m.id} 
                    className={`flex flex-col max-w-[70%] ${
                      isMe ? 'ml-auto items-end' : 'mr-auto items-start'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-1">
                      <span className="font-semibold text-slate-400">{isMe ? 'Eu' : m.senderName || m.from.split('@')[0]}</span>
                      <span>•</span>
                      <span>{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    <div className={`p-3 rounded-2xl text-sm leading-relaxed border ${
                      isMe 
                        ? 'bg-indigo-600 border-indigo-500 text-white rounded-br-none' 
                        : 'bg-slate-900 border-slate-800 text-slate-200 rounded-bl-none'
                    }`}>
                      {m.body}
                    </div>
                  </div>
                );
              })}
              {currentChatMsgs.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-20">
                  <MessageSquare size={48} className="text-slate-600 mb-3" />
                  <p className="text-sm text-slate-400">Nenhuma mensagem neste chat.</p>
                  <p className="text-xs text-slate-500 mt-1">Envie um ping para iniciar a conversação XMPP.</p>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message composer form footer */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-900 bg-slate-900/60 flex gap-3">
              <input
                type="text"
                placeholder="Digite sua mensagem XMPP segura..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition"
                required
              />
              <button
                type="submit"
                id="btn_send_xmpp_msg"
                className="px-5 py-3 rounded-xl bg-indigo-600 text-white hover:bg-indigo-500 transition flex items-center justify-center shrink-0 cursor-pointer shadow-lg shadow-indigo-950/50"
              >
                <Send size={16} />
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-slate-950/50">
            <div className="w-16 h-16 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center mb-4 text-emerald-400 shadow-xl">
              <MessageSquare size={32} />
            </div>
            <h3 className="text-xl font-bold text-white tracking-tight">Console XMPP Chat Ghost XMPP</h3>
            <p className="text-slate-400 text-sm max-w-md mt-1.5 leading-relaxed">
              Conexão com servidor <code className="text-purple-300 font-mono text-xs bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">chags.smartmall577.space</code> estabelecida. Selecione um contato no roster ou entre em uma sala de conferência MUC.
            </p>
          </div>
        )}

        {/* WEBRTC CALL INTERFACE OVERLAY */}
        {callActive && (
          <div className="absolute inset-0 bg-slate-950/95 z-50 flex flex-col items-center justify-center p-6" id="webrtc_call_overlay">
            
            {/* Top Indicator */}
            <div className="text-center mb-6">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-800 text-emerald-400 rounded-full text-xs font-semibold tracking-wide uppercase mb-3">
                <Volume2 size={12} className="animate-pulse" />
                Chamada Segura XMPP (WebRTC)
              </span>
              <h2 className="text-2xl font-bold text-white tracking-tight">{callPartner?.name}</h2>
              <p className="text-slate-400 text-sm font-mono mt-0.5">{callPartner?.jid}</p>
            </div>

            {/* Video Streams Container */}
            {callType === 'video' && (
              <div className="relative w-full max-w-3xl aspect-video rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-2xl flex items-center justify-center mb-8">
                
                {/* Simulated / Remote Video element */}
                <video
                  ref={remoteVideoRef}
                  autoPlay
                  playsInline
                  id="remote_video_stream"
                  className="w-full h-full object-cover"
                />

                {!remoteStream && callStatus === 'connected' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-900/50 backdrop-blur text-slate-400">
                    <p className="text-sm">Aguardando feed de vídeo remoto...</p>
                  </div>
                )}

                {callStatus !== 'connected' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/90 text-slate-400 z-10 gap-3">
                    <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center animate-bounce border border-slate-750">
                      <Phone className="text-slate-300" size={20} />
                    </div>
                    <p className="text-sm font-semibold uppercase tracking-wider">
                      {callStatus === 'incoming' ? 'Chamando você...' : 
                       callStatus === 'outgoing' ? 'Sinalizando destinatário...' : 
                       'Estabelecendo conexão P2P...'}
                    </p>
                    {isLoopback && (
                      <span className="text-xs text-amber-400 font-semibold bg-amber-950/30 px-2.5 py-1 rounded-full border border-amber-900/30">
                        Modo Sandbox: Loopback Ativado
                      </span>
                    )}
                  </div>
                )}

                {/* Local PiP Stream element (always in corner if connected/outgoing) */}
                {localStream && (
                  <div className="absolute bottom-4 right-4 w-32 md:w-44 aspect-video rounded-xl overflow-hidden border border-slate-700 shadow-2xl bg-black z-20">
                    <video
                      ref={localVideoRef}
                      autoPlay
                      muted
                      playsInline
                      id="local_video_stream"
                      className="w-full h-full object-cover transform -scale-x-100"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Audio Call visualizer */}
            {callType === 'audio' && (
              <div className="w-48 h-48 rounded-full bg-slate-900 border-2 border-slate-800/80 flex items-center justify-center shadow-2xl mb-12 relative">
                <div className="absolute inset-0 rounded-full border-4 border-emerald-500/20 animate-ping" />
                <div className="w-40 h-40 rounded-full bg-slate-950 flex flex-col items-center justify-center border border-slate-800">
                  <Phone size={44} className="text-emerald-400 animate-pulse" />
                  {callStatus === 'connected' && (
                    <span className="text-emerald-400 text-xs font-bold font-mono tracking-wider uppercase mt-3">Conectado</span>
                  )}
                </div>
              </div>
            )}

            {/* CALL STATUS CONTROL BUTTONS */}
            <div className="flex items-center gap-4">
              
              {/* Incoming Actions Panel */}
              {callStatus === 'incoming' && (
                <>
                  <button
                    onClick={handleAcceptCall}
                    id="btn_accept_incoming_call"
                    className="px-6 py-3 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-emerald-950/60 transition cursor-pointer"
                  >
                    <Phone size={18} />
                    <span>Atender</span>
                  </button>
                  <button
                    onClick={() => handleEndCall(true)}
                    id="btn_reject_incoming_call"
                    className="px-6 py-3 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-red-950/60 transition cursor-pointer"
                  >
                    <PhoneOff size={18} />
                    <span>Recusar</span>
                  </button>
                </>
              )}

              {/* Active / Outgoing Control Panel */}
              {(callStatus === 'connected' || callStatus === 'outgoing') && (
                <>
                  {/* Mute Audio */}
                  <button
                    onClick={toggleAudio}
                    className={`p-3 rounded-full border transition cursor-pointer ${
                      audioMuted 
                        ? 'bg-red-600 border-red-500 text-white hover:bg-red-500' 
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                    }`}
                  >
                    {audioMuted ? <MicOff size={20} /> : <Mic size={20} />}
                  </button>

                  {/* Hangup button */}
                  <button
                    onClick={() => handleEndCall(true)}
                    id="btn_hangup_active_call"
                    className="p-4 rounded-full bg-red-600 text-white hover:bg-red-500 hover:scale-105 transition shadow-xl shadow-red-950/80 cursor-pointer"
                    title="Desconectar chamada"
                  >
                    <PhoneOff size={24} />
                  </button>

                  {/* Mute Video */}
                  {callType === 'video' && (
                    <button
                      onClick={toggleVideo}
                      className={`p-3 rounded-full border transition cursor-pointer ${
                        videoMuted 
                          ? 'bg-red-600 border-red-500 text-white hover:bg-red-500' 
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                      }`}
                    >
                      {videoMuted ? <VideoOff size={20} /> : <Video size={20} />}
                    </button>
                  )}
                </>
              )}

            </div>

          </div>
        )}

      </section>
    </div>
  );
}
