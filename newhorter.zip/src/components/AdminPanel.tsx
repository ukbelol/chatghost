import React, { useState, useEffect } from 'react';
import { User, ConferenceRoom } from '../types';
import { 
  Users, 
  Video, 
  Settings, 
  UserPlus, 
  Plus, 
  Trash2, 
  Terminal, 
  Globe, 
  ShieldCheck, 
  Layers, 
  Activity, 
  Database,
  ArrowLeft,
  X,
  MessageSquare,
  Edit,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import InstallScriptView from './InstallScriptView';

interface AdminPanelProps {
  currentUser: User;
  onLogout: () => void;
  onBackToClient: () => void;
}

export default function AdminPanel({ currentUser, onLogout, onBackToClient }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'users' | 'rooms' | 'install' | 'config'>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [rooms, setRooms] = useState<ConferenceRoom[]>([]);

  // Mercado Pago config states
  const [mpAccessToken, setMpAccessToken] = useState('');
  const [mpPublicKey, setMpPublicKey] = useState('');
  const [mpWebhookUrl, setMpWebhookUrl] = useState('');
  const [mpRedirectUrl, setMpRedirectUrl] = useState('');
  const [configSuccess, setConfigSuccess] = useState('');
  const [configError, setConfigError] = useState('');
  
  // Create User States
  const [newUsername, setNewUsername] = useState('');
  const [newName, setNewName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [userError, setUserError] = useState('');
  const [userSuccess, setUserSuccess] = useState('');

  // Edit User States
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editName, setEditName] = useState('');
  const [editSurname, setEditSurname] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editActive, setEditActive] = useState(true);
  const [editRole, setEditRole] = useState<'admin' | 'user'>('user');
  const [editHasPaid, setEditHasPaid] = useState(false);
  const [editError, setEditError] = useState('');
  const [editSuccess, setEditSuccess] = useState('');

  // Create Room States
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomTheme, setNewRoomTheme] = useState('');
  const [newRoomDesc, setNewRoomDesc] = useState('');
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);
  const [roomError, setRoomError] = useState('');
  const [roomSuccess, setRoomSuccess] = useState('');

  // Fetch Data
  const fetchData = async () => {
    try {
      const usersRes = await fetch('/api/users');
      const roomsRes = await fetch('/api/rooms');
      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setUsers(usersData);
      }
      if (roomsRes.ok) {
        const roomsData = await roomsRes.json();
        setRooms(roomsData);
      }
    } catch (err) {
      console.error('Error fetching admin data:', err);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);

    const fetchConfig = async () => {
      try {
        const res = await fetch('/api/mercadopago/config');
        if (res.ok) {
          const data = await res.json();
          setMpAccessToken(data.accessToken || '');
          setMpPublicKey(data.publicKey || '');
          setMpWebhookUrl(data.webhookUrl || '');
          setMpRedirectUrl(data.redirectUrl || '');
        }
      } catch (err) {
        console.error('Error fetching MP config:', err);
      }
    };
    fetchConfig();

    return () => clearInterval(interval);
  }, []);

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setConfigSuccess('');
    setConfigError('');
    try {
      const res = await fetch('/api/mercadopago/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accessToken: mpAccessToken,
          publicKey: mpPublicKey
        })
      });
      if (res.ok) {
        setConfigSuccess('Configurações do Mercado Pago salvas com sucesso!');
      } else {
        setConfigError('Erro ao salvar as configurações.');
      }
    } catch (err) {
      setConfigError('Erro de conexão ao salvar.');
    }
  };

  // Handle Create User
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setUserError('');
    setUserSuccess('');

    if (!newUsername || !newName || !newPassword) {
      setUserError('Preencha todos os campos obrigatórios.');
      return;
    }

    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: newUsername,
          name: newName,
          password: newPassword
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setUserError(data.error || 'Erro ao criar usuário XMPP.');
        return;
      }

      setUserSuccess(`Usuário ${data.jid} criado com sucesso!`);
      setNewUsername('');
      setNewName('');
      setNewPassword('');
      fetchData();
    } catch (err) {
      setUserError('Erro de conexão com o servidor.');
    }
  };

  // Handle Delete User
  const handleDeleteUser = async (id: string, jid: string) => {
    if (jid === 'rgs577@chags.smartmall577.space') {
      alert('Não é possível deletar o superadmin principal.');
      return;
    }

    if (!confirm(`Deseja realmente remover o usuário ${jid}? Ele perderá o acesso ao servidor XMPP.`)) {
      return;
    }

    try {
      const res = await fetch(`/api/admin/users/${id}`, { method: 'DELETE' });
      if (res.ok) {
        fetchData();
      } else {
        const data = await res.json();
        alert(data.error || 'Erro ao deletar usuário.');
      }
    } catch (err) {
      alert('Erro ao conectar ao servidor.');
    }
  };

  // Start Editing User
  const startEditingUser = (user: User) => {
    setEditingUser(user);
    setEditName(user.name || '');
    setEditSurname(user.surname || '');
    setEditEmail(user.email || '');
    setEditPassword(user.password || '');
    setEditActive(user.active !== false); // default to true if undefined
    setEditRole(user.role || 'user');
    setEditHasPaid(!!user.hasPaid);
    setEditError('');
    setEditSuccess('');
  };

  // Submit User Update
  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setEditError('');
    setEditSuccess('');

    try {
      const res = await fetch(`/api/admin/users/${editingUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName,
          surname: editSurname,
          email: editEmail,
          password: editPassword,
          active: editActive,
          role: editRole,
          hasPaid: editHasPaid
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setEditError(data.error || 'Erro ao atualizar dados do usuário.');
        return;
      }

      setEditSuccess('Cadastro do usuário atualizado com sucesso!');
      fetchData(); // reload users
      // Close after 1.5 seconds
      setTimeout(() => {
        setEditingUser(null);
      }, 1500);
    } catch (err) {
      setEditError('Erro de conexão ao atualizar usuário.');
    }
  };

  // Toggle user active status directly from list
  const toggleUserActive = async (user: User) => {
    const newActiveState = user.active === false ? true : false;
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          active: newActiveState
        })
      });
      if (res.ok) {
        fetchData();
      } else {
        const data = await res.json();
        console.error('Erro ao alterar status:', data.error);
      }
    } catch (err) {
      console.error('Error toggling active state:', err);
    }
  };

  // Handle Create Room
  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    setRoomError('');
    setRoomSuccess('');

    if (!newRoomName || !newRoomTheme) {
      setRoomError('Nome e Tema são obrigatórios.');
      return;
    }

    try {
      const res = await fetch('/api/admin/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newRoomName,
          theme: newRoomTheme,
          description: newRoomDesc,
          participants: [...selectedParticipants, 'rgs577@chags.smartmall577.space'] // Admin is always a participant
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setRoomError(data.error || 'Erro ao criar sala de conferência.');
        return;
      }

      setRoomSuccess(`Sala de conferência MUC ${data.name} criada!`);
      setNewRoomName('');
      setNewRoomTheme('');
      setNewRoomDesc('');
      setSelectedParticipants([]);
      fetchData();
    } catch (err) {
      setRoomError('Erro de rede.');
    }
  };

  // Handle Delete Room
  const handleDeleteRoom = async (id: string, roomName: string) => {
    if (!confirm(`Deseja realmente excluir a sala de conferência "${roomName}"?`)) {
      return;
    }

    try {
      const res = await fetch(`/api/admin/rooms/${id}`, { method: 'DELETE' });
      if (res.ok) {
        fetchData();
      } else {
        const data = await res.json();
        alert(data.error || 'Erro ao remover sala.');
      }
    } catch (err) {
      alert('Erro de rede ao conectar.');
    }
  };

  // Toggle Participant Selection
  const toggleParticipant = (jid: string) => {
    if (selectedParticipants.includes(jid)) {
      setSelectedParticipants(selectedParticipants.filter(p => p !== jid));
    } else {
      setSelectedParticipants([...selectedParticipants, jid]);
    }
  };

  const onlineUsersCount = users.filter(u => u.status && u.status !== 'offline' && u.role !== 'admin').length;
  const offlineUsersCount = users.filter(u => (u.status === 'offline' || !u.status) && u.role !== 'admin').length;
  const activeLoginsCount = users.filter(u => u.role !== 'admin' && (!u.subscription || !u.subscription.isBlocked)).length;
  const blockedLoginsCount = users.filter(u => u.role !== 'admin' && u.subscription && u.subscription.isBlocked).length;
  const totalMonthlySubscriptions = activeLoginsCount * 15.00;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col" id="admin_panel_main">
      {/* Admin Header */}
      <header className="bg-slate-900 border-b border-slate-800 py-4 px-6 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600/10 p-2.5 rounded-xl border border-emerald-500/20">
              <Settings className="text-emerald-400" size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-xl tracking-tight text-white">Chat Ghost XMPP Admin</h1>
                <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/20 uppercase tracking-wider">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-slate-400">Serviço XMPP Integrado & Controle de Roster</p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onBackToClient}
              id="btn_back_to_client"
              className="flex items-center gap-2 text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 px-4 py-2 rounded-xl text-sm font-medium transition border border-slate-700/60 cursor-pointer"
            >
              <ArrowLeft size={16} />
              <span>Voltar ao Chat</span>
            </button>
            <button
              onClick={onLogout}
              id="btn_admin_logout"
              className="text-red-400 hover:text-red-300 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 px-4 py-2 rounded-xl text-sm font-semibold transition cursor-pointer"
            >
              Sair da Conta
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8">
        
        {/* Quick Server Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="bg-blue-500/10 p-3 rounded-xl text-blue-400 border border-blue-500/10">
              <Users size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-400">Usuários XMPP</p>
              <h4 className="text-sm font-bold text-white mt-0.5">{onlineUsersCount} On / {offlineUsersCount} Off</h4>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="bg-emerald-500/10 p-3 rounded-xl text-emerald-400 border border-emerald-500/10">
              <ShieldCheck size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-400">Logins Ativos</p>
              <h4 className="text-xl font-bold text-emerald-400 mt-0.5">{activeLoginsCount}</h4>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="bg-red-500/10 p-3 rounded-xl text-red-400 border border-red-500/10">
              <X size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-400">Logins Bloqueados</p>
              <h4 className="text-xl font-bold text-red-400 mt-0.5">{blockedLoginsCount}</h4>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
            <div className="bg-purple-500/10 p-3 rounded-xl text-purple-400 border border-purple-500/10">
              <Database size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-400">Mensalidades Totais</p>
              <h4 className="text-lg font-bold text-white mt-0.5">R$ {totalMonthlySubscriptions.toFixed(2)}</h4>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-4 col-span-2 lg:col-span-1">
            <div className="bg-amber-500/10 p-3 rounded-xl text-amber-400 border border-amber-500/10">
              <Globe size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-400">Servidor</p>
              <h4 className="text-xs font-mono text-amber-400 mt-1 truncate">chags.smartmall577.space</h4>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 mb-8 gap-2">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-medium text-sm transition cursor-pointer ${
              activeTab === 'users' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserPlus size={16} />
            <span>Gerenciar Usuários</span>
          </button>
          <button
            onClick={() => setActiveTab('rooms')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-medium text-sm transition cursor-pointer ${
              activeTab === 'rooms' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare size={16} />
            <span>Salas de Conferência</span>
          </button>
          <button
            onClick={() => setActiveTab('install')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-medium text-sm transition cursor-pointer ${
              activeTab === 'install' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal size={16} />
            <span>Instalação Debian 12</span>
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`flex items-center gap-2 px-5 py-3 border-b-2 font-medium text-sm transition cursor-pointer ${
              activeTab === 'config' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings size={16} />
            <span>Configurações API</span>
          </button>
        </div>

        {/* Tab Contents */}
        {activeTab === 'users' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Create User Form */}
            <div className="lg:col-span-1">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <UserPlus className="text-emerald-400" size={18} />
                  Criar Novo Usuário XMPP
                </h3>
                <form onSubmit={handleCreateUser} className="space-y-4">
                  {userError && (
                    <div className="p-3 bg-red-950/50 border border-red-900/40 text-red-400 rounded-xl text-xs">
                      {userError}
                    </div>
                  )}
                  {userSuccess && (
                    <div className="p-3 bg-emerald-950/50 border border-emerald-900/40 text-emerald-400 rounded-xl text-xs">
                      {userSuccess}
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                      Username (Login) *
                    </label>
                    <div className="flex rounded-xl overflow-hidden border border-slate-800 focus-within:border-emerald-500 transition">
                      <input
                        type="text"
                        placeholder="ex: roger"
                        value={newUsername}
                        onChange={(e) => setNewUsername(e.target.value)}
                        className="bg-slate-950/80 px-4 py-2.5 text-sm text-white focus:outline-none w-full"
                        required
                      />
                      <span className="bg-slate-800 text-slate-400 text-xs px-3 flex items-center font-mono select-none">
                        @chags.smartmall577.space
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                      Nome de Exibição (Roster) *
                    </label>
                    <input
                      type="text"
                      placeholder="ex: Roger Meireles"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="bg-slate-950/80 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white w-full transition"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                      Senha XMPP *
                    </label>
                    <input
                      type="password"
                      placeholder="Sua senha segura"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="bg-slate-950/80 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white w-full transition"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    id="btn_admin_create_user"
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm transition shadow-lg shadow-emerald-950/50 cursor-pointer"
                  >
                    <Plus size={16} />
                    <span>Cadastrar Usuário</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Users List */}
            <div className="lg:col-span-2">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Users className="text-emerald-400" size={18} />
                      Roster do Servidor ({users.length})
                    </h3>
                    <p className="text-slate-400 text-xs mt-0.5">Usuários e contas XMPP autorizadas</p>
                  </div>
                  <button 
                    onClick={fetchData}
                    className="text-xs text-slate-400 hover:text-emerald-400 transition"
                  >
                    Atualizar Lista
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse font-sans">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-xs font-semibold uppercase tracking-wider">
                        <th className="pb-3 pl-2">Usuário</th>
                        <th className="pb-3">Endereço JID</th>
                        <th className="pb-3">Status XMPP</th>
                        <th className="pb-3">Assinatura</th>
                        <th className="pb-3">Vencimento/Renovação</th>
                        <th className="pb-3">Função</th>
                        <th className="pb-3">Status do Login</th>
                        <th className="pb-3 text-right pr-2">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-sm">
                      {users.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-950/30 transition">
                          <td className="py-3 pl-2 flex items-center gap-3">
                            <div 
                              className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs shadow-inner"
                              style={{ backgroundColor: u.avatarColor }}
                            >
                              {u.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold text-white">{u.name}</p>
                              <p className="text-slate-500 text-xs">Criado em {new Date(u.createdAt).toLocaleDateString()}</p>
                            </div>
                          </td>
                          <td className="py-3 text-slate-300 font-mono text-xs">{u.jid}</td>
                          <td className="py-3">
                            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium border ${
                              u.status === 'online' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                              u.status === 'away' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                              u.status === 'dnd' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                              'bg-slate-500/10 text-slate-400 border-slate-500/20'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                u.status === 'online' ? 'bg-emerald-400' :
                                u.status === 'away' ? 'bg-amber-400' :
                                u.status === 'dnd' ? 'bg-red-400' :
                                'bg-slate-500'
                              }`} />
                              <span className="capitalize">{u.status || 'offline'}</span>
                            </span>
                          </td>
                          <td className="py-3">
                            {u.role === 'admin' ? (
                              <span className="text-xs text-slate-500 font-mono">—</span>
                            ) : (
                              <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium border ${
                                u.subscription?.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                                u.subscription?.status === 'trial' ? 'bg-amber-500/10 text-amber-400 border-emerald-500/20' :
                                u.subscription?.status === 'grace' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                                'bg-red-500/10 text-red-400 border-red-500/20'
                              }`}>
                                <span className="capitalize">
                                  {u.subscription?.status === 'active' ? 'Ativa' :
                                   u.subscription?.status === 'trial' ? 'Grátis (Trial)' :
                                   u.subscription?.status === 'grace' ? 'Vencida (Grace)' :
                                   'Bloqueado'}
                                </span>
                              </span>
                            )}
                          </td>
                          <td className="py-3 text-slate-300 font-mono text-xs">
                            {u.role === 'admin' ? (
                              <span className="text-slate-500 font-mono">—</span>
                            ) : u.subscription?.paymentExpiresAt ? (
                              new Date(u.subscription.paymentExpiresAt).toLocaleDateString()
                            ) : (
                              '—'
                            )}
                          </td>
                          <td className="py-3">
                            <span className={`text-xs font-semibold uppercase px-2 py-0.5 rounded ${
                              u.role === 'admin' ? 'bg-indigo-950 text-indigo-400' : 'bg-slate-800 text-slate-400'
                            }`}>
                              {u.role}
                            </span>
                          </td>
                          <td className="py-3">
                            <button
                              onClick={() => toggleUserActive(u)}
                              disabled={u.jid === 'rgs577@chags.smartmall577.space'}
                              className={`inline-flex items-center gap-1.5 focus:outline-none transition ${
                                u.jid === 'rgs577@chags.smartmall577.space' ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'
                              }`}
                              title={u.active !== false ? 'Desativar login deste usuário' : 'Ativar login deste usuário'}
                            >
                              {u.active !== false ? (
                                <div className="flex items-center gap-1">
                                  <ToggleRight size={22} className="text-emerald-500 hover:text-emerald-400" />
                                  <span className="text-emerald-400 text-xs font-medium">Ativo</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1">
                                  <ToggleLeft size={22} className="text-slate-500 hover:text-slate-400" />
                                  <span className="text-slate-500 text-xs font-medium">Desativado</span>
                                </div>
                              )}
                            </button>
                          </td>
                          <td className="py-3 text-right pr-2">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => startEditingUser(u)}
                                className="p-1.5 rounded-lg border border-transparent hover:border-slate-800 hover:bg-slate-900 text-slate-300 hover:text-white transition"
                                title="Editar cadastro do usuário"
                              >
                                <Edit size={15} />
                              </button>
                              <button
                                onClick={() => handleDeleteUser(u.id, u.jid)}
                                disabled={u.jid === 'rgs577@chags.smartmall577.space'}
                                className={`p-1.5 rounded-lg border transition ${
                                  u.jid === 'rgs577@chags.smartmall577.space' 
                                    ? 'text-slate-600 border-slate-800/40 cursor-not-allowed bg-transparent' 
                                    : 'text-red-400 hover:text-red-300 border-transparent hover:border-red-900/30 hover:bg-red-950/20'
                                }`}
                                title="Remover usuário XMPP"
                              >
                                <Trash2 size={15} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Edit User Modal */}
        {editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
            <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
              {/* Modal Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/40">
                <div className="flex items-center gap-2">
                  <Edit size={18} className="text-purple-400" />
                  <h3 className="text-base font-semibold text-white">Editar Cadastro: {editingUser.username}</h3>
                </div>
                <button 
                  onClick={() => setEditingUser(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Modal Content / Form */}
              <form onSubmit={handleUpdateUser} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
                {editError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs font-medium">
                    {editError}
                  </div>
                )}
                {editSuccess && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400 text-xs font-medium">
                    {editSuccess}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-medium font-sans">Nome</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      required
                      className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-purple-500 transition"
                      placeholder="Nome completo"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-medium font-sans">Sobrenome</label>
                    <input
                      type="text"
                      value={editSurname}
                      onChange={(e) => setEditSurname(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-purple-500 transition"
                      placeholder="Sobrenome"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1 font-medium font-sans">E-mail</label>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-purple-500 transition"
                    placeholder="e-mail@exemplo.com"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1 font-medium font-sans">Nova Senha (deixe em branco para não alterar)</label>
                  <input
                    type="text"
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm font-mono focus:outline-none focus:border-purple-500 transition"
                    placeholder="Senha de acesso"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium font-sans">Status do Login</label>
                    <button
                      type="button"
                      disabled={editingUser.id === 'superadmin'}
                      onClick={() => setEditActive(!editActive)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border transition ${
                        editingUser.id === 'superadmin' 
                          ? 'bg-slate-950/40 border-slate-800/60 text-slate-500 cursor-not-allowed'
                          : editActive 
                            ? 'bg-emerald-950/20 border-emerald-900/30 text-emerald-400 hover:bg-emerald-950/30' 
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800/30'
                      }`}
                    >
                      <span className="text-sm font-medium">{editActive ? 'Ativo (Permitido)' : 'Desativado (Bloqueado)'}</span>
                      {editActive ? <ToggleRight size={22} /> : <ToggleLeft size={22} />}
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium font-sans">Função (Role)</label>
                    <select
                      value={editRole}
                      disabled={editingUser.id === 'superadmin'}
                      onChange={(e) => setEditRole(e.target.value as 'admin' | 'user')}
                      className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-purple-500 transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <option value="user">User (Comum)</option>
                      <option value="admin">Admin (Gerente)</option>
                    </select>
                  </div>
                </div>

                {editingUser.role !== 'admin' && (
                  <div className="p-4 bg-slate-950/50 border border-slate-800/80 rounded-xl space-y-3">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-purple-400">Controle de Assinatura & Cobrança</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-300">Marcar como Pago (Status Ativo)</span>
                      <input
                        type="checkbox"
                        checked={editHasPaid}
                        onChange={(e) => setEditHasPaid(e.target.checked)}
                        className="w-4 h-4 text-purple-600 border-slate-800 rounded focus:ring-purple-500 focus:ring-offset-slate-900 bg-slate-950"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 leading-normal">
                      Ativar esta opção ignora a contagem automática de dias grátis de testes (trial) e do período de tolerância (grace period), garantindo acesso irrestrito ao chat de vídeo.
                    </p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800/60">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-4 py-2 rounded-lg bg-transparent border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white text-sm font-medium transition"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-sm font-medium shadow-lg hover:shadow-purple-500/20 transition"
                  >
                    Salvar Alterações
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'rooms' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Create Conference Room */}
            <div className="lg:col-span-1">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Plus className="text-emerald-400" size={18} />
                  Criar Sala de Conferência
                </h3>
                <form onSubmit={handleCreateRoom} className="space-y-4">
                  {roomError && (
                    <div className="p-3 bg-red-950/50 border border-red-900/40 text-red-400 rounded-xl text-xs">
                      {roomError}
                    </div>
                  )}
                  {roomSuccess && (
                    <div className="p-3 bg-emerald-950/50 border border-emerald-900/40 text-emerald-400 rounded-xl text-xs">
                      {roomSuccess}
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                      Nome da Sala *
                    </label>
                    <input
                      type="text"
                      placeholder="ex: Desenvolvimento Core"
                      value={newRoomName}
                      onChange={(e) => setNewRoomName(e.target.value)}
                      className="bg-slate-950/80 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white w-full transition"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                      Tema da Sala *
                    </label>
                    <input
                      type="text"
                      placeholder="ex: Discussão de Infra e Certificados"
                      value={newRoomTheme}
                      onChange={(e) => setNewRoomTheme(e.target.value)}
                      className="bg-slate-950/80 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white w-full transition"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                      Descrição da Sala
                    </label>
                    <textarea
                      placeholder="Objetivo e pauta de reunião..."
                      value={newRoomDesc}
                      onChange={(e) => setNewRoomDesc(e.target.value)}
                      rows={3}
                      className="bg-slate-950/80 border border-slate-800 focus:border-emerald-500 focus:outline-none rounded-xl px-4 py-2.5 text-sm text-white w-full transition resize-none"
                    />
                  </div>

                  {/* Choose Participants List */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      Selecionar Participantes
                    </label>
                    <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 max-h-40 overflow-y-auto space-y-2">
                      {users
                        .filter(u => u.jid !== 'rgs577@chags.smartmall577.space') // Admin is auto included
                        .map((u) => (
                          <label key={u.id} className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer select-none hover:text-white transition">
                            <input
                              type="checkbox"
                              checked={selectedParticipants.includes(u.jid)}
                              onChange={() => toggleParticipant(u.jid)}
                              className="rounded border-slate-700 bg-slate-900 text-emerald-600 focus:ring-emerald-500/20"
                            />
                            <span>{u.name} <code className="text-slate-500 text-xs">({u.jid})</code></span>
                          </label>
                        ))}
                      {users.length <= 1 && (
                        <p className="text-xs text-slate-500 italic text-center py-2">Nenhum outro usuário criado ainda.</p>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1.5">* O Super Admin está incluso por padrão em todas as salas.</p>
                  </div>

                  <button
                    type="submit"
                    id="btn_admin_create_room"
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm transition shadow-lg shadow-emerald-950/50 cursor-pointer"
                  >
                    <Plus size={16} />
                    <span>Criar Sala MUC</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Conference Rooms List */}
            <div className="lg:col-span-2">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <MessageSquare className="text-emerald-400" size={18} />
                      Salas Ativas (MUC)
                    </h3>
                    <p className="text-slate-400 text-xs mt-0.5">Salas de conferência configuradas no servidor</p>
                  </div>
                </div>

                {rooms.length === 0 ? (
                  <div className="text-center py-12 border border-dashed border-slate-800 rounded-xl">
                    <p className="text-slate-500 text-sm">Nenhuma sala de conferência criada ainda.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {rooms.map((r) => (
                      <div key={r.id} className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start gap-2">
                            <div>
                              <h4 className="font-bold text-white text-base">{r.name}</h4>
                              <p className="text-emerald-400/90 font-mono text-xs mt-0.5 truncate">{r.jid}</p>
                            </div>
                            <button
                              onClick={() => handleDeleteRoom(r.id, r.name)}
                              className="p-1 rounded bg-slate-900 border border-slate-800 text-red-400 hover:text-red-300 hover:border-red-950/40 transition cursor-pointer"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>

                          <div className="mt-3 border-t border-slate-900 pt-3">
                            <p className="text-xs text-slate-300 font-semibold flex items-center gap-1">
                              Tema: <span className="font-normal text-slate-400">{r.theme}</span>
                            </p>
                            {r.description && (
                              <p className="text-xs text-slate-400 mt-1 italic">"{r.description}"</p>
                            )}
                          </div>
                        </div>

                        <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs text-slate-500">
                          <span>Criado em {new Date(r.createdAt).toLocaleDateString()}</span>
                          <strong className="text-emerald-500">{r.participants.length} participante(s)</strong>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'install' && (
          <InstallScriptView onBack={() => setActiveTab('users')} />
        )}

        {activeTab === 'config' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-2xl mx-auto">
            <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <Settings className="text-emerald-400" size={18} />
              Configurações da API do Mercado Pago
            </h3>
            <p className="text-slate-400 text-xs mb-6">
              Insira as chaves necessárias da sua conta do Mercado Pago para gerenciar as assinaturas e pagamentos de manutenção via PIX.
            </p>

            <form onSubmit={handleSaveConfig} className="space-y-6">
              {configSuccess && (
                <div className="p-3 bg-emerald-950/50 border border-emerald-900/40 text-emerald-400 rounded-xl text-xs">
                  {configSuccess}
                </div>
              )}
              {configError && (
                <div className="p-3 bg-red-950/50 border border-red-900/40 text-red-400 rounded-xl text-xs">
                  {configError}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                    Access Token (Produção / Sandbox)
                  </label>
                  <input
                    type="password"
                    placeholder="APP_USR-..."
                    value={mpAccessToken}
                    onChange={(e) => setMpAccessToken(e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none transition font-mono"
                    required
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Sua chave de acesso privado (Começa com APP_USR-).</p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                    Public Key (Chave Pública)
                  </label>
                  <input
                    type="text"
                    placeholder="APP_USR-..."
                    value={mpPublicKey}
                    onChange={(e) => setMpPublicKey(e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none transition font-mono"
                    required
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Sua chave pública (Começa com APP_USR-).</p>
                </div>

                <div className="p-4 bg-slate-950/50 border border-slate-800/60 rounded-xl space-y-3">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Endereços para cadastro no Mercado Pago</h4>
                  
                  <div className="space-y-2">
                    <div>
                      <span className="text-[10px] text-slate-500 font-mono block">URI de Redirecionamento (Redirect URL)</span>
                      <code className="text-xs text-indigo-400 break-all select-all block font-mono bg-slate-950 p-2 rounded mt-1 border border-slate-900">{mpRedirectUrl || 'Carregando...'}</code>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 font-mono block">URL de Notificação Webhook (Webhook URL)</span>
                      <code className="text-xs text-emerald-400 break-all select-all block font-mono bg-slate-950 p-2 rounded mt-1 border border-slate-900">{mpWebhookUrl || 'Carregando...'}</code>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-normal">
                    * Informe esses endereços no seu painel de desenvolvedor do Mercado Pago para garantir o redirecionamento pós-pagamento e a aprovação automática via Webhook instantâneo.
                  </p>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('users')}
                  className="px-5 py-2.5 rounded-xl border border-slate-800 hover:bg-slate-950 text-slate-400 text-sm font-medium transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-bold transition shadow-lg shadow-emerald-950/60 cursor-pointer"
                >
                  Salvar Configurações
                </button>
              </div>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
