import React, { useState } from 'react';
import { ArrowLeft, Shield, Mail, Lock, Calendar, FileText, CheckCircle2, ChevronRight, KeyRound, Sparkles } from 'lucide-react';

interface ResetPasswordFormProps {
  onBack: () => void;
  onLoginSuccess: (user: any) => void;
}

export default function ResetPasswordForm({ onBack, onLoginSuccess }: ResetPasswordFormProps) {
  // Modes: 'reset' | 'login'
  const [activeTab, setActiveTab] = useState<'reset' | 'login'>('reset');

  // Step for reset: 1 = verification, 2 = set new password, 3 = success
  const [resetStep, setResetStep] = useState<1 | 2 | 3>(1);

  // Verification fields
  const [email, setEmail] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [cpf, setCpf] = useState('');

  // Password update fields
  const [userId, setUserId] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Quick Login fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Status/Error messages
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Client-side CPF formatting
  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const clean = rawVal.replace(/[^\d]/g, '');
    let formatted = clean;
    if (clean.length > 3) {
      formatted = `${clean.slice(0, 3)}.${clean.slice(3)}`;
    }
    if (clean.length > 6) {
      formatted = `${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6)}`;
    }
    if (clean.length > 9) {
      formatted = `${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6, 9)}-${clean.slice(9, 11)}`;
    }
    setCpf(formatted.slice(0, 14));
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email || !birthDate || !cpf) {
      setError('Por favor, preencha todos os campos.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/reset-password/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, birthDate, cpf })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Não foi possível verificar as informações.');
      }

      setUserId(data.userId);
      setResetStep(2);
    } catch (err: any) {
      setError(err.message || 'Erro na verificação dos dados.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!newPassword || !confirmPassword) {
      setError('Por favor, digite e confirme a nova senha.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('As senhas digitadas não coincidem.');
      return;
    }

    if (newPassword.length < 6) {
      setError('A nova senha deve possuir ao menos 6 caracteres.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/reset-password/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, password: newPassword })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao redefinir senha.');
      }

      setResetStep(3);
      setSuccess('Senha redefinida com sucesso! Você já pode entrar com sua nova senha.');
    } catch (err: any) {
      setError(err.message || 'Houve um erro na atualização da senha.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuickLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!loginEmail || !loginPassword) {
      setError('Por favor, digite seu e-mail e senha.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jid: loginEmail, password: loginPassword })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'E-mail ou senha incorretos.');
      }

      onLoginSuccess(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao realizar login.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none" id="reset_password_portal_wrapper">
      
      {/* Background ambient light */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-600/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-emerald-600/5 blur-[120px] pointer-events-none" />

      {/* Back button */}
      <button 
        onClick={onBack}
        className="absolute top-6 left-6 flex items-center gap-2 text-slate-400 hover:text-white text-xs font-semibold font-mono bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 transition cursor-pointer"
      >
        <ArrowLeft size={14} />
        <span>Voltar</span>
      </button>

      {/* Main Card */}
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl z-10 space-y-6">
        
        {/* Toggle tabs for Reset vs Login */}
        <div className="flex border-b border-slate-800 pb-1">
          <button
            onClick={() => {
              setActiveTab('reset');
              setError('');
              setSuccess('');
            }}
            className={`flex-1 pb-3 text-center text-xs font-bold uppercase tracking-wider transition relative ${activeTab === 'reset' ? 'text-white' : 'text-slate-500 hover:text-slate-400'}`}
          >
            <span>Recuperar Conta</span>
            {activeTab === 'reset' && (
              <span className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-indigo-500" />
            )}
          </button>
          
          <button
            onClick={() => {
              setActiveTab('login');
              setError('');
              setSuccess('');
            }}
            className={`flex-1 pb-3 text-center text-xs font-bold uppercase tracking-wider transition relative ${activeTab === 'login' ? 'text-white' : 'text-slate-500 hover:text-slate-400'}`}
          >
            <span>Fazer Login</span>
            {activeTab === 'login' && (
              <span className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-indigo-500" />
            )}
          </button>
        </div>

        {/* Dynamic header depending on stage/tab */}
        <div className="text-center">
          <div className="mx-auto w-10 h-10 bg-indigo-600/10 border border-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400 mb-3 shadow-xl">
            <KeyRound size={20} />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            {activeTab === 'reset' 
              ? (resetStep === 1 ? 'Redefinir Senha' : resetStep === 2 ? 'Nova Senha' : 'Sucesso!')
              : 'Acessar Conta'}
          </h1>
          <p className="text-slate-400 text-xs mt-1">
            {activeTab === 'reset'
              ? (resetStep === 1 
                  ? 'Confirme seus dados cadastrados para prosseguir' 
                  : resetStep === 2 
                    ? 'Digite sua nova senha de acesso seguro' 
                    : 'Acesso reestabelecido com sucesso!')
              : 'Entre com seu e-mail e senha cadastrados'}
          </p>
        </div>

        {/* Global Feedback Messages */}
        {error && (
          <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-xs flex items-center gap-2">
            <Shield size={14} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 rounded-xl text-xs flex items-center gap-2">
            <CheckCircle2 size={14} className="shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* RESET FLOW PANEL */}
        {activeTab === 'reset' && (
          <div className="space-y-4">
            
            {/* Step 1: Verify Account Information */}
            {resetStep === 1 && (
              <form onSubmit={handleVerify} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Endereço de E-mail</label>
                  <div className="relative">
                    <input
                      type="email"
                      placeholder="exemplo@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl pl-10 pr-4 py-2.5 text-xs text-white"
                      required
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                      <Mail size={14} />
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Data de Nascimento</label>
                  <div className="relative">
                    <input
                      type="date"
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl px-4 py-2 text-xs text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">CPF Cadastrado</label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="000.000.000-00"
                      value={cpf}
                      onChange={handleCpfChange}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl pl-10 pr-4 py-2.5 text-xs text-white font-mono"
                      required
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                      <FileText size={14} />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-bold text-xs tracking-wide rounded-xl transition shadow-lg disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 mt-2"
                >
                  <span>{submitting ? 'Verificando Cadastro...' : 'Confirmar & Redefinir Senha'}</span>
                  <ChevronRight size={14} />
                </button>
              </form>
            )}

            {/* Step 2: Set New Password */}
            {resetStep === 2 && (
              <form onSubmit={handleUpdatePassword} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Nova Senha</label>
                  <div className="relative">
                    <input
                      type="password"
                      placeholder="••••••••"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl pl-10 pr-4 py-2.5 text-xs text-white"
                      required
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                      <Lock size={14} />
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Confirmar Nova Senha</label>
                  <div className="relative">
                    <input
                      type="password"
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl pl-10 pr-4 py-2.5 text-xs text-white"
                      required
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                      <Lock size={14} />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-bold text-xs tracking-wide rounded-xl transition shadow-lg disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>{submitting ? 'Salvando Nova Senha...' : 'Salvar Nova Senha'}</span>
                </button>
              </form>
            )}

            {/* Step 3: Success Screen */}
            {resetStep === 3 && (
              <div className="space-y-4 text-center">
                <div className="p-3 bg-emerald-950/20 border border-emerald-900/30 rounded-2xl text-emerald-400 flex flex-col items-center gap-2 py-6">
                  <CheckCircle2 size={32} className="text-emerald-400 mb-1" />
                  <span className="text-sm font-semibold">Tudo Pronto!</span>
                  <p className="text-xs text-slate-400 max-w-xs px-2">
                    Sua senha foi redefinida com êxito. Utilize a aba acima "Fazer Login" ou clique abaixo para acessar seu painel instantaneamente.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setActiveTab('login');
                    setError('');
                    setSuccess('');
                  }}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs tracking-wide rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>Ir para o Formulário de Login</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* LOGIN PANEL */}
        {activeTab === 'login' && (
          <form onSubmit={handleQuickLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">E-mail ou JID</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="exemplo@email.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl pl-10 pr-4 py-2.5 text-xs text-white"
                  required
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                  <Mail size={14} />
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Senha de Acesso</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:outline-none rounded-xl pl-10 pr-4 py-2.5 text-xs text-white"
                  required
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                  <Lock size={14} />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-xs tracking-wide rounded-xl transition shadow-lg disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 mt-2"
            >
              <span>{submitting ? 'Efetuando Login...' : 'Entrar na Conta'}</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
