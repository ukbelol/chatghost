import { useState } from 'react';
import { Copy, Check, Download, Ghost, Key, Shield, Code, Terminal, Cpu } from 'lucide-react';

interface InstallScriptViewProps {
  onBack?: () => void;
}

export default function InstallScriptView({ onBack }: InstallScriptViewProps) {
  const [copied, setCopied] = useState(false);

  const scriptContent = `#!/bin/bash
# ==============================================================================
# CHAT GHOST - SECURE XMPP SERVER INSTALLATION SCRIPT
# Target OS: Linux Debian 12 (Bookworm)
# Server Architecture: Prosody XMPP Server + Nginx SSL Reverse Proxy + Certbot
# Domain: chatghost.smartmall577.space
# Admin JID: newest@chatghost.smartmall577.space
# Security Email: rogermei577@gmail.com
# ==============================================================================

set -e

GREEN='\\033[0;32m'
PURPLE='\\033[0;35m'
BLUE='\\033[0;34m'
YELLOW='\\033[1;33m'
RED='\\033[0;31m'
NC='\\033[0m'

echo -e "\${BLUE}===================================================================\${NC}"
echo -e "\${PURPLE}          CHAT GHOST XMPP INTEGRATED SERVICE AUTOMATIC INSTALLER     \${NC}"
echo -e "\${BLUE}===================================================================\${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "\${RED}Error: This script must be run as root (sudo).\${NC}"
  exit 1
fi

echo -e "\\n\${YELLOW}[1/7] Updating system packages...\${NC}"
apt-get update && apt-get upgrade -y

echo -e "\\n\${YELLOW}[2/7] Installing dependencies...\${NC}"
apt-get install -y curl gnupg2 lsb-release ca-certificates certbot python3-certbot-nginx ufw git build-essential

echo -e "\\n\${YELLOW}[3/7] Setting up Prosody official repository...\${NC}"
mkdir -p /etc/apt/keyrings
curl -fsSL https://prosody.im/files/prosody-debian-packages.key | gpg --dearmor -o /etc/apt/keyrings/prosody.gpg
echo "deb [signed-by=/etc/apt/keyrings/prosody.gpg] http://packages.prosody.im/debian $(lsb_release -sc) main" > /etc/apt/sources.list.d/prosody.list
apt-get update
apt-get install -y prosody lua-sec lua-socket lua-expat lua-filesystem lua-dbi-sqlite3

echo -e "\\n\${YELLOW}Downloading community modules for WebSockets & WebRTC...\${NC}"
mkdir -p /usr/lib/prosody-modules
git clone https://hg.prosody.im/prosody-modules/ /tmp/prosody-modules
cp -r /tmp/prosody-modules/mod_websocket /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_turn_external /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_csi_simple /usr/lib/prosody-modules/ || true

echo -e "\\n\${YELLOW}[4/7] Generating Prosody configuration file...\${NC}"
cat << 'EOF' > /etc/prosody/prosody.cfg.lua
plugin_paths = { "/usr/lib/prosody-modules" }
modules_enabled = {
    "roster"; "saslauth"; "tls"; "dialback"; "disco"; "private";
    "vcard4"; "vcard"; "websocket"; "bosh"; "carbons"; "pep";
    "adhoc"; "admin_adhoc"; "mam"; "csi_simple"; "blocklist"; "ping";
}
allow_registration = false;
c2s_require_encryption = true;
s2s_require_encryption = true;
certificates = "/etc/prosody/certs"
log = {
    info = "/var/log/prosody/prosody.log";
    error = "/var/log/prosody/prosody.err";
}

VirtualHost "chatghost.smartmall577.space"
    ssl = {
        key = "/etc/prosody/certs/chatghost.smartmall577.space.key";
        certificate = "/etc/prosody/certs/chatghost.smartmall577.space.crt";
    }

Component "conference.chatghost.smartmall577.space" "muc"
    restrict_room_creation = "admin"
    modules_enabled = { "muc_mam" }

Component "turn.chatghost.smartmall577.space" "turn_external"
    turn_external_host = "chatghost.smartmall577.space"
    turn_external_port = 3478
    turn_external_secret = "chatghost-webrtc-secure-turn-key-577"
EOF

echo -e "\\n\${YELLOW}[5/7] Requesting Let's Encrypt SSL certificates...\${NC}"
mkdir -p /etc/prosody/certs
chown -R prosody:prosody /etc/prosody/certs
systemctl stop nginx || true
certbot certonly --standalone -d chatghost.smartmall577.space --non-interactive --agree-tos -m rogermei577@gmail.com --preferred-challenges http

cp /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem /etc/prosody/certs/chatghost.smartmall577.space.key
cp /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem /etc/prosody/certs/chatghost.smartmall577.space.crt
chown -R prosody:prosody /etc/prosody/certs/
chmod 640 /etc/prosody/certs/*.key || true

echo -e "\\n\${YELLOW}[6/7] Configuring Nginx Reverse Proxy...\\n"
cat << 'EOF' > /etc/nginx/sites-available/chatghost
server {
    listen 80;
    server_name chatghost.smartmall577.space;
    return 301 https://$host$request_uri;
}
server {
    listen 443 ssl;
    server_name chatghost.smartmall577.space;
    ssl_certificate /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    root /var/www/chatghost/dist;
    index index.html;
    location / {
        try_files $uri $uri/ /index.html;
    }
    location /xmpp-websocket {
        proxy_pass http://127.0.0.1:5280/xmpp-websocket;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400;
    }
}
EOF
ln -sf /etc/nginx/sites-available/chatghost /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default || true
mkdir -p /var/www/chatghost/dist

echo -e "\\n\${YELLOW}[7/7] Registering Super Admin account...\${NC}"
prosodyctl register newest chatghost.smartmall577.space blackangel@577-NHT || echo "Já registrado"

echo -e "\\n\${YELLOW}Configuring Firewall (UFW)...\${NC}"
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5222/tcp
ufw allow 5269/tcp
ufw allow 5280/tcp
ufw allow 3478/udp
ufw allow 5349/tcp
ufw --force enable || true

systemctl restart nginx
systemctl restart prosody
echo -e "\\n\${GREEN}===================================================================\${NC}"
echo -e "\${GREEN}          CHAT GHOST INSTALLATION COMPLETED SUCCESSFULLY!             \${NC}"
echo -e "==================================================================="`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(scriptContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([scriptContent], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = "install-chatghost.sh";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl" id="install_script_view_container">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 mb-6 gap-4">
        <div>
          <span className="text-purple-400 font-semibold text-xs tracking-wider uppercase bg-purple-950/50 border border-purple-900/50 px-2.5 py-1 rounded-full flex items-center gap-1.5 w-fit mb-2 animate-pulse">
            <Cpu size={12} />
            Debian 12 Bootstrapper
          </span>
          <h2 className="text-2xl font-bold text-white tracking-tight">Script de Instalação Automatizada</h2>
          <p className="text-slate-400 text-sm mt-1">Configurado especialmente para o domínio <code className="text-purple-300 font-mono">chatghost.smartmall577.space</code></p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <button
            onClick={copyToClipboard}
            id="btn_copy_script"
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 transition font-medium text-sm border border-slate-700 cursor-pointer"
          >
            {copied ? (
              <>
                <Check size={16} className="text-purple-400" />
                <span className="text-purple-400">Copiado!</span>
              </>
            ) : (
              <>
                <Copy size={16} />
                <span>Copiar Script</span>
              </>
            )}
          </button>
          <button
            onClick={handleDownload}
            id="btn_download_script"
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 text-white hover:bg-purple-500 transition font-semibold text-sm shadow-lg shadow-purple-900/30 cursor-pointer border border-purple-500/20"
          >
            <Download size={16} />
            <span>Download .sh</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-950/60 border border-slate-800/80 p-5 rounded-xl">
          <div className="flex items-center gap-2 text-purple-400 font-bold mb-3">
            <Ghost size={18} />
            <h3>Ambiente do Servidor</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Sistema Operacional</span>
              <strong className="text-white font-mono">Debian 12 x64</strong>
            </li>
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Servidor XMPP Core</span>
              <strong className="text-white">Prosody 0.12+</strong>
            </li>
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Servidor Web / Proxy</span>
              <strong className="text-white">Nginx Stable</strong>
            </li>
            <li className="flex justify-between">
              <span className="text-slate-500">Banco de Dados</span>
              <strong className="text-white font-mono">SQLite (Interno)</strong>
            </li>
          </ul>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 p-5 rounded-xl">
          <div className="flex items-center gap-2 text-purple-400 font-bold mb-3">
            <Shield size={18} />
            <h3>Segurança & SSL</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Domínio Alvo</span>
              <strong className="text-purple-300 font-mono">chatghost.smartmall577.space</strong>
            </li>
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Provedor de Certificado</span>
              <strong className="text-white">Let's Encrypt (Certbot)</strong>
            </li>
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">E-mail de Contato</span>
              <strong className="text-white text-xs">rogermei577@gmail.com</strong>
            </li>
            <li className="flex justify-between">
              <span className="text-slate-500">Firewall (UFW)</span>
              <strong className="text-purple-400">Ativado (80/443/5222)</strong>
            </li>
          </ul>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 p-5 rounded-xl">
          <div className="flex items-center gap-2 text-purple-400 font-bold mb-3">
            <Key size={18} />
            <h3>Acesso do Servidor</h3>
          </div>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Super Admin JID</span>
              <strong className="text-purple-300 font-mono text-xs">newest@chatghost.smartmall577.space</strong>
            </li>
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">Senha Admin</span>
              <strong className="text-white font-mono text-xs">blackangel@577-NHT</strong>
            </li>
            <li className="flex justify-between border-b border-slate-900 pb-1.5">
              <span className="text-slate-500">MUC Subdomain</span>
              <strong className="text-slate-400 font-mono text-xs">conference.*</strong>
            </li>
            <li className="flex justify-between">
              <span className="text-slate-500">STUN/TURN</span>
              <strong className="text-purple-400 font-mono text-xs">turn.chatghost.smartmall577.space</strong>
            </li>
          </ul>
        </div>
      </div>

      {/* Terminal Steps */}
      <div className="mb-6">
        <h3 className="text-white font-semibold text-base mb-3 flex items-center gap-2">
          <Terminal size={18} className="text-slate-400" />
          Como executar no seu VPS Debian 12:
        </h3>
        <div className="bg-black/90 rounded-xl p-4 font-mono text-xs text-slate-300 border border-slate-800 leading-relaxed shadow-inner">
          <p className="text-slate-500 mb-2"># 1. Conecte no seu servidor via SSH e mude para usuário root:</p>
          <p className="text-purple-400 mb-4"><span className="text-slate-600 select-none">$</span> sudo su -</p>

          <p className="text-slate-500 mb-2"># 2. Baixe o script diretamente da API do Chat Ghost:</p>
          <p className="text-purple-400 mb-4"><span className="text-slate-600 select-none">$</span> curl -L -o install-chatghost.sh https://chatghost.smartmall577.space/api/install-script</p>

          <p className="text-slate-500 mb-2"># 3. Dê permissão de execução:</p>
          <p className="text-purple-400 mb-4"><span className="text-slate-600 select-none">$</span> chmod +x install-chatghost.sh</p>

          <p className="text-slate-500 mb-2"># 4. Execute a instalação automatizada total:</p>
          <p className="text-purple-400"><span className="text-slate-600 select-none">$</span> ./install-chatghost.sh</p>
        </div>
      </div>

      {/* Visual Code Console for preview */}
      <div>
        <h3 className="text-white font-semibold text-base mb-3 flex items-center gap-2">
          <Code size={18} className="text-slate-400" />
          Pré-visualização do Script Bash:
        </h3>
        <div className="bg-slate-950 rounded-xl p-4 font-mono text-xs text-slate-400 border border-slate-800 max-h-72 overflow-y-auto leading-relaxed shadow-inner">
          <pre>{scriptContent}</pre>
        </div>
      </div>
    </div>
  );
}
