import React from 'react';
import { Shield, Lock, Server, Cpu, Zap, ArrowRight, CheckCircle, RefreshCw, Key, ShieldCheck, Ghost } from 'lucide-react';

interface LandingPageProps {
  onEnterRestrictedArea: () => void;
}

export default function LandingPage({ onEnterRestrictedArea }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans relative overflow-x-hidden selection:bg-purple-500/30 selection:text-purple-300" id="landing_page_root">
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none animate-pulse duration-[8000ms]" />
      <div className="absolute top-1/3 right-1/4 w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Header */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/10 border border-purple-500/20 rounded-xl flex items-center justify-center text-purple-400 shadow-lg shadow-purple-950/30 animate-bounce duration-[4000ms]">
              <Ghost size={20} className="drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-purple-400 to-emerald-400 bg-clip-text text-transparent">Chat Ghost XMPP</span>
              <span className="text-[10px] text-slate-500 font-mono block">SPECTRAL SECURE MESSAGING</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onEnterRestrictedArea}
              className="bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl font-bold text-sm tracking-wide transition shadow-lg shadow-purple-950/60 flex items-center gap-2 cursor-pointer border border-purple-500/20"
            >
              <span>Área Restrita</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-5xl mx-auto px-6 pt-16 pb-12 text-center relative">
        <div className="inline-flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-full px-4 py-1.5 text-xs text-purple-400 mb-8 animate-pulse">
          <ShieldCheck size={14} className="text-emerald-400" />
          <span className="font-mono tracking-wider uppercase font-semibold">Presença Invisível & Criptografia Indestrutível</span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-white leading-tight mb-6">
          Comunicação Fantasma.<br />
          Sua <span className="bg-gradient-to-r from-purple-400 to-emerald-400 bg-clip-text text-transparent">Privacidade Absoluta</span> Reestabelecida.
        </h1>
        
        <p className="text-slate-400 text-base md:text-xl max-w-3xl mx-auto leading-relaxed mb-10">
          Baseado no robusto protocolo descentralizado XMPP, o <strong className="text-purple-400">Chat Ghost XMPP</strong> oferece uma infraestrutura de comunicação federada e criptografada de ponta a ponta. Converse, envie arquivos e crie salas sem deixar metadados, logs ou rastros.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onEnterRestrictedArea}
            className="w-full sm:w-auto px-8 py-4 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-2xl shadow-xl shadow-purple-950/40 transition flex items-center justify-center gap-2 cursor-pointer text-base border border-purple-500/20"
          >
            <span>Cadastrar e Experimentar Grátis</span>
            <ArrowRight size={18} />
          </button>
          <a
            href="#details"
            className="w-full sm:w-auto px-8 py-4 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 font-semibold rounded-2xl transition flex items-center justify-center gap-2"
          >
            <span>Conhecer Tecnologia</span>
          </a>
        </div>
      </section>

      {/* Subscription Pricing Notification Callout */}
      <section className="max-w-4xl mx-auto px-6 mb-16">
        <div className="bg-gradient-to-br from-slate-900 to-purple-950/30 border border-slate-800 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-[200px] h-[200px] bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="space-y-3 max-w-lg text-left">
            <span className="inline-block px-3 py-1 bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-mono font-bold rounded-lg uppercase tracking-wider">
              Assinatura Transparente
            </span>
            <h3 className="text-xl md:text-2xl font-bold text-white tracking-tight">Período de Testes: 14 dias sem pagar</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Faça o seu cadastro agora e utilize a infraestrutura completa de comunicação de forma gratuita por <strong>14 dias corridos</strong>. Após o período, cobra-se uma taxa de manutenção de <strong>R$ 15,00/mês</strong> via Mercado Pago (PIX) para manter sua conta ativa.
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 text-center shrink-0 w-full md:w-60">
            <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider block">Taxa Mensal</span>
            <span className="text-4xl font-extrabold text-white font-mono block mt-1">R$ 15,00</span>
            <span className="text-[11px] text-purple-400 font-mono block mt-2">14 Dias Grátis Primeiro</span>
            <button
              onClick={onEnterRestrictedArea}
              className="mt-4 w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Criar Minha Conta
            </button>
          </div>
        </div>
      </section>

      {/* Feature grid & XMPP details */}
      <section id="details" className="max-w-6xl mx-auto px-6 py-12 border-t border-slate-900">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white tracking-tight mb-4">Arquitetura de Segurança XMPP em Detalhes</h2>
          <p className="text-slate-400 max-w-2xl mx-auto text-sm leading-relaxed">
            O XMPP (Extensible Messaging and Presence Protocol) é o protocolo padrão da IETF que devolve o controle da privacidade aos usuários. Veja por que ele é indestrutível.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Card 1 */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 hover:border-purple-500/20 transition duration-300">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Lock size={22} />
            </div>
            <h3 className="text-lg font-bold text-white">Criptografia OMEMO</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Criptografia de ponta a ponta multi-dispositivo desenvolvida com base no algoritmo Double Ratchet. Suas mensagens são cifradas no remetente e decifradas apenas no destinatário real, impossibilitando que intermediários ou administradores de redes acessem a conversa.
            </p>
            <ul className="text-[11px] text-slate-500 font-mono space-y-1">
              <li>• Perfect Forward Secrecy</li>
              <li>• Chaves Rotativas Efêmeras</li>
              <li>• Proteção contra replay attacks</li>
            </ul>
          </div>

          {/* Card 2 */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 hover:border-purple-500/20 transition duration-300">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Shield size={22} />
            </div>
            <h3 className="text-lg font-bold text-white">Canal TLS 1.3 Obrigatório</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              A conexão entre o seu aplicativo cliente (Conversations, Dino, ChatSecure) e o nosso servidor Debian é blindada com Transport Layer Security (TLS 1.3), o mesmo nível de segurança exigido em transações financeiras internacionais, mitigando ataques de interceptação (Man-In-The-Middle).
            </p>
            <ul className="text-[11px] text-slate-500 font-mono space-y-1">
              <li>• Certificados SSL automáticos</li>
              <li>• Algoritmos de cifra modernos (Chacha20)</li>
              <li>• Zero metadados trafegando abertamente</li>
            </ul>
          </div>

          {/* Card 3 */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 hover:border-purple-500/20 transition duration-300">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Cpu size={22} />
            </div>
            <h3 className="text-lg font-bold text-white">Debian 12 Open-Source Cluster</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              O nosso backend roda exclusivamente em instâncias Debian 12 endurecidas (Hardened), rodando o servidor open-source Prosody. Nenhum software proprietário tem acesso ao banco de dados ou ao fluxo de informações. Você tem transparência e auditoria completa do ecossistema.
            </p>
            <ul className="text-[11px] text-slate-500 font-mono space-y-1">
              <li>• Sem logs de mensagens</li>
              <li>• Limpeza automática de banco de dados</li>
              <li>• Docker containers isolados em Cloud Run</li>
            </ul>
          </div>

        </div>
      </section>

      {/* Tech Specifications */}
      <section className="bg-slate-950 border-t border-slate-900 py-16">
        <div className="max-w-5xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 bg-purple-500/10 border border-purple-500/20 rounded-lg px-3 py-1 text-xs text-purple-300 font-mono font-bold">
              ESPECIFICAÇÕES DO PROTOCOLO
            </div>
            <h2 className="text-3xl font-bold tracking-tight text-white">Controle total do seu endereço de comunicação</h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Ao se cadastrar, você define um nickname único que gera um endereço global do protocolo XMPP (JID). Esse endereço é compatível com qualquer aplicativo XMPP do planeta. Conecte-se de qualquer plataforma sem depender de um app proprietário centralizador.
            </p>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <CheckCircle size={18} className="text-purple-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-white">XEP-0198 (Mensagens Resilientes)</h4>
                  <p className="text-slate-500 text-xs">Mantém seu estado ativo e enfileira as mensagens quando sua internet cai, entregando imediatamente assim que reestabelecer.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle size={18} className="text-purple-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-white">Multi-User Chat (MUC)</h4>
                  <p className="text-slate-500 text-xs">Criação de salas de conferência persistentes para equipes com total segurança de criptografia de ponta a ponta.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle size={18} className="text-purple-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-white">WebRTC Integrado (Jingle)</h4>
                  <p className="text-slate-500 text-xs">Chamadas de voz e videoconferência peer-to-peer integradas sem servidores intermediários interceptando o áudio.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative">
            <div className="absolute top-4 right-4 text-[9px] font-mono text-slate-500 bg-slate-950 px-2 py-1 rounded border border-slate-800 uppercase tracking-widest">
              Live Connection Specs
            </div>
            
            <h3 className="text-lg font-mono font-bold text-slate-200">XMPP SERVER ACCESS</h3>
            
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-wider block">Endereço do Servidor</span>
                <span className="font-mono text-purple-400 font-bold select-all block text-sm">chatghost.smartmall577.space</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5">
                  <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-wider block">Porta de Entrada</span>
                  <span className="font-mono text-white font-bold block text-sm">5222 (STARTTLS)</span>
                </div>
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5">
                  <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-wider block">Autenticação</span>
                  <span className="font-mono text-white font-bold block text-sm">SCRAM-SHA-1/256</span>
                </div>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-wider block">Websocket Endpoint (Para Clientes Web)</span>
                <span className="font-mono text-purple-400 block text-xs truncate">wss://chatghost.smartmall577.space/xmpp-websocket</span>
              </div>
            </div>

            <div className="text-center pt-4 border-t border-slate-800/60">
              <button
                onClick={onEnterRestrictedArea}
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-emerald-600 hover:from-purple-500 hover:to-emerald-500 text-white font-bold text-sm tracking-wide rounded-xl transition cursor-pointer border border-purple-500/20"
              >
                Registrar Novo Login Agora
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-12 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-purple-500/10 border border-purple-500/20 rounded-md flex items-center justify-center text-purple-400">
              <Ghost size={14} className="drop-shadow-[0_0_4px_rgba(168,85,247,0.5)]" />
            </div>
            <span className="font-bold text-slate-300 font-mono">CHAT GHOST XMPP COMMUNICATIONS</span>
          </div>

          <div className="flex items-center gap-6 text-[11px] font-mono">
            <span>SSL: SECURE TLS 1.3</span>
            <span>•</span>
            <span>MUC: ACTIVE</span>
            <span>•</span>
            <span>ADMIN: rogue-577</span>
          </div>

          <div>
            <span>© {new Date().getFullYear()} Chat Ghost XMPP. Todos os direitos reservados.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
