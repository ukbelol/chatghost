#!/bin/bash
# ==============================================================================
# CHAT GHOST XMPP - FULLY AUTOMATED RESILIENT STANDUP BOOTSTRAPPER (install-gerall.sh)
# Target OS: Debian 12 (Bookworm) / Ubuntu 22.04 LTS or newer
# Target Domain: chatghost.smartmall577.space
# Core Services: Prosody XMPP (v0.12+) + Nginx Web Server + Let's Encrypt SSL
# Author: Chat Ghost Deployment Team
# ==============================================================================

# Exit immediately if any command fails
set -e

# Disable interactive prompts during apt-get operations
export DEBIAN_FRONTEND=noninteractive

# Clear screen for professional terminal visual flow
clear

# ANSI Color Codes for beautiful output
GREEN='\033[0;32m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}===================================================================${NC}"
echo -e "${PURPLE}       CHAT GHOST XMPP PLATFORM - INTEGRATED RESILIENT BOOTSTRAPPER      ${NC}"
echo -e "${BLUE}===================================================================${NC}"
echo -e " Alvo de Domínio:     ${GREEN}chatghost.smartmall577.space${NC}"
echo -e " Email de Segurança:  ${GREEN}rogermei577@gmail.com${NC}"
echo -e " Sistema Homologado:  ${GREEN}Debian 12 (Bookworm) ou Ubuntu LTS${NC}"
echo -e " Status Alvo:         ${YELLOW}IMPLANTAÇÃO TOTAL E COLOCAR EM PRODUÇÃO${NC}"
echo -e "${BLUE}===================================================================${NC}"

# Ensure script is executed as Superuser (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERRO] Este script precisa ser executado como root (Superusuário).${NC}"
  echo -e "Por favor, mude para root executando: ${YELLOW}sudo su -${NC} e rode o script novamente."
  exit 1
fi

# Detect operating system
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_NAME=$ID
    OS_VERSION=$VERSION_ID
    echo -e "${GREEN}[INFO] Sistema operacional detectado: $OS_NAME $OS_VERSION${NC}"
else
    echo -e "${YELLOW}[AVISO] Não foi possível verificar os metadados do SO. Continuando...${NC}"
fi

# ==============================================================================
# PASSO INICIAL: REPARAR ERROS DE DPKG / APT-GET ANTERIORES
# ==============================================================================
echo -e "\n${YELLOW}[Passo Inicial] Corrigindo e reparando o gerenciador de pacotes dpkg/apt...${NC}"
dpkg --configure -a || true
apt-get install -f -y || true
apt-get clean
apt-get update

# Removendo repositório antigo do Prosody se houver para reinstalação limpa
echo -e "${YELLOW}Removendo repositório e fontes antigas do Prosody para evitar conflitos...${NC}"
rm -f /etc/apt/sources.list.d/prosody.list || true

# ==============================================================================
# PASSO 1: INSTALAR FERRAMENTAS BÁSICAS E DEPENDÊNCIAS DO SISTEMA (INCLUINDO MERCURIAL)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 1/12] Instalando utilitários essenciais e controle de versão (Mercurial + Git)...${NC}"
apt-get install -y --no-install-recommends \
  curl \
  gnupg2 \
  lsb-release \
  ca-certificates \
  git \
  mercurial \
  build-essential \
  unzip \
  openssl \
  sqlite3 \
  libsqlite3-dev

# ==============================================================================
# PASSO 2: INSTALAR DEPENDÊNCIAS DO WEB SERVER (NGINX)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 2/12] Instalando o Web Server Nginx e Certbot para SSL...${NC}"
apt-get install -y --no-install-recommends \
  nginx \
  certbot \
  python3-certbot-nginx

# ==============================================================================
# PASSO 3: INSTALAR O NODE.JS (V20 LTS) E CONFIGURAÇÃO NPM
# ==============================================================================
echo -e "\n${YELLOW}[Passo 3/12] Configurando ambiente de execução Node.js para o Web Client...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Baixando e instalando o Node.js v20 LTS de forma independente...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo -e "${GREEN}[OK] Node.js já está instalado na versão: $(node -v)${NC}"
fi

# ==============================================================================
# PASSO 4: INSTALAR DEPENDÊNCIAS DE LUA COMPATÍVEIS COM O PROSODY
# ==============================================================================
echo -e "\n${YELLOW}[Passo 4/12] Instalando pacotes Lua e bibliotecas de banco/criptografia...${NC}"
apt-get install -y \
  lua5.2 \
  lua5.3 \
  lua-sec \
  lua-socket \
  lua-expat \
  lua-filesystem \
  lua-dbi-sqlite3 \
  lua-dbi-mysql \
  lua-dbi-postgresql \
  lua-zlib \
  lua-unbound || true

# ==============================================================================
# PASSO 5: CONFIGURAR REPOSITÓRIO OFICIAL DO PROSODY E INSTALAR SERVIDOR
# ==============================================================================
echo -e "\n${YELLOW}[Passo 5/12] Registrando chaves e instalando a versão mais recente do Prosody...${NC}"
mkdir -p /etc/apt/keyrings
curl -fsSL https://prosody.im/files/prosody-debian-packages.key | gpg --dearmor -o /etc/apt/keyrings/prosody.gpg || true

# Adiciona o repositório oficial do Prosody à lista de fontes
echo "deb [signed-by=/etc/apt/keyrings/prosody.gpg] http://packages.prosody.im/debian $(lsb_release -sc) main" > /etc/apt/sources.list.d/prosody.list

apt-get update
echo -e "${YELLOW}Instalando Prosody Core via gerenciador de pacotes...${NC}"
apt-get install -y prosody || {
  echo -e "${RED}[AVISO] Tentativa com o repositório oficial falhou. Instalando versão padrão estável...${NC}"
  apt-get install -y prosody --fix-broken --fix-missing
}

# ==============================================================================
# PASSO 6: BAIXAR MÓDULOS DE COMUNIDADE PROSODY USANDO MERCURIAL (HG CLONE)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 6/12] Baixando módulos comunitários atualizados via Mercurial (hg clone)...${NC}"
# Removendo diretórios antigos se houver para garantir uma nova instalação 100% limpa
rm -rf /usr/lib/prosody-modules || true
rm -rf /tmp/prosody-modules || true

echo -e "${YELLOW}Clonando repositório oficial de módulos Prosody via hg...${NC}"
hg clone https://hg.prosody.im/prosody-modules/ /tmp/prosody-modules || {
  echo -e "${RED}[ERRO] O clone via Mercurial falhou. Tentando download do arquivo zip estável...${NC}"
  curl -L -o /tmp/prosody-modules.zip https://hg.prosody.im/prosody-modules/archive/tip.zip
  unzip -q /tmp/prosody-modules.zip -d /tmp/
  mv /tmp/prosody-modules-* /tmp/prosody-modules
}

# Configurar pasta final dos plugins adicionais do Prosody
mkdir -p /usr/lib/prosody-modules
cp -r /tmp/prosody-modules/mod_websocket /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_turn_external /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_csi_simple /usr/lib/prosody-modules/ || true

# Limpeza de arquivos temporários
rm -rf /tmp/prosody-modules /tmp/prosody-modules.zip || true

# ==============================================================================
# PASSO 7: DEPLOY DA CONFIGURAÇÃO DO PROSODY (PROSODY.CFG.LUA)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 7/12] Aplicando configurações do Chat Ghost no Prosody...${NC}"
cat << 'EOF' > /etc/prosody/prosody.cfg.lua
-- CHAT GHOST SECURE MESSAGING SERVER CONFIG
-- Domain: chatghost.smartmall577.space

-- Modules path pointing to community folder
plugin_paths = { "/usr/lib/prosody-modules" }

-- Enabled modules list
modules_enabled = {
    -- Basic features
    "roster"; 
    "saslauth"; 
    "tls"; 
    "dialback"; 
    "disco"; 
    "private"; 
    "vcard4"; 
    "vcard"; 

    -- Advanced features for modern Web Clients
    "websocket"; 
    "bosh"; 
    "carbons"; -- History sync across devices
    "pep"; -- Avatars and profiles
    "adhoc"; 
    "admin_adhoc"; 
    "mam"; -- Message Archive Management
    "csi_simple"; -- Client State Indication
    "blocklist"; 
    "ping"; 
}

-- Force security parameters
allow_registration = false;
c2s_require_encryption = true;
s2s_require_encryption = true;

-- Directory for Let's Encrypt symbolic linked keys
certificates = "/etc/prosody/certs"

-- Logs configuration
log = {
    info = "/var/log/prosody/prosody.log";
    error = "/var/log/prosody/prosody.err";
}

-- Host settings
VirtualHost "chatghost.smartmall577.space"
    ssl = {
        key = "/etc/prosody/certs/chatghost.smartmall577.space.key";
        certificate = "/etc/prosody/certs/chatghost.smartmall577.space.crt";
    }

-- Multi-User Chat rooms
Component "conference.chatghost.smartmall577.space" "muc"
    restrict_room_creation = "admin"
    modules_enabled = { "muc_mam" }

-- WebRTC TURN/STUN helper server integration
Component "turn.chatghost.smartmall577.space" "turn_external"
    turn_external_host = "chatghost.smartmall577.space"
    turn_external_port = 3478
    turn_external_secret = "chatghost-webrtc-secure-turn-key-577"
EOF

# ==============================================================================
# PASSO 8: PROVER CERTIFICADOS SSL COM CERTBOT LET'S ENCRYPT
# ==============================================================================
echo -e "\n${YELLOW}[Passo 8/12] Provisionando certificados SSL válidos...${NC}"
mkdir -p /etc/prosody/certs
chown -R prosody:prosody /etc/prosody/certs

# Libera momentaneamente a porta 80 parando o Nginx
systemctl stop nginx || true
systemctl stop prosody || true

echo -e "${YELLOW}Solicitando certificado oficial da Let's Encrypt para o domínio chatghost.smartmall577.space...${NC}"
certbot certonly --standalone -d chatghost.smartmall577.space --non-interactive --agree-tos -m rogermei577@gmail.com --preferred-challenges http || {
  echo -e "${RED}[AVISO] O Certbot falhou na geração do certificado. Criando certificados auto-assinados de backup...${NC}"
  openssl req -new -newkey rsa:2048 -days 365 -nodes -x509 \
    -subj "/C=BR/ST=SP/L=SaoPaulo/O=ChatGhost/CN=chatghost.smartmall577.space" \
    -keyout /etc/prosody/certs/chatghost.smartmall577.space.key \
    -out /etc/prosody/certs/chatghost.smartmall577.space.crt
}

# Importar certificados Let's Encrypt caso tenham sido gerados com sucesso
if [ -d "/etc/letsencrypt/live/chatghost.smartmall577.space" ]; then
    echo -e "${GREEN}[OK] Certificados Let's Encrypt gerados! Importando e aplicando permissões...${NC}"
    cp -L /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem /etc/prosody/certs/chatghost.smartmall577.space.key
    cp -L /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem /etc/prosody/certs/chatghost.smartmall577.space.crt
fi

# Hardening das chaves criptográficas
chown -R prosody:prosody /etc/prosody/certs/
chmod 640 /etc/prosody/certs/*.key || true

# ==============================================================================
# PASSO 9: CONFIGURAR O WEB SERVER VIRTUAL HOST DO NGINX
# ==============================================================================
echo -e "\n${YELLOW}[Passo 9/12] Configurando Nginx Virtual Host e WebSocket Proxy...${NC}"
cat << 'EOF' > /etc/nginx/sites-available/chatghost
server {
    listen 80;
    server_name chatghost.smartmall577.space;
    
    # Redirecionamento permanente para HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name chatghost.smartmall577.space;

    # SSL parameters pointing to generated certificates
    ssl_certificate /etc/prosody/certs/chatghost.smartmall577.space.crt;
    ssl_certificate_key /etc/prosody/certs/chatghost.smartmall577.space.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Document Root do Web Client do Chat Ghost
    root /var/www/chatghost/dist;
    index index.html;

    # Suporte a rotas SPA (Single Page Application)
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Redirecionamento seguro de WebSockets para o Prosody (porta 5280)
    location /xmpp-websocket {
        proxy_pass http://127.0.0.1:5280/xmpp-websocket;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400;
    }

    # BOSH api proxy de fallback
    location /http-bind {
        proxy_pass http://127.0.0.1:5280/http-bind;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

# Ativar configuração e limpar default
ln -sf /etc/nginx/sites-available/chatghost /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default || true

# ==============================================================================
# PASSO 10: COMPILAR E IMPLANTAR O CLIENTE WEB
# ==============================================================================
echo -e "\n${YELLOW}[Passo 10/12] Compilando e gerando arquivos de produção do Web Client...${NC}"
mkdir -p /var/www/chatghost/dist

if [ -f "./package.json" ]; then
    echo -e "${YELLOW}Executando npm install...${NC}"
    npm install
    
    echo -e "${YELLOW}Executando build estático (Vite)...${NC}"
    npm run build
    
    echo -e "${YELLOW}Movendo arquivos para /var/www/chatghost/dist...${NC}"
    cp -r dist/* /var/www/chatghost/dist/
    chown -R www-data:www-data /var/www/chatghost
    echo -e "${GREEN}[OK] Interface Web compilada e hospedada com sucesso!${NC}"
else
    echo -e "${RED}[AVISO] package.json não localizado nesta pasta. O cliente Nginx será servido vazio até você compilar o código.${NC}"
fi

# ==============================================================================
# PASSO 11: REGISTRAR SUPER ADMIN DO SERVIDOR XMPP
# ==============================================================================
echo -e "\n${YELLOW}[Passo 11/12] Registrando Super Administrador 'newest'...${NC}"
prosodyctl register newest chatghost.smartmall577.space blackangel@577-NHT || echo -e "${YELLOW}[AVISO] Usuário admin 'newest' já existe ou falha na inserção automática.${NC}"

# ==============================================================================
# PASSO 12: CONFIGURAR REGRAS DO FIREWALL (UFW)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 12/12] Liberando portas de segurança e infraestrutura no Firewall (UFW)...${NC}"
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 5222/tcp # XMPP Client Connection
    ufw allow 5269/tcp # XMPP Server-to-Server
    ufw allow 5280/tcp # Prosody HTTP/WS
    ufw allow 3478/udp # STUN/TURN UDP
    ufw allow 5349/tcp # STUN/TURN TCP
    ufw --force enable || true
fi

# ==============================================================================
# FINALIZAÇÃO: COLOCAR O SISTEMA 100% ONLINE NO AR
# ==============================================================================
echo -e "\n${YELLOW}[Finalização] Iniciando e ativando todos os serviços integrados...${NC}"
systemctl daemon-reload || true
systemctl restart prosody || true
systemctl restart nginx || true
systemctl enable prosody || true
systemctl enable nginx || true

# Verificação de status
echo -e "\n${GREEN}✔ Status dos serviços em execução:${NC}"
systemctl is-active prosody || echo -e "${RED}Prosody inativo.${NC}"
systemctl is-active nginx || echo -e "${RED}Nginx inativo.${NC}"

echo -e "\n${GREEN}===================================================================${NC}"
echo -e "${GREEN}      PARABÉNS! INSTALAÇÃO DO CHAT GHOST CONCLUÍDA COM SUCESSO!     ${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e " 🚀 Endereço Web:      ${PURPLE}https://chatghost.smartmall577.space${NC}"
echo -e " ⚡ Host XMPP:          ${PURPLE}chatghost.smartmall577.space${NC}"
echo -e " 🔗 WebSocket URL:     ${PURPLE}wss://chatghost.smartmall577.space/xmpp-websocket${NC}"
echo -e " 🔑 Super Admin:       ${PURPLE}newest@chatghost.smartmall577.space${NC}"
echo -e " 🛡 Senha de Acesso:   ${PURPLE}blackangel@577-NHT${NC}"
echo -e " 📧 E-mail Certbot:    ${PURPLE}rogermei577@gmail.com${NC}"
echo -e " 🛡️ Segurança:         ${YELLOW}Acesso restrito apenas ao Super Admin${NC}"
echo -e " 🚫 IP Blacklist:      ${RED}Ativo (3 erros consecutivos bloqueiam a faixa /24)${NC}"
echo -e " 👤 Desenvolvedor:     ${PURPLE}ukbelol@gmail.com${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e "O Chat Ghost XMPP está 100% ONLINE e no ar em produção para uso!"
