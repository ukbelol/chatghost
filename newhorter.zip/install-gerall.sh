#!/bin/bash
# ==============================================================================
# CHAT GHOST XMPP - FULLY AUTOMATED RESILIENT STANDUP BOOTSTRAPPER (install-gerall.sh)
# Target OS: Debian 12 (Bookworm) / Ubuntu 22.04 LTS or newer
# Target Domain: chags.smartmall577.space
# Core Services: Prosody XMPP (v0.12+) + Nginx Web Server + Let's Encrypt SSL
# Author: Chat Ghost Deployment Team
# ==============================================================================

# Exit immediately if any command fails
set -e

# Disable interactive prompts during apt-get operations
export DEBIAN_FRONTEND=noninteractive

# Clear screen for professional terminal visual flow
clear

# ANSI Color Codes for beautiful output
GREEN='\033[0;32m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}===================================================================${NC}"
echo -e "${PURPLE}       CHAT GHOST XMPP PLATFORM - INTEGRATED RESILIENT BOOTSTRAPPER      ${NC}"
echo -e "${BLUE}===================================================================${NC}"
echo -e " Alvo de Domínio:     ${GREEN}chags.smartmall577.space${NC}"
echo -e " Email de Segurança:  ${GREEN}rogermei577@gmail.com${NC}"
echo -e " Sistema Homologado:  ${GREEN}Debian 12 (Bookworm) ou Ubuntu LTS${NC}"
echo -e " Status Alvo:         ${YELLOW}IMPLANTAÇÃO TOTAL E COLOCAR EM PRODUÇÃO${NC}"
echo -e "${BLUE}===================================================================${NC}"

# Ensure script is executed as Superuser (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERRO] Este script precisa ser executado como root (Superusuário).${NC}"
  echo -e "Por favor, mude para root executando: ${YELLOW}sudo su -${NC} e rode o script novamente."
  exit 1
fi

# Detect operating system
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_NAME=$ID
    OS_VERSION=$VERSION_ID
    echo -e "${GREEN}[INFO] Sistema operacional detectado: $OS_NAME $OS_VERSION${NC}"
else
    echo -e "${YELLOW}[AVISO] Não foi possível verificar os metadados do SO. Continuando...${NC}"
fi

# ==============================================================================
# PASSO INICIAL: REPARAR ERROS DE DPKG / APT-GET ANTERIORES
# ==============================================================================
echo -e "\n${YELLOW}[Passo Inicial] Corrigindo e reparando o gerenciador de pacotes dpkg/apt...${NC}"
dpkg --configure -a || true
apt-get install -f -y || true
apt-get clean
apt-get update

# Removendo repositório antigo do Prosody se houver para reinstalação limpa
echo -e "${YELLOW}Removendo repositório e fontes antigas do Prosody para evitar conflitos...${NC}"
rm -f /etc/apt/sources.list.d/prosody.list || true

# ==============================================================================
# PASSO 1: INSTALAR FERRAMENTAS BÁSICAS E DEPENDÊNCIAS DO SISTEMA (INCLUINDO MERCURIAL)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 1/12] Instalando utilitários essenciais e controle de versão (Mercurial + Git)...${NC}"
apt-get install -y --no-install-recommends \
  curl \
  gnupg2 \
  lsb-release \
  ca-certificates \
  git \
  mercurial \
  build-essential \
  unzip \
  openssl \
  sqlite3 \
  libsqlite3-dev \
  coturn

# ==============================================================================
# PASSO 2: VERIFICAR E INSTALAR DEPENDÊNCIAS DO WEB SERVER (NGINX)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 2/12] Verificando e instalando o Web Server Nginx e Certbot para SSL...${NC}"
if ! command -v nginx &> /dev/null || [ ! -d "/etc/nginx" ]; then
    echo -e "${YELLOW}Nginx não encontrado ou diretório de configuração ausente. Instalando Nginx...${NC}"
    apt-get install -y --no-install-recommends \
      nginx \
      certbot \
      python3-certbot-nginx
else
    echo -e "${GREEN}[OK] Nginx já está instalado.${NC}"
    # Se a configuração do Nginx estiver corrompida (ex: devido a múltiplas edições incorretas no nginx.conf), restaura os arquivos padrão
    if ! nginx -t &> /dev/null || [ $(grep -c "sites-enabled" /etc/nginx/nginx.conf 2>/dev/null || echo 0) -gt 1 ]; then
        echo -e "${YELLOW}Aviso: Configuração do Nginx corrompida ou inválida. Restaurando arquivos originais padrão...${NC}"
        apt-get install --reinstall -o Dpkg::Options::="--force-confmiss" -y nginx-common nginx || true
    fi
    apt-get install -y --no-install-recommends \
      certbot \
      python3-certbot-nginx
fi

# Garantir a criação de todos os diretórios necessários do Nginx de forma limpa
echo -e "${YELLOW}Criando e configurando diretórios padrão do Nginx...${NC}"
mkdir -p /etc/nginx
mkdir -p /etc/nginx/sites-available
mkdir -p /etc/nginx/sites-enabled

# ==============================================================================
# PASSO 3: INSTALAR O NODE.JS (V20 LTS) E CONFIGURAÇÃO NPM
# ==============================================================================
echo -e "\n${YELLOW}[Passo 3/12] Configurando ambiente de execução Node.js para o Web Client...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Baixando e instalando o Node.js v20 LTS de forma independente...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo -e "${GREEN}[OK] Node.js já está instalado na versão: $(node -v)${NC}"
fi

# ==============================================================================
# PASSO 4: INSTALAR DEPENDÊNCIAS DE LUA COMPATÍVEIS COM O PROSODY
# ==============================================================================
echo -e "\n${YELLOW}[Passo 4/12] Instalando pacotes Lua e bibliotecas de banco/criptografia...${NC}"
apt-get install -y \
  lua5.2 \
  lua5.3 \
  lua-sec \
  lua-socket \
  lua-expat \
  lua-filesystem \
  lua-dbi-sqlite3 \
  lua-dbi-mysql \
  lua-dbi-postgresql \
  lua-zlib \
  lua-unbound || true

# ==============================================================================
# PASSO 5: CONFIGURAR REPOSITÓRIO OFICIAL DO PROSODY E INSTALAR SERVIDOR
# ==============================================================================
echo -e "\n${YELLOW}[Passo 5/12] Registrando chaves e instalando a versão mais recente do Prosody...${NC}"
mkdir -p /etc/apt/keyrings
curl -fsSL https://prosody.im/files/prosody-debian-packages.key | gpg --dearmor -o /etc/apt/keyrings/prosody.gpg || true

# Adiciona o repositório oficial do Prosody à lista de fontes
echo "deb [signed-by=/etc/apt/keyrings/prosody.gpg] http://packages.prosody.im/debian $(lsb_release -sc) main" > /etc/apt/sources.list.d/prosody.list

apt-get update
echo -e "${YELLOW}Instalando Prosody Core via gerenciador de pacotes...${NC}"
apt-get install -y prosody || {
  echo -e "${RED}[AVISO] Tentativa com o repositório oficial falhou. Instalando versão padrão estável...${NC}"
  apt-get install -y prosody --fix-broken --fix-missing
}

# ==============================================================================
# PASSO 6: BAIXAR MÓDULOS DE COMUNIDADE PROSODY USANDO MERCURIAL (HG CLONE)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 6/12] Baixando módulos comunitários atualizados via Mercurial (hg clone)...${NC}"
# Removendo diretórios antigos se houver para garantir uma nova instalação 100% limpa
rm -rf /usr/lib/prosody-modules || true
rm -rf /tmp/prosody-modules || true

echo -e "${YELLOW}Clonando repositório oficial de módulos Prosody via hg...${NC}"
hg clone https://hg.prosody.im/prosody-modules/ /tmp/prosody-modules || {
  echo -e "${RED}[ERRO] O clone via Mercurial falhou. Tentando download do arquivo zip estável...${NC}"
  curl -L -o /tmp/prosody-modules.zip https://hg.prosody.im/prosody-modules/archive/tip.zip
  unzip -q /tmp/prosody-modules.zip -d /tmp/
  mv /tmp/prosody-modules-* /tmp/prosody-modules
}

# Configurar pasta final dos plugins adicionais do Prosody
mkdir -p /usr/lib/prosody-modules
cp -r /tmp/prosody-modules/mod_websocket /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_turn_external /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_csi_simple /usr/lib/prosody-modules/ || true

# Limpeza de arquivos temporários
rm -rf /tmp/prosody-modules /tmp/prosody-modules.zip || true

# ==============================================================================
# PASSO 7: DEPLOY DA CONFIGURAÇÃO DO PROSODY (PROSODY.CFG.LUA)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 7/12] Aplicando configurações do Chat Ghost no Prosody...${NC}"
cat << 'EOF' > /etc/prosody/prosody.cfg.lua
-- CHAT GHOST SECURE MESSAGING SERVER CONFIG
-- Domain: chags.smartmall577.space

-- Modules path pointing to community folder
plugin_paths = { "/usr/lib/prosody-modules" }

-- Authentication backend (secure hashed passwords)
authentication = "internal_hashed"

-- Enabled modules list
modules_enabled = {
    -- Basic features
    "roster"; 
    "saslauth"; 
    "tls"; 
    "dialback"; 
    "disco"; 
    "private"; 
    "vcard4"; 
    "vcard"; 

    -- Advanced features for modern Web Clients
    "websocket"; 
    "bosh"; 
    "carbons"; -- History sync across devices
    "pep"; -- Avatars and profiles
    "adhoc"; 
    "admin_adhoc"; 
    "mam"; -- Message Archive Management
    "csi_simple"; -- Client State Indication
    "blocklist"; 
    "ping"; 
    "turn_external"; -- Advertise STUN/TURN configuration to clients
}

-- Force security parameters
allow_registration = false;
c2s_require_encryption = true;
s2s_require_encryption = true;

-- Global TURN/STUN Settings for WebRTC Client Discovery (Audio & Video)
turn_external_host = "chags.smartmall577.space"
turn_external_port = 3478
turn_external_secret = "chatghost-webrtc-secure-turn-key-577"

-- Directory for Let's Encrypt symbolic linked keys
certificates = "/etc/prosody/certs"

-- Logs configuration
log = {
    info = "/var/log/prosody/prosody.log";
    error = "/var/log/prosody/prosody.err";
}

-- Host settings
VirtualHost "chags.smartmall577.space"
    authentication = "internal_hashed"
    ssl = {
        key = "/etc/prosody/certs/chags.smartmall577.space.key";
        certificate = "/etc/prosody/certs/chags.smartmall577.space.crt";
    }

-- Multi-User Chat rooms
Component "conference.chags.smartmall577.space" "muc"
    restrict_room_creation = "admin"
    modules_enabled = { "muc_mam" }

-- WebRTC TURN/STUN helper server integration
Component "turn.chags.smartmall577.space" "turn_external"
    turn_external_host = "chags.smartmall577.space"
    turn_external_port = 3478
    turn_external_secret = "chatghost-webrtc-secure-turn-key-577"
EOF

# ==============================================================================
# PASSO 8: PROVER CERTIFICADOS SSL COM CERTBOT LET'S ENCRYPT
# ==============================================================================
echo -e "\n${YELLOW}[Passo 8/12] Provisionando certificados SSL válidos...${NC}"
mkdir -p /etc/prosody/certs
chown -R prosody:prosody /etc/prosody/certs

# Novo diretório para certificados seguros e legíveis pelo Nginx
mkdir -p /etc/nginx/ssl
chmod 755 /etc/nginx/ssl

# Libera momentaneamente a porta 80 parando o Nginx e garantindo que nada prenda as portas
systemctl stop nginx || true
pkill -f nginx || true
if command -v fuser &> /dev/null; then
    fuser -k 80/tcp || true
    fuser -k 443/tcp || true
fi
systemctl stop prosody || true

echo -e "${YELLOW}Solicitando certificado oficial da Let's Encrypt para o domínio chags.smartmall577.space...${NC}"
certbot certonly --standalone -d chags.smartmall577.space --non-interactive --agree-tos -m rogermei577@gmail.com --preferred-challenges http || {
  echo -e "${RED}[AVISO] O Certbot falhou na geração do certificado. Criando certificados auto-assinados de backup...${NC}"
  openssl req -new -newkey rsa:2048 -days 365 -nodes -x509 \
    -subj "/C=BR/ST=SP/L=SaoPaulo/O=ChatGhost/CN=chags.smartmall577.space" \
    -keyout /etc/nginx/ssl/chatghost.key \
    -out /etc/nginx/ssl/chatghost.crt
}

# Importar certificados Let's Encrypt caso tenham sido gerados com sucesso
if [ -d "/etc/letsencrypt/live/chags.smartmall577.space" ]; then
    echo -e "${GREEN}[OK] Certificados Let's Encrypt gerados! Importando e aplicando permissões...${NC}"
    cp -L /etc/letsencrypt/live/chags.smartmall577.space/privkey.pem /etc/nginx/ssl/chatghost.key
    cp -L /etc/letsencrypt/live/chags.smartmall577.space/fullchain.pem /etc/nginx/ssl/chatghost.crt
fi

# Ajustar permissões para os certificados do Nginx para evitar erro de leitura (www-data)
chmod 644 /etc/nginx/ssl/chatghost.crt || true
chmod 600 /etc/nginx/ssl/chatghost.key || true

# Copiar ou linkar para o Prosody (com permissões adequadas de prosody:prosody)
cp /etc/nginx/ssl/chatghost.key /etc/prosody/certs/chags.smartmall577.space.key
cp /etc/nginx/ssl/chatghost.crt /etc/prosody/certs/chags.smartmall577.space.crt

# ==============================================================================
# CONFIGURAR SERVIDOR CO-TURN (STUN/TURN) PARA AUDIO/VIDEO WEBRTC E PERMISSÕES
# ==============================================================================
echo -e "\n${YELLOW}Configurando o servidor de STUN/TURN (Coturn) para Áudio e Vídeo...${NC}"

# Backup do turnserver.conf original
mv /etc/turnserver.conf /etc/turnserver.conf.bak || true

# Escrever nova configuração de alto desempenho e segura para o Coturn
cat << 'EOF' > /etc/turnserver.conf
listening-port=3478
tls-listening-port=5349
fingerprint
lt-cred-mech
use-auth-secret
static-auth-secret=chatghost-webrtc-secure-turn-key-577
realm=chags.smartmall577.space
total-quota=100
bps-capacity=0
stale-nonce=600
no-loopback-peers
no-multicast-peers
min-port=8000
max-port=10000
cert=/etc/prosody/certs/chags.smartmall577.space.crt
pkey=/etc/prosody/certs/chags.smartmall577.space.key
user=chatghostuser:chatghostpass577
EOF

# Garantir que o Coturn esteja ativado para iniciar no boot
sed -i 's/TURNSERVER_ENABLED=0/TURNSERVER_ENABLED=1/' /etc/default/coturn || true

# Adicionar turnserver ao grupo prosody para conseguir ler os certificados
usermod -aG prosody turnserver || true

# Ajustar permissões para os certificados do Prosody e Coturn
chown -R prosody:prosody /etc/prosody/certs/
chmod 750 /etc/prosody/certs || true
chmod 644 /etc/prosody/certs/chags.smartmall577.space.crt || true
chmod 640 /etc/prosody/certs/chags.smartmall577.space.key || true

# Garantir permissões de logs e dados para o Prosody
mkdir -p /var/log/prosody
chown -R prosody:prosody /var/log/prosody
chmod 750 /var/log/prosody

mkdir -p /var/lib/prosody
chown -R prosody:prosody /var/lib/prosody
chmod 750 /var/lib/prosody

# Habilitar e reiniciar o serviço Coturn
systemctl daemon-reload || true
systemctl enable coturn || true
systemctl restart coturn || true

# ==============================================================================
# PASSO 9: CONFIGURAR O WEB SERVER VIRTUAL HOST DO NGINX COM PROXY REVERSO DE API
# ==============================================================================
echo -e "\n${YELLOW}[Passo 9/12] Configurando Nginx Virtual Host e WebSocket + API Proxy...${NC}"

# Garantir que as pastas de configuração do Nginx existam
mkdir -p /etc/nginx/sites-available
mkdir -p /etc/nginx/sites-enabled

# Garantir a inclusão de sites-enabled no nginx.conf se estiver ausente
if [ -f "/etc/nginx/nginx.conf" ]; then
    if ! grep -q "sites-enabled" /etc/nginx/nginx.conf; then
        echo -e "${YELLOW}Injetando inclusão de sites-enabled no /etc/nginx/nginx.conf...${NC}"
        sed -i '/http {/a \    include /etc/nginx/sites-enabled/*;' /etc/nginx/nginx.conf || true
    fi
fi

cat << 'EOF' > /etc/nginx/sites-available/chatghost
server {
    listen 80;
    server_name chags.smartmall577.space;
    
    # Redirecionamento permanente para HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name chags.smartmall577.space;

    # SSL parameters pointing to secure Nginx certificates
    ssl_certificate /etc/nginx/ssl/chatghost.crt;
    ssl_certificate_key /etc/nginx/ssl/chatghost.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Document Root do Web Client do Chat Ghost
    root /var/www/chatghost/dist;
    index index.html;

    # Suporte a rotas SPA (Single Page Application)
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Encaminhamento seguro de requisições de API para o Backend Node.js
    location /api {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Redirecionamento seguro de WebSockets para o Prosody (porta 5280)
    location /xmpp-websocket {
        proxy_pass http://127.0.0.1:5280/xmpp-websocket;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400;
    }

    # BOSH api proxy de fallback
    location /http-bind {
        proxy_pass http://127.0.0.1:5280/http-bind;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

# Ativar configuração e limpar default
ln -sf /etc/nginx/sites-available/chatghost /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default || true

# ==============================================================================
# PASSO 10: COMPILAR E IMPLANTAR O BACKEND E CLIENTE FULLSTACK (PERSISTENTE)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 10/12] Compilando e instalando o backend e cliente Fullstack persistente...${NC}"
mkdir -p /var/www/chatghost

if [ -f "./package.json" ]; then
    echo -e "${YELLOW}Instalando dependências do projeto com npm...${NC}"
    npm install
    
    echo -e "${YELLOW}Executando compilação do frontend e do backend (Vite + esbuild)...${NC}"
    npm run build
    
    echo -e "${YELLOW}Copiando arquivos compilados para o diretório de produção /var/www/chatghost...${NC}"
    cp -r dist /var/www/chatghost/
    cp package.json /var/www/chatghost/
    cp -r node_modules /var/www/chatghost/
    
    # Criar arquivo inicial data-store.json se não existir, mantendo persistência das credenciais
    if [ ! -f "/var/www/chatghost/data-store.json" ]; then
        echo -e "${YELLOW}Criando base de dados persistente inicial data-store.json...${NC}"
        cat << 'JSONEOF' > /var/www/chatghost/data-store.json
{
  "users": [
    {
      "id": "superadmin",
      "username": "rgs577",
      "jid": "rgs577@chags.smartmall577.space",
      "password": "2149090577@Ukbelol-577",
      "name": "Chat Ghost SuperAdmin",
      "surname": "Manager",
      "email": "rogermei577@gmail.com",
      "status": "offline",
      "statusMessage": "Server manager active",
      "avatarColor": "#4f46e5",
      "role": "admin",
      "createdAt": "2026-07-07T23:56:25.933Z",
      "trialStartDate": "2026-07-07T23:56:25.934Z",
      "paymentExpiresAt": "2027-07-07T23:56:25.934Z",
      "graceExpiresAt": "2027-07-10T23:56:25.934Z",
      "hasPaid": true,
      "paymentStatus": "approved"
    }
  ],
  "rooms": [
    {
      "id": "general-muc",
      "name": "General Conference",
      "jid": "general@conference.chags.smartmall577.space",
      "theme": "General Discussion",
      "description": "Main server lobby for Chat Ghost XMPP network users.",
      "participants": [
        "rgs577@chags.smartmall577.space"
      ],
      "createdAt": "2026-07-07T23:56:25.934Z"
    },
    {
      "id": "development-muc",
      "name": "XMPP Debian Setup",
      "jid": "debian-setup@conference.chags.smartmall577.space",
      "theme": "Technical Installation",
      "description": "Discussions around the Debian 12 open-source server cluster setup.",
      "participants": [
        "rgs577@chags.smartmall577.space"
      ],
      "createdAt": "2026-07-07T23:56:25.934Z"
    }
  ],
  "messages": [],
  "mercadoPagoConfig": {
    "accessToken": "",
    "publicKey": ""
  },
  "payments": [],
  "blacklist": []
}
JSONEOF
    fi

    echo -e "${YELLOW}Configurando o serviço em segundo plano (systemd) para o backend Node.js...${NC}"
    NODE_PATH=$(which node || echo "/usr/bin/node")
    
    cat << SYSTEMDOF > /etc/systemd/system/chatghost-backend.service
[Unit]
Description=Chat Ghost Backend Fullstack API
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/chatghost
ExecStart=$NODE_PATH dist/server.cjs
Restart=always
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
SYSTEMDOF

    echo -e "${YELLOW}Habilitando e iniciando o serviço chatghost-backend...${NC}"
    systemctl daemon-reload
    systemctl enable chatghost-backend
    systemctl restart chatghost-backend
    
    echo -e "${YELLOW}Revisando e ajustando todas as permissões de arquivos, pastas e banco de dados...${NC}"
    # Garantir que o proprietário e grupo sejam www-data para evitar conflitos com o Nginx e o backend
    chown -R www-data:www-data /var/www/chatghost
    # Pastas com permissão de leitura, escrita e execução (775)
    find /var/www/chatghost -type d -exec chmod 775 {} +
    # Arquivos com permissão de leitura e escrita (664)
    find /var/www/chatghost -type f -exec chmod 664 {} +
    # Garantir permissão explícita no banco de dados JSON para leitura/gravação irrestrita
    chmod 664 /var/www/chatghost/data-store.json || true

    echo -e "${GREEN}[OK] Interface Web, Backend Node.js e Banco de Dados configurados com permissões ideais!${NC}"
else
    echo -e "${RED}[AVISO] package.json não localizado nesta pasta. O cliente Nginx será servido vazio até você compilar o código.${NC}"
fi

# ==============================================================================
# PASSO 11: REGISTRAR SUPER ADMIN DO SERVIDOR XMPP
# ==============================================================================
echo -e "\n${YELLOW}[Passo 11/12] Registrando Super Administrador 'rgs577'...${NC}"
prosodyctl register rgs577 chags.smartmall577.space 2149090577@Ukbelol-577 || echo -e "${YELLOW}[AVISO] Usuário admin 'rgs577' já existe ou falha na inserção automática.${NC}"

# ==============================================================================
# PASSO 12: CONFIGURAR REGRAS DO FIREWALL (UFW)
# ==============================================================================
echo -e "\n${YELLOW}[Passo 12/12] Liberando portas de segurança e infraestrutura no Firewall (UFW)...${NC}"
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 3000/tcp # Backend API Port
    ufw allow 5222/tcp # XMPP Client Connection (Android/iOS apps)
    ufw allow 5223/tcp # XMPP Direct TLS/SSL Connection
    ufw allow 5269/tcp # XMPP Server-to-Server
    ufw allow 5280/tcp # Prosody HTTP/WS
    ufw allow 3478/tcp # STUN/TURN TCP
    ufw allow 3478/udp # STUN/TURN UDP
    ufw allow 5349/tcp # STUN/TURN over TLS TCP
    ufw allow 5349/udp # STUN/TURN over TLS UDP
    ufw allow 8000:10000/udp # WebRTC RTP/RTCP Media Streams
    ufw --force enable || true
fi

# ==============================================================================
# FINALIZAÇÃO: COLOCAR O SISTEMA 100% ONLINE NO AR
# ==============================================================================
echo -e "\n${YELLOW}[Finalização] Iniciando e ativando todos os serviços integrados...${NC}"
systemctl daemon-reload || true
systemctl restart coturn || true
systemctl restart prosody || true
systemctl restart nginx || true
systemctl restart chatghost-backend || true
systemctl enable coturn || true
systemctl enable prosody || true
systemctl enable nginx || true
systemctl enable chatghost-backend || true

# Verificação de status
echo -e "\n${GREEN}✔ Status dos serviços em execução:${NC}"
systemctl is-active coturn || echo -e "${RED}Coturn inativo.${NC}"
systemctl is-active prosody || echo -e "${RED}Prosody inativo.${NC}"
systemctl is-active nginx || echo -e "${RED}Nginx inativo.${NC}"
systemctl is-active chatghost-backend || echo -e "${RED}Chatghost Backend inativo.${NC}"

echo -e "\n${GREEN}===================================================================${NC}"
echo -e "${GREEN}      PARABÉNS! INSTALAÇÃO DO CHAT GHOST CONCLUÍDA COM SUCESSO!     ${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e " 🚀 Endereço Web:      \${PURPLE}https://chags.smartmall577.space\${NC}"
echo -e " ⚡ Host XMPP:          \${PURPLE}chags.smartmall577.space\${NC}"
echo -e " 🔗 WebSocket URL:     \${PURPLE}wss://chags.smartmall577.space/xmpp-websocket\${NC}"
echo -e " 🔑 Super Admin:       \${PURPLE}rgs577@chags.smartmall577.space\${NC}"
echo -e " 🛡 Senha de Acesso:   \${PURPLE}2149090577@Ukbelol-577\${NC}"
echo -e " 📧 E-mail Certbot:    \${PURPLE}rogermei577@gmail.com\${NC}"
echo -e " 🛡️ Segurança:         ${YELLOW}Acesso restrito apenas ao Super Admin${NC}"
echo -e " 💾 Banco de Dados:    ${GREEN}Persistente (data-store.json c/ Leitura & Escrita)${NC}"
echo -e " 🚫 IP Blacklist:      ${RED}Ativo (3 erros consecutivos bloqueiam a faixa /24)${NC}"
echo -e " 👤 Desenvolvedor:     ${PURPLE}ukbelol@gmail.com${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e "O Chat Ghost XMPP está 100% ONLINE e no ar em produção para uso!"
