#!/bin/bash
# ==============================================================================
# CHAT GHOST - FULLY AUTOMATED SYSTEM STANDUP BOOTSTRAPPER (install-gerall.sh)
# Target OS: Debian 12 (Bookworm) / Ubuntu 22.04 LTS or newer
# Target Domain: chatghost.smartmall577.space
# Core Services: Prosody XMPP (v0.12+) + Nginx Web Server + Let's Encrypt SSL
# Author: Chat Ghost Deployment Team
# ==============================================================================

# Exit immediately if any command fails
set -e

# Clear screen for professional terminal visual flow
clear

# ANSI Color Codes for beautiful output
GREEN='\033[0;32m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}===================================================================${NC}"
echo -e "${PURPLE}       CHAT GHOST SPECTRAL PLATFORM - INTEGRATED BOOTSTRAPPER      ${NC}"
echo -e "${BLUE}===================================================================${NC}"
echo -e " Alvo de Domínio:     ${GREEN}chatghost.smartmall577.space${NC}"
echo -e " Email de Segurança:  ${GREEN}rogermei577@gmail.com${NC}"
echo -e " Sistema Homologado:  ${GREEN}Debian 12 (Bookworm) ou Ubuntu LTS${NC}"
echo -e " Status Alvo:         ${YELLOW}IMPLANTAÇÃO TOTAL E COLOCAR EM PRODUÇÃO${NC}"
echo -e "${BLUE}===================================================================${NC}"

# Ensure script is executed as Superuser (Root)
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERRO] Este script precisa ser executado como root (Superusuário).${NC}"
  echo -e "Por favor, mude para root executando: ${YELLOW}sudo su -${NC} e rode o script novamente."
  exit 1
fi

# Detect operating system
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_NAME=$ID
    OS_VERSION=$VERSION_ID
    echo -e "${GREEN}[INFO] Sistema operacional detectado: $OS_NAME $OS_VERSION${NC}"
else
    echo -e "${YELLOW}[AVISO] Não foi possível verificar os metadados do SO. Continuando...${NC}"
fi

# 1. Update Core System Repositories
echo -e "\n${YELLOW}[Passo 1/11] Atualizando lista de pacotes e dependências...${NC}"
apt-get update && apt-get upgrade -y

# 2. Install Core System Tools & Utilities
echo -e "\n${YELLOW}[Passo 2/11] Instalando pacotes básicos de rede, compilação e segurança...${NC}"
apt-get install -y \
  curl \
  gnupg2 \
  lsb-release \
  ca-certificates \
  certbot \
  python3-certbot-nginx \
  ufw \
  git \
  build-essential \
  sqlite3 \
  libsqlite3-dev \
  unzip \
  openssl

# 3. Provision Node.js Environment (LTS 20)
echo -e "\n${YELLOW}[Passo 3/11] Configurando ambiente de execução Node.js para o Web Client...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Instalando Node.js v20 LTS...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo -e "${GREEN}[OK] Node.js já está instalado na versão: $(node -v)${NC}"
fi

# 4. Configure Prosody Official Repository & Install XMPP Server
echo -e "\n${YELLOW}[Passo 4/11] Configurando repositório oficial do Prosody XMPP Server...${NC}"
mkdir -p /etc/apt/keyrings
curl -fsSL https://prosody.im/files/prosody-debian-packages.key | gpg --dearmor -o /etc/apt/keyrings/prosody.gpg || true

# Add official prosody source list
echo "deb [signed-by=/etc/apt/keyrings/prosody.gpg] http://packages.prosody.im/debian $(lsb_release -sc) main" > /etc/apt/sources.list.d/prosody.list

apt-get update
echo -e "${YELLOW}Instalando Prosody Core, LuaSec e drivers SQLite3 necessários...${NC}"
apt-get install -y prosody lua-sec lua-socket lua-expat lua-filesystem lua-dbi-sqlite3

# Install community modules for WebSocket support and mobile push compatibility
echo -e "${YELLOW}Baixando e instalando módulos Prosody da comunidade...${NC}"
mkdir -p /usr/lib/prosody-modules
rm -rf /tmp/prosody-modules || true
git clone https://hg.prosody.im/prosody-modules/ /tmp/prosody-modules

# Copy highly resilient modules to Prosody plugin directory
cp -r /tmp/prosody-modules/mod_websocket /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_turn_external /usr/lib/prosody-modules/ || true
cp -r /tmp/prosody-modules/mod_csi_simple /usr/lib/prosody-modules/ || true

# 5. Build and Deploy Chat Ghost Configs on Prosody
echo -e "\n${YELLOW}[Passo 5/11] Configurando o arquivo do Prosody (prosody.cfg.lua)...${NC}"
cat << 'EOF' > /etc/prosody/prosody.cfg.lua
-- CHAT GHOST SECURE MESSAGING SERVER CONFIG
-- Domain: chatghost.smartmall577.space

-- Modules path pointing to community folder
plugin_paths = { "/usr/lib/prosody-modules" }

-- Enabled modules list
modules_enabled = {
    -- Basic features
    "roster"; 
    "saslauth"; 
    "tls"; 
    "dialback"; 
    "disco"; 
    "private"; 
    "vcard4"; 
    "vcard"; 

    -- Advanced features for modern Web Clients
    "websocket"; 
    "bosh"; 
    "carbons"; -- History sync across devices
    "pep"; -- Avatars and profiles
    "adhoc"; 
    "admin_adhoc"; 
    "mam"; -- Message Archive Management
    "csi_simple"; -- Client State Indication
    "blocklist"; 
    "ping"; 
}

-- Force security parameters
allow_registration = false;
c2s_require_encryption = true;
s2s_require_encryption = true;

-- Directory for Let's Encrypt symbolic linked keys
certificates = "/etc/prosody/certs"

-- Logs configuration
log = {
    info = "/var/log/prosody/prosody.log";
    error = "/var/log/prosody/prosody.err";
}

-- Host settings
VirtualHost "chatghost.smartmall577.space"
    ssl = {
        key = "/etc/prosody/certs/chatghost.smartmall577.space.key";
        certificate = "/etc/prosody/certs/chatghost.smartmall577.space.crt";
    }

-- Multi-User Chat rooms
Component "conference.chatghost.smartmall577.space" "muc"
    restrict_room_creation = "admin"
    modules_enabled = { "muc_mam" }

-- WebRTC TURN/STUN helper server integration
Component "turn.chatghost.smartmall577.space" "turn_external"
    turn_external_host = "chatghost.smartmall577.space"
    turn_external_port = 3478
    turn_external_secret = "chatghost-webrtc-secure-turn-key-577"
EOF

# 6. Secure SSL Certificates with Let's Encrypt
echo -e "\n${YELLOW}[Passo 6/11] Obtendo certificado SSL válido da Let's Encrypt para o domínio...${NC}"
mkdir -p /etc/prosody/certs
chown -R prosody:prosody /etc/prosody/certs

# Stop services momentarily to free up port 80
systemctl stop nginx || true
systemctl stop prosody || true

# Obtain the Certificate
echo -e "${YELLOW}Executando Certbot Standalone...${NC}"
certbot certonly --standalone -d chatghost.smartmall577.space --non-interactive --agree-tos -m rogermei577@gmail.com --preferred-challenges http || {
  echo -e "${RED}[AVISO] Certbot Standalone falhou. Criando chaves de segurança auto-assinadas temporárias...${NC}"
  openssl req -new -newkey rsa:2048 -days 365 -nodes -x509 \
    -subj "/C=BR/ST=SP/L=SaoPaulo/O=ChatGhost/CN=chatghost.smartmall577.space" \
    -keyout /etc/prosody/certs/chatghost.smartmall577.space.key \
    -out /etc/prosody/certs/chatghost.smartmall577.space.crt
}

# Copy Let's Encrypt credentials to Prosody cert directory
if [ -d "/etc/letsencrypt/live/chatghost.smartmall577.space" ]; then
    echo -e "${GREEN}[OK] Certificados gerados com sucesso! Sincronizando com o Prosody...${NC}"
    cp /etc/letsencrypt/live/chatghost.smartmall577.space/privkey.pem /etc/prosody/certs/chatghost.smartmall577.space.key
    cp /etc/letsencrypt/live/chatghost.smartmall577.space/fullchain.pem /etc/prosody/certs/chatghost.smartmall577.space.crt
fi

# Permissions hardening
chown -R prosody:prosody /etc/prosody/certs/
chmod 640 /etc/prosody/certs/*.key || true

# 7. Configure and Setup Nginx Web Server Virtual Host
echo -e "\n${YELLOW}[Passo 7/11] Configurando o servidor Nginx e redirecionamento de Websocket...${NC}"
cat << 'EOF' > /etc/nginx/sites-available/chatghost
server {
    listen 80;
    server_name chatghost.smartmall577.space;
    
    # Global redirect to SSL
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name chatghost.smartmall577.space;

    # SSL parameters pointing to generated certificates
    ssl_certificate /etc/prosody/certs/chatghost.smartmall577.space.crt;
    ssl_certificate_key /etc/prosody/certs/chatghost.smartmall577.space.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Document Root of Chat Ghost UI
    root /var/www/chatghost/dist;
    index index.html;

    # Single Page Application router
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Redirect XMPP secure WebSockets to Prosody port 5280
    location /xmpp-websocket {
        proxy_pass http://127.0.0.1:5280/xmpp-websocket;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 86400;
    }

    # BOSH api for legacy fallback clients
    location /http-bind {
        proxy_pass http://127.0.0.1:5280/http-bind;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

# Activate Nginx configuration and clean default site
ln -sf /etc/nginx/sites-available/chatghost /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default || true

# 8. Build & Compile Web Client
echo -e "\n${YELLOW}[Passo 8/11] Compilando e gerando arquivos de produção do Web Client...${NC}"
mkdir -p /var/www/chatghost/dist

if [ -f "./package.json" ]; then
    echo -e "${YELLOW}Executando 'npm install' para buscar pacotes...${NC}"
    npm install
    
    echo -e "${YELLOW}Construindo build estático do cliente Web (Vite)...${NC}"
    npm run build
    
    echo -e "${YELLOW}Copiando arquivos compilados para o diretório de destino do Nginx (/var/www/chatghost/dist)...${NC}"
    cp -r dist/* /var/www/chatghost/dist/
    chown -R www-data:www-data /var/www/chatghost
    echo -e "${GREEN}[OK] Interface Web compilada e hospedada com sucesso!${NC}"
else
    echo -e "${RED}[AVISO] package.json não localizado nesta pasta. O cliente Nginx será servido vazio até você clonar o código e compilar.${NC}"
fi

# 9. Register Primary Super Admin Account
echo -e "\n${YELLOW}[Passo 9/11] Registrando Superusuário 'newest' no servidor Prosody...${NC}"
prosodyctl register newest chatghost.smartmall577.space blackangel@577-NHT || echo -e "${YELLOW}[AVISO] Super Admin 'newest' já existe ou erro na inserção.${NC}"

# 10. Enable UFW Security Rules
echo -e "\n${YELLOW}[Passo 10/11] Configurando portas e regras do Firewall (UFW)...${NC}"
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5222/tcp # XMPP Client-to-Server
ufw allow 5269/tcp # XMPP Server-to-Server
ufw allow 5280/tcp # Prosody HTTP
ufw allow 3478/udp # STUN/TURN UDP
ufw allow 5349/tcp # STUN/TURN TCP
ufw --force enable || true

# 11. Launch Services & Put Platform Online
echo -e "\n${YELLOW}[Passo 11/11] Colocando o sistema no ar em produção...${NC}"
systemctl daemon-reload || true
systemctl restart prosody
systemctl restart nginx
systemctl enable prosody
systemctl enable nginx

# 12. Verification check
echo -e "\n${GREEN}✔ Verificando serviços em execução:${NC}"
systemctl is-active prosody || echo -e "${RED}Prosody inativo.${NC}"
systemctl is-active nginx || echo -e "${RED}Nginx inativo.${NC}"

echo -e "\n${GREEN}===================================================================${NC}"
echo -e "${GREEN}      PARABÉNS! INSTALAÇÃO DO CHAT GHOST CONCLUÍDA COM SUCESSO!     ${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e " 🚀 Endereço Web:      ${PURPLE}https://chatghost.smartmall577.space${NC}"
echo -e " ⚡ Host XMPP:          ${PURPLE}chatghost.smartmall577.space${NC}"
echo -e " 🔗 WebSocket URL:     ${PURPLE}wss://chatghost.smartmall577.space/xmpp-websocket${NC}"
echo -e " 🔑 Super Admin:       ${PURPLE}newest@chatghost.smartmall577.space${NC}"
echo -e " 🛡 Senha de Acesso:   ${PURPLE}blackangel@577-NHT${NC}"
echo -e " 📧 E-mail Certbot:    ${PURPLE}rogermei577@gmail.com${NC}"
echo -e " 👤 Desenvolvedor:     ${PURPLE}ukbelol@gmail.com${NC}"
echo -e "${GREEN}===================================================================${NC}"
echo -e "O Chat Ghost está 100% ONLINE e no ar em produção prontamente para uso!"
